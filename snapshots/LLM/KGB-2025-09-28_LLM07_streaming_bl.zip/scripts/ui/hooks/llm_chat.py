# CONTRACT — UI Hook (Glue Only)
# This module is thin glue:
#  - Collect user text from the GUI.
#  - Call services.llm_client.generate(text, persona=...).
#  - Render the reply.
# Forbidden:
#  - subprocess calls
#  - direct provider imports (services.providers.*)
#  - env parsing or timeouts
# Provider selection and robustness live in services.llm_client.
"""LLM01 chat hook — keep _app_gui_entry_impl lean.

Usage from GUI classifier:
    for extra in _llm_handle_chat_line(s, persona=None):
        chat_buffer.append(extra); _chat_dirty = True

Usage from direct chat submit (bridge stopped):
    for extra in reply_for_user_text(user_text, persona=None):
        chat_buffer.append(extra); _chat_dirty = True

Contract:
    handle_chat_line(line: str, *, persona) -> list[str]
    reply_for_user_text(user_text: str, *, persona) -> list[str]

Notes:
- No side effects outside returning extra chat lines.
- Persona is accepted for future steps; unused in LLM01.
- Assistant display name is Piper."""
from __future__ import annotations
from typing import Any, List
import re

from services.llm_client import generate as llm_generate
from services.llm_client import stream_generate as llm_stream_generate
from services import state_store

# Canonical user line emitted by GUI/CLI bridge (allow optional leading '> ')
_USER_LINE_RE = re.compile(r"^(?:>\s*)?You:\s*(.*)$", re.IGNORECASE)


def handle_chat_line(line: str, *, persona: Any) -> List[str]:
    """Original non-streaming path (kept for compatibility)."""
    m = _USER_LINE_RE.match(line.strip())
    if not m:
        return []
    user_text = m.group(1)
    try:
        state_store.append_turn("user", user_text)
    except Exception:
        pass
    reply = llm_generate(user_text, persona=persona)
    try:
        state_store.append_turn("assistant", reply)
    except Exception:
        pass
    return [f"Piper: {reply}"]


def reply_for_user_text(user_text: str, *, persona: Any) -> List[str]:
    """Original non-streaming path (kept for compatibility)."""
    try:
        state_store.append_turn("user", user_text)
    except Exception:
        pass
    reply = llm_generate(user_text, persona=persona)
    try:
        state_store.append_turn("assistant", reply)
    except Exception:
        pass
    return [f"Piper: {reply}"]

# --- Streaming variants (LLM07.2) -------------------------------------------

def stream_reply_for_user_text(user_text: str, *, persona: Any, on_tick=None) -> List[str]:
    """Streaming consumer: appends/accumulates assistant text chunk-by-chunk.

    - Persists a single accumulating assistant turn via state_store.append_or_accumulate_assistant.
    - If provided, calls on_tick() after each chunk so the GUI can refresh.
    - Returns a single final "Piper: ..." line for compatibility with callers
      that expect a list of lines.
    """
    try:
        state_store.append_turn("user", user_text)
    except Exception:
        pass

    for chunk in llm_stream_generate(user_text, persona=persona):
        try:
            state_store.append_or_accumulate_assistant(chunk)
        except Exception:
            pass
        if on_tick is not None:
            try:
                on_tick()
            except Exception:
                pass

    # Read back the last assistant turn to form the final line
    try:
        recs = state_store.read_all(limit=1)
        final_text = recs[-1]["text"] if recs and recs[-1].get("role") == "assistant" else ""
    except Exception:
        final_text = ""
    return [f"Piper: {final_text}"]

def stream_handle_chat_line(line: str, *, persona: Any, on_tick=None) -> List[str]:
    m = _USER_LINE_RE.match(line.strip())
    if not m:
        return []
    user_text = m.group(1)
    return stream_reply_for_user_text(user_text, persona=persona, on_tick=on_tick)

# --- Stream-aware append -----------------------------------------------------

def append_or_accumulate_assistant(chunk: str, meta: Optional[dict] = None) -> dict:
    """Append chunk text into a single *assistant* turn.

    If the last record is an assistant turn, extend its text by `chunk`.
    Otherwise, append a new assistant turn initialized with `chunk`.

    Returns the updated/created assistant record.
    """
    _ensure_paths()
    with _LOCK:
        # Load existing records
        records: list[dict] = []
        try:
            with open(STATE_FILE, "r", encoding="utf-8", errors="ignore") as f:
                for ln in f:
                    ln = ln.strip()
                    if not ln:
                        continue
                    try:
                        records.append(json.loads(ln))
                    except Exception:
                        continue
        except FileNotFoundError:
            records = []

        # Decide whether to extend or append
        if records and isinstance(records[-1], dict) and records[-1].get("role") == "assistant":
            rec = records[-1]
            rec["text"] = (rec.get("text", "") or "") + ("" if chunk is None else str(chunk))
            if meta:
                # Shallow merge of meta
                rec_meta = rec.get("meta") or {}
                rec_meta.update(meta)
                rec["meta"] = rec_meta
        else:
            rec = {
                "ts": _now_ms(),
                "role": "assistant",
                "text": "" if chunk is None else str(chunk),
                "meta": meta or {},
            }
            records.append(rec)

        # Atomic rewrite
        tmp = STATE_FILE.with_suffix(".jsonl.tmp")
        with open(tmp, "w", encoding="utf-8", newline="") as f:
            for r in records:
                f.write(json.dumps(r, ensure_ascii=False) + "")
        os.replace(tmp, STATE_FILE)
        return rec
