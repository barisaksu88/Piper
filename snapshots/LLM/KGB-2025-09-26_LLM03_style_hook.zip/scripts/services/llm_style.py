﻿"""
Piper — LLM Integration (LLM03)
services/llm_style.py

Contract:
    apply_style(reply: str, *, persona) -> str

Notes:
- LLM03 is a pass-through. Future steps can shape tone/sarcasm here.
- Keep side-effect free; pure function.
"""
from __future__ import annotations
from typing import Any

# No magic numbers; read-only use of persona (reserved).

def apply_style(reply: str, *, persona: Any) -> str:
    _ = persona  # placeholder for future persona-aware transforms
    return reply
