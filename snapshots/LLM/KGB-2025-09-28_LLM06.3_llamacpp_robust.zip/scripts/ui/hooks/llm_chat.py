# CONTRACT — UI Hook (Glue Only)
# This module is thin glue:
#  - Collect user text from the GUI.
#  - Call services.llm_client.generate(text, persona=...).
#  - Render the reply.
# Forbidden:
#  - subprocess calls
#  - direct provider imports (services.providers.*)
#  - env parsing or timeouts
# Provider selection and robustness live in services.llm_client.
"""LLM01 chat hook — keep _app_gui_entry_impl lean.

Usage from GUI classifier:
    for extra in _llm_handle_chat_line(s, persona=None):
        chat_buffer.append(extra); _chat_dirty = True

Usage from direct chat submit (bridge stopped):
    for extra in reply_for_user_text(user_text, persona=None):
        chat_buffer.append(extra); _chat_dirty = True

Contract:
    handle_chat_line(line: str, *, persona) -> list[str]
    reply_for_user_text(user_text: str, *, persona) -> list[str]

Notes:
- No side effects outside returning extra chat lines.
- Persona is accepted for future steps; unused in LLM01.
- Assistant display name is Piper."""
from __future__ import annotations
from typing import Any, List
import re

from services.llm_client import generate as llm_generate

# Canonical user line emitted by GUI/CLI bridge (allow optional leading '> ')
_USER_LINE_RE = re.compile(r"^(?:>\s*)?You:\s*(.*)$", re.IGNORECASE)


def handle_chat_line(line: str, *, persona: Any) -> List[str]:
    """Return extra chat lines (if any) for a tailed chat line."""
    m = _USER_LINE_RE.match(line.strip())
    if not m:
        return []
    user_text = m.group(1)
    reply = llm_generate(user_text, persona=persona)
    return [f"Piper: {reply}"]


def reply_for_user_text(user_text: str, *, persona: Any) -> List[str]:
    """Return extra chat lines for a raw user text (used by direct GUI submit)."""
    reply = llm_generate(user_text, persona=persona)
    return [f"Piper: {reply}"]
