﻿"""
Piper — LLM Integration (LLM01)
services/llm_client.py

Contract:
    generate(user_text: str, *, persona) -> str

Notes:
- LLM01 is a SAFE stub. We don't touch Core or GUI beyond the call site.
- persona is read-only here; kept for future steps (LLM03), unused now.
- Default SAFE_MODE provider is effectively a canned response.
"""
from __future__ import annotations
from typing import Any

# No magic numbers or layout literals here per invariants.


def generate(user_text: str, *, persona: Any) -> str:
    """Return a minimal, friendly stub reply.

    LLM01 only: do not call any backend. Keep it instant and deterministic.
    The GUI send handler will append this as: "Assistant: <reply>".
    """
    # Persona is accepted but unused in LLM01 (reserved for LLM03 persona shaping)
    _ = persona  # quiet linters, intentional no-op
    return "Hello! (stub)"
