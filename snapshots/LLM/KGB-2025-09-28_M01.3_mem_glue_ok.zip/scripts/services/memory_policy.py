﻿# CONTRACT — Memory Policy v1
# - summarize_recent(turns) -> str
#   (token-bounded, deterministic summary of last N turns)
# - choose_write(summary) -> bool
#   (simple threshold gate; SAFE_MODE conservative)
# Forbidden:
# - Embeddings
# - External APIs or internet
# - Blocking calls into LLM providers

from __future__ import annotations
from typing import List, Dict
import os

# --- Deterministic knobs (env-overridable) ------------------------------------
# How many most-recent turns to consider
_SUM_TURNS = int(os.getenv("PIPER_MEM_SUMMARY_TURNS", "6") or 6)
# Max bytes to write (ASCII-bound) — keep tiny to ensure sync I/O stays fast
_SUM_MAX_CHARS = int(os.getenv("PIPER_MEM_SUMMARY_MAX", "200") or 200)
# Minimum length to consider writing an episode
_MIN_WRITE_LEN = int(os.getenv("PIPER_MEM_MINLEN", "50") or 50)
# Hard guard (0 disables writes)
_WRITE_ENABLE = os.getenv("PIPER_MEM_WRITE", "1").strip() not in {"0", "false", "no"}

# --- Helpers ------------------------------------------------------------------

def _coerce_turn(t: Dict) -> str:
    """Deterministically stringify a single turn dict (role + text only)."""
    role = str(t.get("role", "")).strip()
    text = str(t.get("text", "")).replace("\n", " ").replace("\r", " ")
    # Clamp each piece to keep total deterministic; leave head-bias
    if len(role) > 16:
        role = role[:16]
    if len(text) > 160:
        text = text[:160]
    return f"{role}: {text}".strip()

# --- Public API ---------------------------------------------------------------

def summarize_recent(turns: List[Dict]) -> str:
    """Return a deterministic ≤_SUM_MAX_CHARS summary of the last _SUM_TURNS.

    Policy: concatenate compact "role: text" lines for the last N turns, then
    truncate to the byte/char budget. No randomness, no model calls.
    """
    if not turns:
        return ""
    # Take last N deterministically
    tail = turns[-_SUM_TURNS:]
    parts = []
    for t in tail:
        parts.append(_coerce_turn(t))
    s = " | ".join(p for p in parts if p)
    if len(s) > _SUM_MAX_CHARS:
        s = s[:_SUM_MAX_CHARS]
    return s


def choose_write(summary: str) -> bool:
    """Gate writes conservatively in SAFE_MODE.

    - Disabled if PIPER_MEM_WRITE=0.
    - Otherwise write only if summary length ≥ _MIN_WRITE_LEN.
    """
    if not _WRITE_ENABLE:
        return False
    return bool(summary) and (len(summary) >= _MIN_WRITE_LEN)
