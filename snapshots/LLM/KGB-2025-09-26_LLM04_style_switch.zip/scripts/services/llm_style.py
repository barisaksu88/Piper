﻿"""
Piper — LLM Integration (LLM04)
services/llm_style.py

Contract:
    apply_style(reply: str, *, persona) -> str

Notes:
- LLM04 adds a SAFE style switch via env var PIPER_LLM_STYLE.
  Allowed: 'plain' (default), 'pilot', 'snark'.
- Pure, side‑effect free. Persona is accepted for later use.
"""
from __future__ import annotations
from typing import Any
import os

# -------------------------------
# Config / constants
# -------------------------------
_STYLE_ENV = "PIPER_LLM_STYLE"
_ALLOWED_STYLES = ("plain", "pilot", "snark")
_DEFAULT_STYLE = "plain"


def _style_plain(reply: str, persona: Any) -> str:
    return reply


def _style_pilot(reply: str, persona: Any) -> str:
    # Minimal ATC‑ish flourish; avoid duplication.
    r = (reply or "").strip()
    if not r:
        return r
    if r.lower().startswith("roger"):
        return r
    return f"Roger — {r}"


def _style_snark(reply: str, persona: Any) -> str:
    r = reply or ""
    # Keep it light; no toxicity.
    if r.endswith((".", "!", "?")):
        return r + " Sure."
    return r + " — sure."


_STYLES = {
    "plain": _style_plain,
    "pilot": _style_pilot,
    "snark": _style_snark,
}


def _current_style() -> str:
    v = (os.environ.get(_STYLE_ENV, _DEFAULT_STYLE) or "").strip().lower()
    return v if v in _ALLOWED_STYLES else _DEFAULT_STYLE


def apply_style(reply: str, *, persona: Any) -> str:
    """Apply the selected style to a rendered reply (pure)."""
    fn = _STYLES.get(_current_style(), _style_plain)
    return fn(reply, persona)
