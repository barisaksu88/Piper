﻿# CONTRACT — LLM Client (Registry + Robustness)
# Single registry for providers; the UI/entries must call only this client.
# Responsibilities:
#  - Select provider via env PIPER_LLM_PROVIDER (echo, stub, llamacpp, ...).
#  - Enforce LLM04 robustness: timeout + safe fallback, never block the GUI.
#  - Apply style via services.llm_style (persona shaping later).
# Forbidden:
#  - UI imports
#  - GUI mutations, logging UIs

from __future__ import annotations
import os
import concurrent.futures as _f
from typing import Callable, Dict

# --- Public API --------------------------------------------------------------
# generate(text, persona=None) -> str
#  - Selects provider by env PIPER_LLM_PROVIDER
#  - Wraps call with timeout (PIPER_LLM_TIMEOUT_MS, default 2000)
#  - Falls back safely to echo on error/timeout

ProviderFn = Callable[[str, str | None], str]

# Built-in trivial providers (no imports from UI!)

def _prov_echo(text: str, persona: str | None = None) -> str:
    return text

def _prov_stub(text: str, persona: str | None = None) -> str:
    return f"stub: {text}"

# Registry — external providers imported lazily to avoid heavy deps at import time
_REGISTRY: Dict[str, ProviderFn | None] = {
    "echo": _prov_echo,
    "stub": _prov_stub,
    # LLM06: register llamacpp provider; imported lazily
    "llamacpp": None,
}

# Resolve provider callable (lazy import for services.providers.llamacpp)

def _resolve_provider(name: str) -> ProviderFn:
    try:
        if name == "llamacpp":
            # Prefer absolute import style for clarity from services package root
            from services.providers import llamacpp as _ll
            return _ll.generate  # type: ignore[return-value]
        prov = _REGISTRY.get(name)
        if prov is None:
            raise KeyError(name)
        return prov
    except Exception as e:
        print(f"[ERR] provider resolve failed for '{name}': {e} -> using echo")
        return _prov_echo


def generate(text: str, persona: str | None = None) -> str:
    provider_name = os.getenv("PIPER_LLM_PROVIDER", "echo").strip().lower()
    timeout_ms_str = os.getenv("PIPER_LLM_TIMEOUT_MS", "2000").strip()
    try:
        timeout_ms = int(timeout_ms_str)
    except ValueError:
        timeout_ms = 2000

    provider = _resolve_provider(provider_name)

    def _call() -> str:
        return provider(text, persona)

    # LLM04 robustness: enforce timeout; never block UI thread
    with _f.ThreadPoolExecutor(max_workers=1, thread_name_prefix="llm_call") as ex:
        fut = ex.submit(_call)
        try:
            return fut.result(timeout=timeout_ms / 1000.0)
        except _f.TimeoutError:
            print(f"[ERR] LLM provider '{provider_name}' timeout after {timeout_ms} ms")
            return _prov_echo(text, persona)
        except Exception as e:
            print(f"[ERR] LLM provider '{provider_name}' failed: {e}")
            return _prov_echo(text, persona)
