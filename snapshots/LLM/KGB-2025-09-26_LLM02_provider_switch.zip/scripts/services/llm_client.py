﻿"""
Piper — LLM Integration (LLM02)
services/llm_client.py

Contract:
    generate(user_text: str, *, persona) -> str

Notes:
- LLM02 adds a SAFE provider switch via env var PIPER_LLM_PROVIDER.
  Allowed: 'echo' (default), 'stub'. No network/backends.
- persona is accepted (reserved for later persona shaping), unused here.
- Keep strings as layout-level constants; no magic numbers.
"""
from __future__ import annotations
from typing import Any, Callable, Dict
import os

# -------------------------------
# Config / constants
# -------------------------------
_PROVIDER_ENV = "PIPER_LLM_PROVIDER"
_ALLOWED_PROVIDERS = ("echo", "stub")
_DEFAULT_PROVIDER = "echo"  # SAFE_MODE default per runbook

_STUB_REPLY = "Hello! (stub)"


def _provider() -> str:
    v = (os.environ.get(_PROVIDER_ENV, _DEFAULT_PROVIDER) or "").strip().lower()
    return v if v in _ALLOWED_PROVIDERS else _DEFAULT_PROVIDER


# -------------------------------
# Provider implementations (pure)
# -------------------------------
def _gen_stub(user_text: str, persona: Any) -> str:
    _ = persona
    return _STUB_REPLY


def _gen_echo(user_text: str, persona: Any) -> str:
    _ = persona
    # Echo back the user's text; GUI prefixes speaker name.
    return user_text


_PROVIDERS: Dict[str, Callable[[str, Any], str]] = {
    "stub": _gen_stub,
    "echo": _gen_echo,
}


# -------------------------------
# Public API
# -------------------------------
def generate(user_text: str, *, persona: Any) -> str:
    """Generate a reply using the selected SAFE provider.

    Provider is chosen per-call from PIPER_LLM_PROVIDER to allow live toggling.
    """
    fn = _PROVIDERS.get(_provider(), _gen_echo)
    return fn(user_text, persona)
