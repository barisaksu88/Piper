﻿"""
Piper — LLM Integration (LLM04 — Robustness)
services/llm_client.py

Contract:
    generate(user_text: str, *, persona) -> str

Notes:
- LLM02 adds a SAFE provider switch via env var PIPER_LLM_PROVIDER.
  Allowed: 'echo' (default), 'stub'. No network/backends.
- persona is accepted (reserved for later persona shaping), unused here.
- Keep strings as layout-level constants; no magic numbers.
"""
from __future__ import annotations
from typing import Any, Callable, Dict
from services.llm_style import apply_style as _apply_style
import os
import concurrent.futures as _futures

# -------------------------------
# Robustness (LLM04)
# -------------------------------
_TIMEOUT_ENV = "PIPER_LLM_TIMEOUT_MS"
_DEFAULT_TIMEOUT_MS = 2000

# -------------------------------
# Config / constants
# -------------------------------
_PROVIDER_ENV = "PIPER_LLM_PROVIDER"
_ALLOWED_PROVIDERS = ("echo", "stub")
_DEFAULT_PROVIDER = "echo"  # SAFE_MODE default per runbook

_STUB_REPLY = "Hello! (stub)"


def _provider() -> str:
    v = (os.environ.get(_PROVIDER_ENV, _DEFAULT_PROVIDER) or "").strip().lower()
    return v if v in _ALLOWED_PROVIDERS else _DEFAULT_PROVIDER


# -------------------------------
# Provider implementations (pure)
# -------------------------------
def _gen_stub(user_text: str, persona: Any) -> str:
    _ = persona
    return _STUB_REPLY


def _gen_echo(user_text: str, persona: Any) -> str:
    _ = persona
    # Echo back the user's text; GUI prefixes speaker name.
    return user_text


_PROVIDERS: Dict[str, Callable[[str, Any], str]] = {
    "stub": _gen_stub,
    "echo": _gen_echo,
}


# -------------------------------
# Public API
# -------------------------------
def generate(user_text: str, *, persona: Any) -> str:
    """Generate a reply using the selected SAFE provider.

    Provider is chosen per-call from PIPER_LLM_PROVIDER to allow live toggling.
    """
    fn = _PROVIDERS.get(_provider(), _gen_echo)
    _ms = int(os.environ.get(_TIMEOUT_ENV, _DEFAULT_TIMEOUT_MS))
    try:
        with _futures.ThreadPoolExecutor(max_workers=1) as _ex:
            _fut = _ex.submit(fn, user_text, persona)
            raw = _fut.result(timeout=max(0.001, _ms / 1000.0))
    except _futures.TimeoutError:
        print("[ERR] LLM timeout or error")
        raw = "…(temporary issue)"
    except Exception:
        print("[ERR] LLM timeout or error")
        raw = "…(temporary issue)"
    return _apply_style(raw, persona=persona)
