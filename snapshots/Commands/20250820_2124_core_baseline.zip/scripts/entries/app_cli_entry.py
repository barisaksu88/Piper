# C:\Piper\scripts\entries\app_cli_entry.py
# COMMANDS Chapter - TCommands10 (FINAL for chapter):
# - Add "about" command confirming Commands baseline
# - SAFE_MODE default ON + runtime toggles preserved

import os
import sys
import queue
import datetime
from dataclasses import dataclass

# ---------- Core metadata ----------
CORE_VERSION = "TCommands10-2025-08-20"

def flag(name: str, default: str = "0") -> str:
    return os.environ.get(name, default)

FLAG_TRANSITIONS = flag("PIPER_CORE_TRANSITIONS", "1") == "1"
FLAG_FORWARD_INPUT = flag("PIPER_CORE_FORWARD_INPUT", "1") == "1"
DEFAULT_SANDBOX = True if flag("PIPER_CORE_SANDBOX", "1") == "1" else True
FLAG_RUNTIME = flag("PIPER_CORE_RUNTIME", "1") == "1"

def log_state(msg: str): print(f"[STATE] {msg}")
def log_core(msg: str): print(f"[CORE] {msg}")
def log_event(msg: str): print(f"[EVENT] {msg}")
def log_info(msg: str): print(f"[INFO] {msg}")

@dataclass
class Event:
    name: str
    payload: dict | None = None

class States:
    SLEEPING   = "SLEEPING"
    WAKING     = "WAKING"
    LISTENING  = "LISTENING"
    THINKING   = "THINKING"
    SPEAKING   = "SPEAKING"

AVAILABLE_STATES = "|".join([States.SLEEPING, States.WAKING, States.LISTENING, States.THINKING, States.SPEAKING])
AVAILABLE_EVENTS = "WakeDetected|ASRResult|Speak|StopSpeak|Sleep"

# -------------------------------
# Command Table (+ descriptions)
# -------------------------------
def cmd_time() -> str:
    now = datetime.datetime.now()
    return now.strftime("It's %H:%M.")

def cmd_date() -> str:
    today = datetime.date.today()
    return f"Today is {today.isoformat()}."

def cmd_help_list() -> str:
    return "Available commands: time, date, help, sleep, version, reset, about."

def cmd_version() -> str:
    return f"Piper Core {CORE_VERSION}"

def cmd_about() -> str:
    return "Piper Core Commands baseline ready."

COMMANDS = {
    "time":    {"fn": cmd_time,     "desc": "Say the current time (HH:MM)."},
    "date":    {"fn": cmd_date,     "desc": "Say today's date (YYYY-MM-DD)."},
    "help":    {"fn": cmd_help_list,"desc": "List commands or use 'help <command>'."},
    "sleep":   {"fn": None,         "desc": "Return to SLEEPING state (says 'Going to sleep.')."},
    "version": {"fn": cmd_version,  "desc": "Speak the current core version string."},
    "reset":   {"fn": None,         "desc": "Reset the core: speak, clear queue, and go to SLEEPING."},
    "about":   {"fn": cmd_about,    "desc": "Confirm Commands chapter baseline is ready."},
}

CMD_SLEEP_EVENT = "__CMD_SLEEP__"
CMD_RESET_EVENT = "__CMD_RESET__"

def parse_command(asr_text: str) -> str | None:
    """
    Router supports:
      - 'time', 'date', 'version', 'about'
      - 'help' / 'help <command>'
      - 'sleep'  → CMD_SLEEP_EVENT
      - 'reset'  → CMD_RESET_EVENT
    Returns: text to speak OR CMD_*_EVENT OR None if unknown.
    """
    t = (asr_text or "").strip().lower()

    # Progressive help
    if t.startswith("help"):
        parts = t.split(maxsplit=1)
        if len(parts) == 1:
            return cmd_help_list()
        topic = parts[1].strip()
        if topic in COMMANDS:
            return f"Help for '{topic}': {COMMANDS[topic]['desc']}"
        return "I don't know that command. Try 'help'."

    if t == "sleep":
        return CMD_SLEEP_EVENT
    if t == "reset":
        return CMD_RESET_EVENT

    for key, meta in COMMANDS.items():
        if key in t and key not in ("sleep", "reset"):
            fn = meta["fn"]
            if fn is not None:
                return fn()

    return None

# -------------------------------
# State Machine
# -------------------------------
class CoreMachine:
    def __init__(self):
        self.state = States.SLEEPING
        self.q = queue.SimpleQueue()
        self.sandbox = DEFAULT_SANDBOX

    def tts_say(self, text: str):
        if self.sandbox:
            print(f"[TTS] {text}")
        else:
            print(f"[TTS] (non-sandbox placeholder) {text}")

    def post(self, name: str, payload: dict | None = None):
        if FLAG_TRANSITIONS:
            log_event(f"queued {name} payload={payload or {}}")
        self.q.put(Event(name, payload))

    def clear_queue(self):
        cleared = 0
        while not self.q.empty():
            _ = self.q.get_nowait()
            cleared += 1
        if cleared and FLAG_TRANSITIONS:
            log_event(f"cleared {cleared} pending event(s)")

    def run(self):
        log_core(f"probe: file={__file__} runtime_flag='{int(FLAG_RUNTIME)}'")
        demo = [
            *(["PIPER_CORE_RUNTIME"] if FLAG_RUNTIME else []),
            *(["PIPER_CORE_TRANSITIONS"] if FLAG_TRANSITIONS else []),
            *(["PIPER_CORE_FORWARD_INPUT"] if FLAG_FORWARD_INPUT else []),
            "PIPER_CORE_SANDBOX" if self.sandbox else "(sandbox OFF)"
        ]
        log_core("demo_flags_active=" + ",".join(demo))
        log_state(f"available_states={AVAILABLE_STATES}")
        log_state(f"available_events={AVAILABLE_EVENTS}")
        print("Piper is ready. Commands: 'wake', 'sleep', 'sandbox on', 'sandbox off', 'exit'.")
        print("Flow: wake → (LISTENING) → type 'time', 'date', 'version', 'about', 'help <cmd>', 'sleep', or 'reset'.")

        while True:
            try:
                user = input("> ").strip()
            except (EOFError, KeyboardInterrupt):
                user = "exit"

            low = user.lower()

            # Runtime sandbox toggle
            if low in ("sandbox on", "sandbox off"):
                self.sandbox = low.endswith("on")
                print(f"[CORE] sandbox changed → {self.sandbox}")
                continue

            if low in ("exit", "quit"):
                log_core("sandbox=exit")
                break

            if low == "wake":
                self.post("WakeDetected")
            else:
                # Route everything (including typed 'sleep'/'reset') through ASR so parser handles it.
                if self.state == States.LISTENING or low in ("sleep", "reset"):
                    self.post("ASRResult", {"text": user})
                else:
                    log_info("Ignored input (not LISTENING). Use 'wake' first.")

            while not self.q.empty():
                ev = self.q.get_nowait()
                self.handle(ev)

    def set_state(self, new_state: str):
        if self.state != new_state:
            log_state(f"{self.state} → {new_state}")
            self.state = new_state

    def handle(self, ev: Event):
        name = ev.name
        payload = ev.payload or {}

        if name == "Sleep":
            self.set_state(States.SLEEPING)
            return

        if name == "WakeDetected":
            if self.state == States.SLEEPING:
                self.set_state(States.WAKING)
                self.post("Speak", {"text": "Hello sir!"})
            else:
                log_info("Wake ignored (not sleeping).")
            return

        if name == "Speak":
            text = payload.get("text", "")
            self.set_state(States.SPEAKING)
            self.tts_say(text)
            self.set_state(States.LISTENING)
            return

        if name == "ASRResult":
            heard = payload.get("text", "")
            log_event(f"ASRResult text='{heard}'")
            self.set_state(States.THINKING)
            reply = parse_command(heard)

            if reply == CMD_SLEEP_EVENT:
                self.post("Speak", {"text": "Going to sleep."})
                self.post("Sleep")
                return

            if reply == CMD_RESET_EVENT:
                # NOTE: current behavior speaks then resets immediately; queued Speak may be cleared.
                self.post("Speak", {"text": "Resetting core."})
                self.clear_queue()
                self.set_state(States.SLEEPING)
                return

            if reply is None:
                reply = "I don't know that command. Try 'help'."
            self.post("Speak", {"text": reply})
            return

        log_info(f"Unhandled event '{name}' parked.")

def main():
    mach = CoreMachine()
    mach.run()

if __name__ == "__main__":
    main()
