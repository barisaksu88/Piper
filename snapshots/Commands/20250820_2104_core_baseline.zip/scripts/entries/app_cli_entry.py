# C:\Piper\scripts\entries\app_cli_entry.py
# COMMANDS Chapter - TCommands04:
# - Add "help" command
# - Router now lists commands in a dictionary
# - SAFE_MODE default ON + runtime toggles preserved

import os
import sys
import queue
import datetime
from dataclasses import dataclass

# -------------------------------
# Flags (align with README_FIRST)
# -------------------------------
def flag(name: str, default: str = "0") -> str:
    return os.environ.get(name, default)

FLAG_TRANSITIONS = flag("PIPER_CORE_TRANSITIONS", "1") == "1"
FLAG_FORWARD_INPUT = flag("PIPER_CORE_FORWARD_INPUT", "1") == "1"
DEFAULT_SANDBOX = True if flag("PIPER_CORE_SANDBOX", "1") == "1" else True
FLAG_RUNTIME = flag("PIPER_CORE_RUNTIME", "1") == "1"

def log_state(msg: str): print(f"[STATE] {msg}")
def log_core(msg: str): print(f"[CORE] {msg}")
def log_event(msg: str): print(f"[EVENT] {msg}")
def log_info(msg: str): print(f"[INFO] {msg}")

# -------------------------------
# Core Events & States
# -------------------------------
@dataclass
class Event:
    name: str
    payload: dict | None = None

class States:
    SLEEPING   = "SLEEPING"
    WAKING     = "WAKING"
    LISTENING  = "LISTENING"
    THINKING   = "THINKING"
    SPEAKING   = "SPEAKING"

AVAILABLE_STATES = "|".join([States.SLEEPING, States.WAKING, States.LISTENING, States.THINKING, States.SPEAKING])
AVAILABLE_EVENTS = "WakeDetected|ASRResult|Speak|StopSpeak|Sleep"

# -------------------------------
# Command Table (English only)
# -------------------------------
def cmd_time() -> str:
    now = datetime.datetime.now()
    return now.strftime("It's %H:%M.")

def cmd_date() -> str:
    today = datetime.date.today()
    return f"Today is {today.isoformat()}."

def cmd_help() -> str:
    return "Available commands: time, date, help."

COMMANDS = {
    "time": cmd_time,
    "date": cmd_date,
    "help": cmd_help,
}

def parse_command(asr_text: str) -> str | None:
    t = (asr_text or "").strip().lower()
    for key, fn in COMMANDS.items():
        if key in t:
            return fn()
    return None

# -------------------------------
# State Machine
# -------------------------------
class CoreMachine:
    def __init__(self):
        self.state = States.SLEEPING
        self.q = queue.SimpleQueue()
        self.sandbox = DEFAULT_SANDBOX

    def tts_say(self, text: str):
        if self.sandbox:
            print(f"[TTS] {text}")
        else:
            print(f"[TTS] (non-sandbox placeholder) {text}")

    def post(self, name: str, payload: dict | None = None):
        if FLAG_TRANSITIONS:
            log_event(f"queued {name} payload={payload or {}}")
        self.q.put(Event(name, payload))

    def run(self):
        log_core(f"probe: file={__file__} runtime_flag='{int(FLAG_RUNTIME)}'")
        demo = [
            *(["PIPER_CORE_RUNTIME"] if FLAG_RUNTIME else []),
            *(["PIPER_CORE_TRANSITIONS"] if FLAG_TRANSITIONS else []),
            *(["PIPER_CORE_FORWARD_INPUT"] if FLAG_FORWARD_INPUT else []),
            "PIPER_CORE_SANDBOX" if self.sandbox else "(sandbox OFF)"
        ]
        log_core("demo_flags_active=" + ",".join(demo))
        log_state(f"available_states={AVAILABLE_STATES}")
        log_state(f"available_events={AVAILABLE_EVENTS}")
        print("Piper is ready. Commands: 'wake', 'sleep', 'sandbox on', 'sandbox off', 'exit'.")
        print("Flow: wake → (LISTENING) → type 'time', 'date', or 'help'.")

        while True:
            try:
                user = input("> ").strip()
            except (EOFError, KeyboardInterrupt):
                user = "exit"

            low = user.lower()
            if low in ("sandbox on", "sandbox off"):
                new_val = (low.endswith("on"))
                prev = self.sandbox
                self.sandbox = new_val
                print(f"[CORE] sandbox changed: {prev} → {self.sandbox}")
                continue

            if low in ("exit", "quit"):
                log_core("sandbox=exit")
                break

            if low == "sleep":
                self.post("Sleep")
            elif low == "wake":
                self.post("WakeDetected")
            else:
                if self.state == States.LISTENING:
                    self.post("ASRResult", {"text": user})
                else:
                    log_info("Ignored input (not LISTENING). Use 'wake' first, then speak/type your command.")

            while not self.q.empty():
                ev = self.q.get_nowait()
                self.handle(ev)

    def set_state(self, new_state: str):
        if self.state != new_state:
            log_state(f"{self.state} → {new_state}")
            self.state = new_state

    def handle(self, ev: Event):
        name = ev.name
        payload = ev.payload or {}

        if name == "Sleep":
            self.set_state(States.SLEEPING)
            return

        if name == "WakeDetected":
            if self.state == States.SLEEPING:
                self.set_state(States.WAKING)
                self.post("Speak", {"text": "Hello sir!"})
            else:
                log_info("Wake ignored (not sleeping).")
            return

        if name == "Speak":
            text = payload.get("text", "")
            self.set_state(States.SPEAKING)
            self.tts_say(text)
            self.set_state(States.LISTENING)
            return

        if name == "ASRResult":
            if self.state != States.LISTENING:
                log_info("ASR ignored (not listening).")
                return
            heard = payload.get("text", "")
            log_event(f"ASRResult text='{heard}'")
            self.set_state(States.THINKING)
            reply = parse_command(heard)
            if reply is None:
                reply = "For now I only know 'time', 'date', and 'help'."
            self.post("Speak", {"text": reply})
            return

        log_info(f"Unhandled event '{name}' parked.")

# -------------------------------
# Entrypoint
# -------------------------------
def main():
    mach = CoreMachine()
    mach.run()

if __name__ == "__main__":
    main()
