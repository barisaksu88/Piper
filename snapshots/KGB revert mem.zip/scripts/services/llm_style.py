﻿# CONTRACT — Style Uses Single Persona
# - apply_style(text, persona) expects persona from persona_source.load_persona()
# - Must not read files/env itself. Pure function, fast, non-blocking.
# - persona schema: { background:str, traits:{ sarcasm:float, professionalism:float, warmth:float, brevity:float, directness:float, humor:float, honorific:str }, _first_chunk:bool }

from __future__ import annotations
from typing import Any, Dict
import re

# Minimal, pure style pass for PS1 (no env/files, no I/O)

def _strip_primers(s: str) -> str:
    """Remove leaked control blocks like [persona]…[/persona] or [recall]…[/recall]."""
    try:
        # simple, case-insensitive slice-based stripper (no regex)
        for tag in ("persona", "recall"):
            open_t = f"[{tag}]"; close_t = f"[/{tag}]"
            low_open = open_t.lower(); low_close = close_t.lower()
            start = 0
            while True:
                low = s.lower()
                i = low.find(low_open, start)
                if i == -1:
                    break
                j = low.find(low_close, i)
                if j == -1:
                    # no closing tag; drop from open tag to end
                    s = s[:i]
                    break
                s = s[:i] + s[j + len(close_t):]
                start = i
        return s.lstrip()
    except Exception:
        return s


def apply_style(text: str, *, persona: Dict[str, Any] | None = None) -> str:
    """Return a styled version of *text* using the PS1 single-source persona.

    - No env or file reads occur here.
    - Light, non-blocking touches only.
    - Honors optional persona['_first_chunk'] hint for streaming.
    """
    try:
        if text is None:
            return text
        out = text
        # Decontaminate any leaked control blocks before styling
        if isinstance(out, str):
            out = _strip_primers(out)
        # Trait-driven light touches (pure, no I/O)
        traits = (persona or {}).get("traits", {}) if isinstance(persona, dict) else {}
        first_chunk = bool((persona or {}).get("_first_chunk", False))

        # Honorific: one-time prefix only on first chunk
        honor = str(traits.get("honorific", "") or "").strip()
        if honor and first_chunk and isinstance(out, str) and out:
            out = f"{honor}, {out}"

        # Sarcasm: one light emoji on first chunk if >= 0.5
        try:
            sarcasm = float(traits.get("sarcasm", 0.0) or 0.0)
        except Exception:
            sarcasm = 0.0
        if sarcasm >= 0.5 and first_chunk and any(c.isalnum() for c in out):
            out = f"{out} 😏"

        # Brevity: clamp based on slider (>=.9 → 140 chars; >=.7 → 200)
        try:
            brevity = float(traits.get("brevity", 0.0) or 0.0)
        except Exception:
            brevity = 0.0
        if isinstance(out, str):
            if brevity >= 0.9 and len(out) > 140:
                out = out[:140].rstrip() + "…"
            elif brevity >= 0.7 and len(out) > 200:
                out = out[:200].rstrip() + "…"
        return out
    except Exception:
        return text
