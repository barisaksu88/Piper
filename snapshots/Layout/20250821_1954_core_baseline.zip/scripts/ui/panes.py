# C:\Piper\scripts\ui\panes.py
# LAYOUT/LOOK – LL03: Smart autoscroll with single scroll container per pane.
# - Use child_window as the ONLY scroller; render content with add_text (wrapped).
# - Autoscroll when at bottom; pause when user scrolls up; resume at bottom.
# - State dot via drawlist circle.

from __future__ import annotations
import time
import dearpygui.dearpygui as dpg

# ------ Layout constants ------
VIEWPORT_W = 1100
VIEWPORT_H = 720
LEFT_W = int(VIEWPORT_W * 0.58)
RIGHT_W = VIEWPORT_W - LEFT_W - 32
PADDING = 8
ROW_H = VIEWPORT_H - 120

# ------ State→color mapping (RGBA 0–255) ------
STATE_COLORS = {
    "SLEEPING":  (128, 128, 128, 255),   # grey
    "WAKING":    (255, 165,   0, 255),   # orange
    "LISTENING": ( 70, 130, 180, 255),   # steel blue
    "THINKING":  (255, 215,   0, 255),   # gold
    "SPEAKING":  (  0, 200, 100, 255),   # green
}
_DEFAULT_DOT = (200, 200, 200, 255)
_DWELL_SEC = 0.35  # short dwell for visibility

# dwell trackers
_last_state = None
_last_change = 0.0

# autoscroll "stickiness" (True = stick to bottom)
_chat_sticky = True
_logs_sticky = True
_EPS = 2.0  # pixels tolerance to consider "at bottom"

def _is_at_bottom(tag: str) -> bool:
    try:
        cur = dpg.get_y_scroll(tag)
        mx  = dpg.get_y_scroll_max(tag)
        return (mx - cur) <= _EPS
    except Exception:
        return True  # default sticky during initial mount
    
def _scroll_to_bottom(tag: str):
    """Force scroll to bottom now and for a few subsequent frames to survive layout timing."""
    def _snap():
        try:
            mx = dpg.get_y_scroll_max(tag)
            dpg.set_y_scroll(tag, mx)
        except Exception:
            pass

    # do it immediately
    _snap()

    # and again for the next few frames (DPG updates content sizes lazily)
    try:
        fc = dpg.get_frame_count()
        for k in (1, 2, 3, 4, 5):
            dpg.set_frame_callback(fc + k, lambda s=None, a=None, u=None: _snap())
    except Exception:
        pass

def _update_state_dot(current_state: str):
    """Update dot color based on state with a brief dwell."""
    global _last_state, _last_change
    now = time.time()

    if current_state != _last_state:
        _last_state = current_state
        _last_change = now

    show_state = _last_state if (now - _last_change) < _DWELL_SEC and _last_state else current_state
    color = STATE_COLORS.get(show_state, _DEFAULT_DOT)

    try:
        dpg.configure_item("state_dot_circle", fill=color)
    except Exception:
        pass
    try:
        dpg.set_value("state_label", f"State: {current_state}")
    except Exception:
        pass

# ---------------- Public API ----------------
def init_ui(log_path: str) -> None:
    """
    Build the UI tree once. The root window is frameless and pinned to (0,0)
    so there is no "window inside window" offset.
    """
    # Root: frameless, immovable, primary, at (0,0)
    if dpg.does_item_exist("root"):
        dpg.delete_item("root")
    root = dpg.add_window(
        tag="root",
        pos=(0, 0),
        no_title_bar=True,
        no_move=True,
        no_resize=True
    )
    dpg.set_primary_window("root", True)

    # App header (title + state dot/label + heartbeat + tailing file)
    with dpg.group(parent=root, horizontal=False):
        dpg.add_text("Piper GUI", tag="title_label")
        with dpg.group(horizontal=True):
            # tiny drawlist for round state dot (14x14, radius 6 @ center (7,7))
            with dpg.drawlist(width=14, height=14, tag="state_dot_draw"):
                dpg.draw_circle(center=(7, 7), radius=6, color=(0, 0, 0, 0),
                                fill=_DEFAULT_DOT, tag="state_dot_circle")
            dpg.add_spacer(width=6)
            dpg.add_text("State: SLEEPING", tag="state_label")
            dpg.add_spacer(width=12)
            dpg.add_text("Last update: -", tag="hb_label")
            dpg.add_spacer(width=12)
            dpg.add_text(f"Tailing: {log_path}", tag="tailing_label")

    # Body: Chat (left) | Logs (right)
    with dpg.group(parent=root, horizontal=True):
        # Left panel: Chat (child_window is the ONLY scroller)
        with dpg.child_window(tag="chat_panel", width=LEFT_W, height=ROW_H,
                              autosize_x=False, autosize_y=False):
            dpg.add_text("Chat")
            dpg.add_spacer(height=4)
            dpg.add_text("", tag="chat_text", wrap=LEFT_W - PADDING * 2)

        # Right panel: Logs (child_window is the ONLY scroller)
        with dpg.child_window(tag="logs_panel", width=RIGHT_W, height=ROW_H,
                              autosize_x=False, autosize_y=False):
            dpg.add_text("Logs")
            dpg.add_spacer(height=4)
            dpg.add_text("", tag="log_text", wrap=RIGHT_W - PADDING * 2)

def refresh_ui(
    state_text: str,
    heartbeat_text: str,
    chat_text: str,
    log_text: str,
    chat_dirty: bool,
    log_dirty: bool
) -> None:
    """Update header labels and pane contents; smart autoscroll logic."""
    # Header labels
    try:
        dpg.set_value("hb_label", heartbeat_text)
    except Exception:
        pass

    # Update state dot & label
    _update_state_dot(state_text)

    # Determine stickiness BEFORE changing contents
    global _chat_sticky, _logs_sticky
    try:
        _chat_sticky = _is_at_bottom("chat_panel")
    except Exception:
        _chat_sticky = True
    try:
        _logs_sticky = _is_at_bottom("logs_panel")
    except Exception:
        _logs_sticky = True

    # Chat
    if chat_dirty:
        try:
            dpg.set_value("chat_text", chat_text)
            if _chat_sticky:
                _scroll_to_bottom("chat_panel")
        except Exception:
            pass
    else:
        try:
            _chat_sticky = _is_at_bottom("chat_panel")
        except Exception:
            pass

    # Logs
    if log_dirty:
        try:
            dpg.set_value("log_text", log_text)
            if _logs_sticky:
                _scroll_to_bottom("logs_panel")
        except Exception:
            pass
    else:
        try:
            _logs_sticky = _is_at_bottom("logs_panel")
        except Exception:
            pass
