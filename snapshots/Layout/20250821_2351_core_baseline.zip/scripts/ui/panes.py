# C:\Piper\scripts\ui\panes.py
# LAYOUT/LOOK – LL03 stable + LL05 (copy buttons) + LL04B header polish
# - Clean single-row header: Title · State dot+label · Heartbeat · Tailing path
# - Two child_window panes (Chat | Logs), equal outer margins
# - Autoscroll stickiness + dynamic wrapping
# - Copy Chat / Copy Logs buttons (inside pane headers)
from __future__ import annotations
import os
import time
import dearpygui.dearpygui as dpg

# ---------- layout ----------
VIEWPORT_W = 1100
VIEWPORT_H = 720
LEFT_W     = int(VIEWPORT_W * 0.58)
RIGHT_W    = VIEWPORT_W - LEFT_W - 32
ROW_H      = VIEWPORT_H - 120  # fits inside viewport without outer scroll
PAD        = 12                # content wrap padding

# ---------- colors ----------
STATE_COLORS = {
    "SLEEPING":  (128, 128, 128, 255),
    "WAKING":    (255, 165,   0, 255),
    "LISTENING": ( 70, 130, 180, 255),
    "THINKING":  (255, 215,   0, 255),
    "SPEAKING":  (  0, 200, 100, 255),
}
_DEFAULT_DOT = (200, 200, 200, 255)
_DWELL_SEC   = 0.35

_last_state  = None
_last_change = 0.0
_chat_sticky = True
_logs_sticky = True
_EPS         = 2.0  # px tolerance for "at bottom"

# ---------- LL05: copy helpers ----------
def _copy_chat():
    try:
        dpg.set_clipboard_text(dpg.get_value("chat_text") or "")
    except Exception:
        pass

def _copy_logs():
    try:
        dpg.set_clipboard_text(dpg.get_value("log_text") or "")
    except Exception:
        pass

# ---------- helpers ----------
def _is_at_bottom(tag: str) -> bool:
    try:
        cur = dpg.get_y_scroll(tag); mx = dpg.get_y_scroll_max(tag)
        return (mx - cur) <= _EPS
    except Exception:
        return True

def _scroll_to_bottom(tag: str):
    def _snap():
        try:
            dpg.set_y_scroll(tag, dpg.get_y_scroll_max(tag))
        except Exception:
            pass
    _snap()
    try:
        fc = dpg.get_frame_count()
        for k in (1, 2, 3, 4, 5):
            dpg.set_frame_callback(fc + k, lambda s=None, a=None, u=None: _snap())
    except Exception:
        pass

def _apply_wraps():
    try:
        w,_ = dpg.get_item_rect_size("chat_panel")
        dpg.configure_item("chat_text", wrap=max(0, int(w - PAD)))
    except Exception: pass
    try:
        w,_ = dpg.get_item_rect_size("logs_panel")
        dpg.configure_item("log_text", wrap=max(0, int(w - PAD)))
    except Exception: pass

def _update_state_dot(state_text: str):
    global _last_state, _last_change
    now = time.time()
    if state_text != _last_state:
        _last_state, _last_change = state_text, now
    show_state = _last_state if (now - _last_change) < _DWELL_SEC and _last_state else state_text
    color = STATE_COLORS.get(show_state, _DEFAULT_DOT)
    try: dpg.configure_item("state_dot_circle", fill=color)
    except Exception: pass
    try: dpg.set_value("state_label", f"State: {state_text}")
    except Exception: pass

def _shorten_path(p: str, max_chars: int = 72) -> str:
    """Middle-ellipsize a long path to keep header tidy."""
    try:
        s = str(p)
        if len(s) <= max_chars:
            return s
        head = s[: max_chars // 2 - 2].rstrip("\\/")
        tail = s[-(max_chars // 2 - 3):]
        return f"{head}…{tail}"
    except Exception:
        return p

# ---------- pane theme (gentle padding) ----------
def _ensure_pane_theme():
    if dpg.does_item_exist("pane_pad_theme"):
        return "pane_pad_theme"
    with dpg.theme(tag="pane_pad_theme"):
        with dpg.theme_component(dpg.mvAll):
            dpg.add_theme_style(dpg.mvStyleVar_WindowPadding, 10, 8, category=dpg.mvThemeCat_Core)
            dpg.add_theme_style(dpg.mvStyleVar_ItemSpacing,    6, 4, category=dpg.mvThemeCat_Core)
            dpg.add_theme_style(dpg.mvStyleVar_FramePadding,   6, 4, category=dpg.mvThemeCat_Core)
    return "pane_pad_theme"

# ---------- Public API ----------
def init_ui(log_path: str) -> None:
    """
    Root is fixed & primary at (0,0) (no offset). Clean single-row header.
    Two panes with equal visual margins; copy buttons in each header.
    """
    if dpg.does_item_exist("root"):
        dpg.delete_item("root")

    root = dpg.add_window(
        tag="root",
        pos=(0, 0),
        no_title_bar=True,
        no_move=True,
        no_resize=True,
        no_scrollbar=True,
    )
    dpg.set_primary_window("root", True)

    pane_theme = _ensure_pane_theme()

    # ---- Header (single row) ----
    with dpg.group(parent=root, tag="header_row", horizontal=True):
        dpg.add_text("Piper GUI", tag="title_label")
        dpg.add_spacer(width=16)

        # State dot + label
        with dpg.drawlist(width=14, height=14, tag="state_dot_draw"):
            dpg.draw_circle(center=(7, 7), radius=6, color=(0, 0, 0, 0),
                            fill=_DEFAULT_DOT, tag="state_dot_circle")
        dpg.add_spacer(width=6)
        dpg.add_text("State: SLEEPING", tag="state_label")

        # Heartbeat
        dpg.add_spacer(width=12)
        dpg.add_text("·", tag="dot_sep1")
        dpg.add_spacer(width=8)
        dpg.add_text("Last update: -", tag="hb_label")

        # Tailing file (shortened)
        dpg.add_spacer(width=12)
        dpg.add_text("·", tag="dot_sep2")
        dpg.add_spacer(width=8)
        dpg.add_text(_shorten_path(log_path), tag="tailing_label")

    dpg.add_spacer(parent=root, height=6)   # fix: ensure spacer has a parent

    # ---- Body: Chat (left) | Logs (right) ----
    with dpg.group(parent=root, tag="body_row", horizontal=True):
        # Left pane: Chat
        with dpg.child_window(tag="chat_panel", width=LEFT_W, height=ROW_H,
                              autosize_x=False, autosize_y=False):
            with dpg.group(horizontal=True):
                dpg.add_text("Chat", tag="chat_hdr")
                dpg.add_spacer(width=10)
                dpg.add_button(label="Copy Chat", callback=_copy_chat)
            dpg.add_separator()
            dpg.add_spacer(height=6)
            dpg.add_text("", tag="chat_text", wrap=LEFT_W - PAD)
        dpg.bind_item_theme("chat_panel", pane_theme)

        # Gap between panes
        dpg.add_spacer(width=12)

        # Right pane: Logs (slightly narrower so right margin matches left)
        with dpg.child_window(tag="logs_panel", width=(RIGHT_W - 12), height=ROW_H,
                              autosize_x=False, autosize_y=False):
            with dpg.group(horizontal=True):
                dpg.add_text("Logs", tag="logs_hdr")
                dpg.add_spacer(width=10)
                dpg.add_button(label="Copy Logs", callback=_copy_logs)
            dpg.add_separator()
            dpg.add_spacer(height=6)
            dpg.add_text("", tag="log_text", wrap=(RIGHT_W - PAD - 16))
        dpg.bind_item_theme("logs_panel", pane_theme)

def refresh_ui(
    state_text: str,
    heartbeat_text: str,
    chat_text: str,
    log_text: str,
    chat_dirty: bool,
    log_dirty: bool
) -> None:
    """Update header labels and pane contents; smart autoscroll + wrapping."""
    # Header heartbeat
    try: dpg.set_value("hb_label", heartbeat_text)
    except Exception: pass

    # State dot
    _update_state_dot(state_text)

    # Keep wraps aligned to actual panel widths
    _apply_wraps()

    # Determine stickiness BEFORE changing contents
    global _chat_sticky, _logs_sticky
    try:    _chat_sticky = _is_at_bottom("chat_panel")
    except: _chat_sticky = True
    try:    _logs_sticky = _is_at_bottom("logs_panel")
    except: _logs_sticky = True

    # Chat
    if chat_dirty:
        try:
            dpg.set_value("chat_text", chat_text)
            if _chat_sticky: _scroll_to_bottom("chat_panel")
        except Exception: pass

    # Logs
    if log_dirty:
        try:
            dpg.set_value("log_text", log_text)
            if _logs_sticky: _scroll_to_bottom("logs_panel")
        except Exception: pass
