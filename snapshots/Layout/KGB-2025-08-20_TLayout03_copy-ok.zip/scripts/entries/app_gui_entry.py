# C:\Piper\scripts\entries\app_gui_entry.py
# LAYOUT/LOOK Chapter - TLayout03:
# Two-pane scaffold with Copy buttons (Chat + Logs), read-only mirror.
# - Left: Chat (read-only) → [TTS] lines only
# - Right: Logs (read-only) → [STATE]/[EVENT]/[TTS]
# - Top status bar (Core state)
# - Copy buttons copy full visible buffers to clipboard
# - Frame-callback scheduler (Dear PyGui 2.1.0)
# - Spawns CLI subprocess and tails stdout; UI-only

import os
import sys
import time
import threading
import subprocess
from collections import deque
import re

import dearpygui.dearpygui as dpg

# -------------------------------
# Config
# -------------------------------
LOG_MAX_LINES  = 2000
CHAT_MAX_LINES = 1000
POLL_INTERVAL_SEC = 0.10
CLI_MODULE = "entries.app_cli_entry"

# -------------------------------
# State
# -------------------------------
log_buffer  = deque(maxlen=LOG_MAX_LINES)
chat_buffer = deque(maxlen=CHAT_MAX_LINES)
current_state = "SLEEPING"
proc: subprocess.Popen | None = None
lock = threading.Lock()

STATE_RE = re.compile(r"\[STATE\]\s*(?:([A-Z]+)\s*→\s*([A-Z]+)|([A-Z]+))")
INTERESTING_TAGS = ("[STATE]", "[EVENT]", "[TTS]")

# -------------------------------
# Subprocess + reader
# -------------------------------
def start_cli_subprocess():
    args = [sys.executable, "-u", "-m", CLI_MODULE]
    return subprocess.Popen(
        args,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        bufsize=1,
        universal_newlines=True,
        creationflags=0
    )

def reader_thread():
    global current_state
    assert proc is not None and proc.stdout is not None
    for raw in proc.stdout:
        line = raw.rstrip("\n")
        if any(tag in line for tag in INTERESTING_TAGS):
            with lock:
                log_buffer.append(line)
                if "[TTS]" in line:
                    # extract the text after the closing bracket
                    seg = line.split("]", 1)[-1].strip()
                    chat_buffer.append(seg if seg else line)
            # Track latest state
            m = STATE_RE.search(line)
            if m:
                if m.group(2):
                    current_state = m.group(2)
                elif m.group(3):
                    current_state = m.group(3)

# -------------------------------
# Dear PyGui helpers
# -------------------------------
def compose_text(buf: deque) -> str:
    with lock:
        return "\n".join(buf)

def copy_to_clipboard(buf: deque):
    dpg.set_clipboard_text(compose_text(buf))

def update_ui():
    dpg.set_value("state_text", f"Core state: {current_state}")
    dpg.set_value("chat_text", compose_text(chat_buffer))
    dpg.set_value("log_text", compose_text(log_buffer))

def schedule_recurring_update():
    frames_per_tick = max(1, int(POLL_INTERVAL_SEC * 60))  # ~60 FPS base
    next_frame = dpg.get_frame_count() + frames_per_tick
    def tick():
        if dpg.is_dearpygui_running():
            update_ui()
            schedule_recurring_update()
    dpg.set_frame_callback(next_frame, tick)

def on_close(sender, app_data, user_data):
    try:
        if proc and proc.poll() is None:
            proc.terminate()
            for _ in range(10):
                if proc.poll() is not None:
                    break
                time.sleep(0.05)
            if proc.poll() is None:
                proc.kill()
    except Exception:
        pass
    dpg.stop_dearpygui()

# -------------------------------
# Main entry
# -------------------------------
def main():
    global proc
    dpg.create_context()

    with dpg.window(label="Piper — Two‑pane Mirror (TLayout03)", width=1000, height=640, on_close=on_close):
        # Status bar
        dpg.add_text("Core state: SLEEPING", tag="state_text")
        dpg.add_separator()

        # Two-pane table
        with dpg.table(header_row=False, resizable=True, policy=dpg.mvTable_SizingStretchProp, borders_innerV=True, borders_outerV=True):
            dpg.add_table_column(init_width_or_weight=1)
            dpg.add_table_column(init_width_or_weight=1)

            with dpg.table_row():
                # Left: Chat (read-only)
                with dpg.child_window(border=True, autosize_x=False, autosize_y=True):
                    with dpg.group(horizontal=True):
                        dpg.add_text("Chat (read‑only):")
                        dpg.add_spacer(width=8)
                        dpg.add_button(label="Copy Chat", callback=lambda: copy_to_clipboard(chat_buffer))
                    dpg.add_input_text(tag="chat_text", default_value="", multiline=True, readonly=True, width=-1, height=-1)

                # Right: Logs (read-only)
                with dpg.child_window(border=True, autosize_x=False, autosize_y=True):
                    with dpg.group(horizontal=True):
                        dpg.add_text("Logs (read‑only):")
                        dpg.add_spacer(width=8)
                        dpg.add_button(label="Copy Logs", callback=lambda: copy_to_clipboard(log_buffer))
                    dpg.add_input_text(tag="log_text", default_value="", multiline=True, readonly=True, width=-1, height=-1)

    # Launch CLI subprocess and reader
    proc = start_cli_subprocess()
    t = threading.Thread(target=reader_thread, name="stdout_reader", daemon=True)
    t.start()

    dpg.create_viewport(title="Piper GUI — TLayout03 (Copy buttons)", width=1024, height=700)
    dpg.setup_dearpygui()
    dpg.show_viewport()

    schedule_recurring_update()

    dpg.start_dearpygui()
    dpg.destroy_context()

if __name__ == "__main__":
    main()
