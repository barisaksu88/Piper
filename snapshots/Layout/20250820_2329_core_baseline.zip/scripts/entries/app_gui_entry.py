# C:\Piper\scripts\entries\app_gui_entry.py
# LAYOUT/LOOK Chapter - TLayout06:
# - Clean theme (opt-in via PIPER_UI_THEME="clean")
# - Keeps: attach-mode tail, state dwell queue, robust autoscroll, soft-wrap, copy buttons

import os
import time
import threading
from collections import deque
from pathlib import Path
from datetime import datetime
import re

import dearpygui.dearpygui as dpg

# -------------------------------
# Config
# -------------------------------
LOG_PATH = os.environ.get("PIPER_CORE_LOG", r"C:\Piper\run\core.log")
TAIL_FROM_START = os.environ.get("PIPER_UI_TAIL_FROM_START", "0") == "1"
ENABLE_CLEAN_THEME = os.environ.get("PIPER_UI_THEME", "").lower() == "clean"

POLL_INTERVAL_SEC = 0.10
LOG_MAX_LINES  = 4000
CHAT_MAX_LINES = 2000
BOTTOM_EPS = 4.0
STATE_DWELL_SEC = 0.50   # visible time per state in the status bar

# -------------------------------
# State
# -------------------------------
log_buffer  = deque(maxlen=LOG_MAX_LINES)
chat_buffer = deque(maxlen=CHAT_MAX_LINES)

current_state = "SLEEPING"              # latest parsed state
state_queue: deque[str] = deque(["SLEEPING"])  # dwell queue head is displayed
last_display_switch: datetime = datetime.now()

last_update_ts: datetime | None = None
bytes_read = 0

STATE_RE = re.compile(r"\[STATE\]\s*(?:([A-Z]+)\s*→\s*([A-Z]+)|([A-Z]+))")
INTERESTING_TAGS = ("[STATE]", "[EVENT]", "[TTS]")

# autoscroll control (False = autoscroll enabled)
user_scrolled_chat = False
user_scrolled_logs = False

# threading
_stop_tail = False

# -------------------------------
# Helpers
# -------------------------------
def _consume_line(line: str):
    """Ingest one log line into buffers and update state/metrics."""
    global current_state, last_update_ts, bytes_read, last_display_switch
    if not line:
        return
    bytes_read += len(line.encode("utf-8", errors="ignore"))
    last_update_ts = datetime.now()

    if any(tag in line for tag in INTERESTING_TAGS):
        log_buffer.append(line)
        if "[TTS]" in line:
            seg = line.split("]", 1)[-1].strip()
            chat_buffer.append(seg if seg else line)

    # Parse state and enqueue for dwell
    m = STATE_RE.search(line)
    if m:
        new_state = current_state
        if m.group(2):
            new_state = m.group(2)
        elif m.group(3):
            new_state = m.group(3)

        if new_state != current_state:
            current_state = new_state
            if not state_queue or state_queue[-1] != new_state:
                was_empty = len(state_queue) == 0
                state_queue.append(new_state)
                if was_empty or len(state_queue) == 1:
                    last_display_switch = datetime.now()

def _tail_file(path: Path):
    """Tail the UTF-8 log with readline(); tolerant to truncation/rotation."""
    global _stop_tail
    while not path.exists() and not _stop_tail:
        time.sleep(0.1)
    if _stop_tail:
        return
    try:
        with path.open("r", encoding="utf-8", errors="ignore") as f:
            if not TAIL_FROM_START:
                f.seek(0, os.SEEK_END)  # default: tail from end
            while not _stop_tail:
                line = f.readline()
                if line:
                    _consume_line(line.rstrip("\r\n"))
                else:
                    cur = f.tell()
                    f.seek(0, os.SEEK_END)
                    if f.tell() < cur:
                        f.seek(0, os.SEEK_END)
                    time.sleep(POLL_INTERVAL_SEC)
    except Exception as e:
        print(f"[GUI] tail error: {e}")

def _state_color(name: str):
    # accessible palette
    return {
        "SLEEPING":  (130,130,130,255),  # gray
        "WAKING":    (255,170,0,255),    # orange
        "LISTENING": (0,155,255,255),    # blue
        "THINKING":  (185,95,255,255),   # purple
        "SPEAKING":  (0,200,120,255),    # green
    }.get(name, (160,160,160,255))

def _is_at_bottom(child_tag: str) -> bool:
    try:
        y = dpg.get_y_scroll(child_tag)
        y_max = dpg.get_y_scroll_max(child_tag)
        return (y_max - y) <= BOTTOM_EPS
    except Exception:
        return True

def _apply_wrap(text_tag: str, container_tag: str, pad: int = 16):
    try:
        w, _h = dpg.get_item_rect_size(container_tag)
        wrap_px = max(0, int(w) - pad)
        dpg.configure_item(text_tag, wrap=wrap_px)
    except Exception:
        pass

def _compose(buf: deque) -> str:
    return "\n".join(buf)

def _heartbeat_text():
    if not last_update_ts:
        return "Last update: —"
    delta = (datetime.now() - last_update_ts).total_seconds()
    return f"Last update: {int(delta)}s ago"

def copy_to_clipboard(buf: deque):
    dpg.set_clipboard_text(_compose(buf))

# -------------------------------
# UI update
# -------------------------------
def _advance_state_if_needed():
    """Advance state_queue head after dwell time so transient states are visible."""
    global last_display_switch
    if not state_queue:
        state_queue.append(current_state)
        last_display_switch = datetime.now()
        return
    age = (datetime.now() - last_display_switch).total_seconds()
    if age >= STATE_DWELL_SEC and len(state_queue) > 1:
        state_queue.popleft()
        last_display_switch = datetime.now()

def _current_display_state() -> str:
    return state_queue[0] if state_queue else current_state

def _update_status_bar():
    _advance_state_if_needed()
    shown = _current_display_state()
    dpg.configure_item("state_dot_btn", default_value=_state_color(shown))
    dpg.set_value("state_label", shown)
    dpg.set_value("hb_label", f"{_heartbeat_text()}   |   Bytes: {bytes_read:,}")

def _snap_to_bottom(child_tag: str):
    try:
        dpg.set_y_scroll(child_tag, dpg.get_y_scroll_max(child_tag))
        dpg.set_frame_callback(dpg.get_frame_count() + 1,
                               lambda: dpg.set_y_scroll(child_tag, dpg.get_y_scroll_max(child_tag)))
    except Exception:
        pass

def update_ui():
    _update_status_bar()

    # Determine bottom before updates to manage pause/resume
    at_bottom_chat = _is_at_bottom("chat_child")
    at_bottom_logs = _is_at_bottom("logs_child")

    global user_scrolled_chat, user_scrolled_logs
    if at_bottom_chat:
        user_scrolled_chat = False
    if at_bottom_logs:
        user_scrolled_logs = False

    # Update pane text
    dpg.set_value("chat_text", _compose(chat_buffer))
    dpg.set_value("log_text", _compose(log_buffer))

    # Apply soft-wrap to pane widths
    _apply_wrap("chat_text", "chat_child")
    _apply_wrap("log_text", "logs_child")

    # Auto-scroll if not paused by user
    if not user_scrolled_chat:
        _snap_to_bottom("chat_child")
    if not user_scrolled_logs:
        _snap_to_bottom("logs_child")

def schedule_recurring_update():
    frames_per_tick = max(1, int(POLL_INTERVAL_SEC * 60))
    next_frame = dpg.get_frame_count() + frames_per_tick
    def tick():
        if dpg.is_dearpygui_running():
            update_ui()
            schedule_recurring_update()
    dpg.set_frame_callback(next_frame, tick)

# -------------------------------
# Theme (opt-in)
# -------------------------------
def _apply_clean_theme():
    """Minimal, high-contrast theme; opt-in via PIPER_UI_THEME=clean."""
    with dpg.theme(tag="clean_theme"):
        with dpg.theme_component(dpg.mvAll):
            # Backgrounds
            dpg.add_theme_color(dpg.mvThemeCol_WindowBg,  (18,18,20,255))
            dpg.add_theme_color(dpg.mvThemeCol_ChildBg,   (24,24,28,255))
            dpg.add_theme_color(dpg.mvThemeCol_PopupBg,   (24,24,28,255))
            dpg.add_theme_color(dpg.mvThemeCol_MenuBarBg, (24,24,28,255))
            # Text
            dpg.add_theme_color(dpg.mvThemeCol_Text,      (235,235,238,255))
            # Frames/Buttons
            dpg.add_theme_color(dpg.mvThemeCol_FrameBg,   (34,34,38,255))
            dpg.add_theme_color(dpg.mvThemeCol_FrameBgHovered, (54,54,60,255))
            dpg.add_theme_color(dpg.mvThemeCol_Button,    (34,34,38,255))
            dpg.add_theme_color(dpg.mvThemeCol_ButtonHovered, (54,54,60,255))
            # Borders
            dpg.add_theme_style(dpg.mvStyleVar_FrameRounding, 6, category=dpg.mvThemeCat_Core)
            dpg.add_theme_style(dpg.mvStyleVar_ChildRounding, 8, category=dpg.mvThemeCat_Core)
            dpg.add_theme_style(dpg.mvStyleVar_WindowRounding, 8, category=dpg.mvThemeCat_Core)
            dpg.add_theme_style(dpg.mvStyleVar_ItemSpacing, 6, 6, category=dpg.mvThemeCat_Core)
    dpg.bind_theme("clean_theme")

# -------------------------------
# GUI layout
# -------------------------------
def _on_chat_scroll(sender, app_data):
    global user_scrolled_chat
    user_scrolled_chat = not _is_at_bottom("chat_child")

def _on_logs_scroll(sender, app_data):
    global user_scrolled_logs
    user_scrolled_logs = not _is_at_bottom("logs_child")

def build_gui():
    with dpg.window(label="Piper — Status + Two‑pane (TLayout06, Attach mode)", width=1040, height=720, on_close=on_close):
        # Status bar
        with dpg.group(horizontal=True):
            dpg.add_color_button((120,120,120,255), tag="state_dot_btn", no_border=True, width=14, height=14)
            dpg.add_text("SLEEPING", tag="state_label")
            dpg.add_spacer(width=12)
            dpg.add_text("Last update: —", tag="hb_label")
            dpg.add_spacer(width=12)
            dpg.add_text(f"Tailing: {LOG_PATH}")
        dpg.add_separator()

        # Two-pane table
        with dpg.table(header_row=False, resizable=True, policy=dpg.mvTable_SizingStretchProp, borders_innerV=True, borders_outerV=True):
            dpg.add_table_column(init_width_or_weight=1)
            dpg.add_table_column(init_width_or_weight=1)

            with dpg.table_row():
                # Left: Chat
                with dpg.child_window(tag="chat_child", border=True, autosize_x=False, autosize_y=True):
                    with dpg.group(horizontal=True):
                        dpg.add_text("Chat (read‑only)")
                        dpg.add_spacer(width=8)
                        dpg.add_button(label="Copy Chat", callback=lambda: copy_to_clipboard(chat_buffer))
                    dpg.add_text("", tag="chat_text", wrap=0)
                    with dpg.handler_registry():
                        dpg.add_mouse_wheel_handler(callback=_on_chat_scroll)
                        dpg.add_mouse_drag_handler(button=dpg.mvMouseButton_Left, callback=_on_chat_scroll)

                # Right: Logs
                with dpg.child_window(tag="logs_child", border=True, autosize_x=False, autosize_y=True):
                    with dpg.group(horizontal=True):
                        dpg.add_text("Logs (read‑only)")
                        dpg.add_spacer(width=8)
                        dpg.add_button(label="Copy Logs", callback=lambda: copy_to_clipboard(log_buffer))
                    dpg.add_text("", tag="log_text", wrap=0)
                    with dpg.handler_registry():
                        dpg.add_mouse_wheel_handler(callback=_on_logs_scroll)
                        dpg.add_mouse_drag_handler(button=dpg.mvMouseButton_Left, callback=_on_logs_scroll)

def on_close(sender, app_data, user_data):
    global _stop_tail
    _stop_tail = True
    dpg.stop_dearpygui()

# -------------------------------
# Main
# -------------------------------
def main():
    # Start tail thread
    path = Path(LOG_PATH)
    t = threading.Thread(target=_tail_file, args=(path,), name="file_tail", daemon=True)
    t.start()

    # GUI
    dpg.create_context()
    build_gui()
    if ENABLE_CLEAN_THEME:
        _apply_clean_theme()

    dpg.create_viewport(title="Piper GUI — TLayout06", width=1060, height=760)
    dpg.setup_dearpygui()
    dpg.show_viewport()
    schedule_recurring_update()
    dpg.start_dearpygui()
    dpg.destroy_context()

if __name__ == "__main__":
    main()
