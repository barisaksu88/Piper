﻿"""Header Bar pane (stub)."""
from __future__ import annotations
import dearpygui.dearpygui as dpg
from typing import Optional

def build(log_path: Optional[str] = None) -> None:
    pass

def refresh(state_text: str, heartbeat_text: str, tone_text: str, sarcasm_text: str, tailing_text: str) -> None:
    pass

def set_heartbeat(text: str) -> None:
    """Update the heartbeat label in the header if present."""
    try:
        if dpg.does_item_exist("hb_label"):
            dpg.set_value("hb_label", text)
    except Exception:
        pass
