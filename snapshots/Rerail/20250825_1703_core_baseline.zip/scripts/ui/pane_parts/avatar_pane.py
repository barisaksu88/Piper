﻿"""Avatar pane (stub)."""
from __future__ import annotations
import dearpygui.dearpygui as dpg
from typing import Tuple

def build() -> None:
    pass

def resize(panel_size: Tuple[int, int]) -> None:
    pass
