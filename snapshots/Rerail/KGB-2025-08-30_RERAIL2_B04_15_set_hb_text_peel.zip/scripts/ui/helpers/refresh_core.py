"""B04.13b refresh core — extracted from ui/panes.py (behavior-preserving)."""
from __future__ import annotations

# --- imports the function relied on when refresh_ui lived in panes.py ---
import dearpygui.dearpygui as dpg
from scripts.ui.helpers.header_utils import compose_header_strings
from scripts.ui.helpers.header_bridge import apply_header_updates
from scripts.ui.helpers.scroll_utils import (
    is_at_bottom,
    scroll_to_bottom_next_frame,
    update_autoscroll_badges,
)
from scripts.ui.helpers.chatlog_writer import write_chat, write_logs
from scripts.ui.helpers.dev_controls_mount import lazy_mount_under_logs
from scripts.ui.helpers.dev_adapters import build_dev_adapters
from scripts.ui.helpers.layout_utils import apply_wraps_if_present, update_bottom_padding_if_present
# Layout constants (wrap widths & bottom pads) — fall back to 0 if not defined
try:
    from scripts.ui.layout_constants import CHAT_WRAP, LOG_WRAP, CHAT_BOTTOM_PAD, LOG_BOTTOM_PAD
except Exception:
    CHAT_WRAP = 0
    LOG_WRAP = 0
    CHAT_BOTTOM_PAD = 0
    LOG_BOTTOM_PAD = 0


# local copy of a tiny utility that used to live next to refresh_ui
def first_existing_tag(candidates):
    for t in candidates:
        try:
            if dpg.does_item_exist(t):
                return t
        except Exception:
            pass
    return None

def _ensure_text_widgets(CHAT_SCROLL, CHAT_TEXT, LOG_SCROLL, LOG_TEXT):
    """
    Make sure chat/log text widgets exist so set_value() works (including Dev injectors).
    If missing, create simple dpg.add_text() children inside their scroll containers.
    Safe no-op if tags already exist or containers are absent.
    """
    try:
        if CHAT_SCROLL and not CHAT_TEXT and dpg.does_item_exist(CHAT_SCROLL):
            dpg.add_text("", parent=CHAT_SCROLL, tag="chat_text")
    except Exception:
        pass
    try:
        if LOG_SCROLL and not LOG_TEXT and dpg.does_item_exist(LOG_SCROLL):
            dpg.add_text("", parent=LOG_SCROLL, tag="log_text")
    except Exception:
        pass

def refresh_ui(
    state_text: str,
    heartbeat_text: str,
    chat_text: str,
    log_text: str,
    chat_dirty: bool,
    log_dirty: bool
) -> None:
    """Update header + panes; autoscroll if user is already near bottom."""
    import dearpygui.dearpygui as dpg
    # Resolve tags
    CHAT_SCROLL = first_existing_tag(["chat_scroll", "chat_view", "chat_region"])
    CHAT_TEXT   = first_existing_tag(["chat_text", "chat_buffer"])
    LOG_SCROLL  = first_existing_tag(["log_scroll", "logs_scroll", "log_view", "logs_view"])
    LOG_TEXT    = first_existing_tag(["log_text", "logs_text", "log_buffer"])

    # Ensure text widgets exist so both refresh and Dev injectors can write
    _ensure_text_widgets(CHAT_SCROLL, CHAT_TEXT, LOG_SCROLL, LOG_TEXT)
    # re-resolve, in case we just created them
    CHAT_TEXT = CHAT_TEXT or ("chat_text" if dpg.does_item_exist("chat_text") else None)
    LOG_TEXT  = LOG_TEXT  or ("log_text"  if dpg.does_item_exist("log_text")  else None)

    # B02: now that tags are known, lazy-mount Dev Controls under Logs when flag=1
    try:
        lazy_mount_under_logs(LOG_SCROLL, LOG_TEXT, adapters=build_dev_adapters(_hb, _shorten_path))
    except Exception:
        pass

    # Apply wrap widths + ensure bottom padding spacers
    apply_wraps_if_present(["chat_text", "chat_buffer"], CHAT_WRAP)
    apply_wraps_if_present(["log_text", "logs_text", "log_buffer"], LOG_WRAP)
    update_bottom_padding_if_present(["chat_scroll", "chat_view", "chat_region"], CHAT_BOTTOM_PAD)
    update_bottom_padding_if_present(["log_scroll", "logs_scroll", "log_view", "logs_view"], LOG_BOTTOM_PAD)

    # Autoscroll badge visibility and write paths
    CHAT_BADGE = first_existing_tag(["chat_autoscroll_badge"])
    LOG_BADGE  = first_existing_tag(["log_autoscroll_badge", "logs_autoscroll_badge"])

    # where are we relative to bottom?
    chat_was_bottom = is_at_bottom(CHAT_SCROLL)
    log_was_bottom  = is_at_bottom(LOG_SCROLL)

    # update badges (safe no-op if tags missing)
    update_autoscroll_badges(CHAT_SCROLL, CHAT_BADGE, LOG_SCROLL, LOG_BADGE)

    # Write text when dirty (uses helper; also handles scroll-to-bottom when already at bottom)
    if chat_dirty:
        write_chat(chat_text or "", CHAT_SCROLL, CHAT_TEXT, chat_was_bottom)
    if log_dirty:
        write_logs(log_text or "", LOG_SCROLL, LOG_TEXT, log_was_bottom)
