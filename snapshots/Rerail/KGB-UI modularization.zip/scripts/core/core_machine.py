# C:\Piper\scripts\core\core_machine.py
# T‑Core02: CoreMachine (REPL loop + dispatch), persona-agnostic.
from __future__ import annotations
import sys
from typing import Callable, Optional

try:
    from scripts.core.core_commands import handle_core_command, core_banner  # type: ignore
except Exception:
    from core.core_commands import handle_core_command, core_banner  # type: ignore

SayFn = Callable[[str, Optional[str]], None]

class CoreMachine:
    def __init__(self, say: SayFn, version_str: str) -> None:
        self._say = say
        self._version = version_str

    def run(self) -> None:
        # Startup banner
        core_banner(self._say, self._version)

        # Simple REPL
        while True:
            try:
                # Prompt (no trailing space to match prior behavior)
                sys.stdout.write("> ")
                sys.stdout.flush()

                line = sys.stdin.readline()
                if not line:
                    # EOF (e.g., pipeline ends) → exit cleanly
                    return
                user_input = line.rstrip("\r\n")

                # Core commands first
                res = handle_core_command(user_input, self._say, version_str=self._version)
                if res == "EXIT":
                    return
                if res is True:
                    continue

                # Not handled → unknown command (hard error tone)
                self._say("I don't know that command. Try 'help'.", "error_hard")

            except KeyboardInterrupt:
                self._say("✔ Bye.", "confirm")
                return
            except Exception as e:
                # Keep REPL alive on unexpected errors
                self._say(f"Unexpected error: {e}", "error")
