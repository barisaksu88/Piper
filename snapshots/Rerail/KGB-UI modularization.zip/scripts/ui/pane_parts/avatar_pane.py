﻿"""Avatar pane — build + resize + fallback drawing (mutually exclusive surfaces)."""
from __future__ import annotations
from typing import Tuple, Optional
import dearpygui.dearpygui as dpg

def build() -> None:
    """
    Create the avatar panel & draw surface if missing.
    """
    try:
        if not dpg.does_item_exist("logs_container"):
            return
        if not dpg.does_item_exist("avatar_panel"):
            with dpg.child_window(
                tag="avatar_panel",
                autosize_x=True,
                autosize_y=False,
                no_scrollbar=True,              # <- no scrollbars in avatar panel
            ):
                pass
        # Ensure a drawlist exists for fallback glyph
        if not dpg.does_item_exist("avatar_draw"):
            dpg.add_drawlist(tag="avatar_draw", parent="avatar_panel", show=True)
        # If an image widget exists, start hidden (we'll toggle in resize)
        if dpg.does_item_exist("avatar_image"):
            dpg.configure_item("avatar_image", show=False)
    except Exception:
        pass

def _fallback_draw(ap_w: int, ap_h: int) -> None:
    """Draw a pill + 'P' glyph when image texture is not available."""
    try:
        if not dpg.does_item_exist("avatar_draw"):
            return
        dpg.delete_item("avatar_draw", children_only=True)
        dpg.draw_rectangle(
            (0, 0), (ap_w, ap_h),
            color=(0, 0, 0, 0),
            fill=(24, 48, 96, 255),
            rounding=12,
            parent="avatar_draw",
        )
        dpg.draw_text(
            (ap_w // 2 - 12, ap_h // 2 - 24),
            "P",
            size=48,
            color=(230, 240, 255, 255),
            parent="avatar_draw",
        )
    except Exception:
        pass

def resize(
    panel_size: Tuple[int, int],
    pad: int,
    avatar_tex: Optional[int],
    img_w: Optional[int],
    img_h: Optional[int],
) -> None:
    """
    Fit avatar image/draw into panel_size with padding.
    - If texture + size known: show image, hide drawlist.
    - Else: hide image, show drawlist with fallback glyph.
    Ensures no child is larger than the panel (prevents scrolling).
    """
    try:
        ap_w, ap_h = int(panel_size[0]), int(panel_size[1])
        avail_w = max(50, ap_w - pad)
        avail_h = max(50, ap_h - pad)

        has_img_dims = bool(img_w) and bool(img_h)
        has_tex = bool(avatar_tex)

        # Always keep the container non-scrollable
        if dpg.does_item_exist("avatar_panel"):
            dpg.configure_item("avatar_panel", no_scrollbar=True)

        if has_tex and has_img_dims and dpg.does_item_exist("avatar_image"):
            # Scale image with aspect ratio within available area
            scale = min(avail_w / float(img_w), avail_h / float(img_h))
            tw = max(1, int(float(img_w) * scale))
            th = max(1, int(float(img_h) * scale))
            dpg.configure_item("avatar_image", width=tw, height=th, show=True)

            # Hide/neutralize drawlist so it doesn't add height
            if dpg.does_item_exist("avatar_draw"):
                dpg.configure_item("avatar_draw", width=int(avail_w), height=int(avail_h), show=False)
                dpg.delete_item("avatar_draw", children_only=True)
        else:
            # No image → use fallback glyph on the drawlist, hide image
            if dpg.does_item_exist("avatar_image"):
                dpg.configure_item("avatar_image", show=False)
            if dpg.does_item_exist("avatar_draw"):
                dpg.configure_item("avatar_draw", width=int(avail_w), height=int(avail_h), show=True)
                _fallback_draw(int(avail_w), int(avail_h))
    except Exception:
        pass
