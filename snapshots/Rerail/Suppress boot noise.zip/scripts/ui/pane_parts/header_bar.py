﻿"""Header Bar pane (authoritative)."""
from __future__ import annotations
from typing import Optional
import dearpygui.dearpygui as dpg

# Match the state colors used elsewhere
_STATE_COLORS = {
    "SLEEPING":  (128, 128, 128, 255),
    "WAKING":    (255, 165,   0, 255),
    "LISTENING": ( 70, 130, 180, 255),
    "THINKING":  (255, 215,   0, 255),
    "SPEAKING":  (  0, 200, 100, 255),
}
_DEFAULT = (200, 200, 200, 255)

def build(log_path: Optional[str] = None) -> None:
    """
    Create the header row if it does not exist yet.
    Tags used elsewhere: state_dot_circle, state_label, hb_label, tone_label, sarcasm_label, tailing_label.
    Safe to call multiple times.
    """
    try:
        if dpg.does_item_exist("header_row"):
            return
        if not dpg.does_item_exist("root"):
            return  # panes will create it; we only attach under existing "root"

        with dpg.group(parent="root", tag="header_row", horizontal=True):
            dpg.add_text("Piper GUI", tag="title_label")
            dpg.add_spacer(width=16)
            with dpg.drawlist(width=14, height=14, tag="state_dot_draw"):
                dpg.draw_circle(center=(7, 7), radius=6, color=(0, 0, 0, 0),
                                fill=_DEFAULT, tag="state_dot_circle")
            dpg.add_spacer(width=6)
            dpg.add_text("State: SLEEPING", tag="state_label")
            dpg.add_spacer(width=12); dpg.add_text("·"); dpg.add_spacer(width=8)
            dpg.add_text("-", tag="hb_label")  # heartbeat text
            dpg.add_spacer(width=12); dpg.add_text("·"); dpg.add_spacer(width=8)
            dpg.add_text("Tone: neutral", tag="tone_label")
            dpg.add_spacer(width=12); dpg.add_text("·"); dpg.add_spacer(width=8)
            dpg.add_text("Sarcasm: off", tag="sarcasm_label")
            dpg.add_spacer(width=12); dpg.add_text("·"); dpg.add_spacer(width=8)
            dpg.add_text(f"Tailing: {str(log_path) if log_path else ''}", tag="tailing_label")
    except Exception:
        pass

def refresh(
    state_text: str,
    heartbeat_text: str,
    tone_text: str,
    sarcasm_text: str,
    tailing_text: str,
) -> None:
    """Update header labels; inputs are already composed strings."""
    try:
        if dpg.does_item_exist("state_label"):
            dpg.set_value("state_label", state_text)
        if dpg.does_item_exist("hb_label"):
            dpg.set_value("hb_label", heartbeat_text)
        if dpg.does_item_exist("tone_label"):
            dpg.set_value("tone_label", tone_text)
        if dpg.does_item_exist("sarcasm_label"):
            dpg.set_value("sarcasm_label", sarcasm_text)
        if dpg.does_item_exist("tailing_label"):
            dpg.set_value("tailing_label", tailing_text)
    except Exception:
        pass

def set_state_dot(state_name: str) -> None:
    """Set the dot color and ensure the state label matches."""
    try:
        color = _STATE_COLORS.get(str(state_name), _DEFAULT)
        if dpg.does_item_exist("state_dot_circle"):
            dpg.configure_item("state_dot_circle", fill=color)
        if dpg.does_item_exist("state_label"):
            dpg.set_value("state_label", f"State: {state_name}")
    except Exception:
        pass

def set_heartbeat(text: str) -> None:
    """Update the heartbeat label."""
    try:
        if dpg.does_item_exist("hb_label"):
            dpg.set_value("hb_label", text)
    except Exception:
        pass
