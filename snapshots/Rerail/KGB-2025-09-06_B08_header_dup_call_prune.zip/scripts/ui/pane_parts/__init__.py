# pane_parts package — lazy exports only

def avatar_post_layout_fix(*args, **kwargs):
    from .avatar_pane import post_layout_fix
    return post_layout_fix(*args, **kwargs)

def avatar_resize(*args, **kwargs):
    try:
        from .avatar_pane import resize
    except Exception:
        return None
    return resize(*args, **kwargs)
