from __future__ import annotations
import dearpygui.dearpygui as dpg

def ensure_pane_theme() -> None:
    """Ensure any minimal pane theme exists (safe no-op if already present)."
    """
    try:
        # If a global theme tag is already there, we're done.
        if dpg.does_item_exist("pane_theme"):
            return

        # Create a minimal theme that doesn't alter colors unless you had one before.
        # This preserves behavior while providing a stable tag for future styling.
        with dpg.theme(tag="pane_theme"):
            with dpg.theme_component(dpg.mvAll):
                pass
        # Optionally bind it to root if your build expects it.
        if dpg.does_item_exist("root"):
            try:
                dpg.bind_theme("pane_theme")
            except Exception:
                pass
    except Exception:
        pass
