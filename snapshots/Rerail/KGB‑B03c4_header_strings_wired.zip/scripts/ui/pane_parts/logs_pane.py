﻿"""Logs pane (stub)."""
from __future__ import annotations
import dearpygui.dearpygui as dpg

def build() -> None:
    pass

def refresh(text: str, autoscroll_on: bool) -> None:
    pass
