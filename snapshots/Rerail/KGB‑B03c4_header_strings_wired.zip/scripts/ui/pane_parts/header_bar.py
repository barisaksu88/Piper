﻿"""Header Bar pane (stub)."""
from __future__ import annotations
import dearpygui.dearpygui as dpg
from typing import Optional

def build(log_path: Optional[str] = None) -> None:
    pass

def refresh(
    state_text: str,
    heartbeat_text: str,
    tone_text: str,
    sarcasm_text: str,
    tailing_text: str,
) -> None:
    """Update header labels if they exist (tags from current panes.py)."""
    try:
        if dpg.does_item_exist("state_label"):
            dpg.set_value("state_label", state_text)
        if dpg.does_item_exist("hb_label"):
            dpg.set_value("hb_label", heartbeat_text)
        if dpg.does_item_exist("tone_label"):
            dpg.set_value("tone_label", tone_text)
        if dpg.does_item_exist("sarcasm_label"):
            dpg.set_value("sarcasm_label", sarcasm_text)
        if dpg.does_item_exist("tailing_label"):
            dpg.set_value("tailing_label", tailing_text)
    except Exception:
        pass

def set_heartbeat(text: str) -> None:
    """Update the heartbeat label in the header if present."""
    try:
        if dpg.does_item_exist("hb_label"):
            dpg.set_value("hb_label", text)
    except Exception:
        pass
