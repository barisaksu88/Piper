# C:\Piper\scripts\services\cli_prompt.py
# T‑Core03: Minimal prompt/line service (no persona, behavior-preserving)

from __future__ import annotations

def current_prompt() -> str:
    """
    Return the CLI prompt string. Keep it identical to legacy behavior.
    """
    return "> "

def format_line(text: str, tone: str = "info") -> str:
    """
    Placeholder formatter. Intentionally a no-op so output stays unchanged.
    (Persona styling happens elsewhere; this just reserves the hook.)
    """
    return text
