﻿"""Header Bar pane (stub)."""
from __future__ import annotations
import dearpygui.dearpygui as dpg
from typing import Optional

def build(log_path: Optional[str] = None) -> None:
    """
    Create the header row if it does not exist yet.
    Tags:
      header_row, state_label, hb_label, tone_label, sarcasm_label, tailing_label
    Safe to call multiple times (no-ops if header exists).
    """
    try:
        if dpg.does_item_exist("header_row"):
            return

        # We expect a 'root' window to exist; bail if not
        if not dpg.does_item_exist("root"):
            return

        with dpg.group(parent="root", tag="header_row", horizontal=True):
            dpg.add_text("State: ?", tag="state_label")
            dpg.add_spacer(width=12)
            dpg.add_text("0", tag="hb_label")  # heartbeat (parked)
            dpg.add_spacer(width=12)
            dpg.add_text("Tone: neutral", tag="tone_label")
            dpg.add_spacer(width=12)
            dpg.add_text("Sarcasm: off", tag="sarcasm_label")
            dpg.add_spacer(width=12)
            tailing = f"Tailing: {log_path}" if log_path else "Tailing:"
            dpg.add_text(tailing, tag="tailing_label")
    except Exception:
        pass

def refresh(
    state_text: str,
    heartbeat_text: str,
    tone_text: str,
    sarcasm_text: str,
    tailing_text: str,
) -> None:
    """Update header labels if they exist (tags from current panes.py)."""
    try:
        if dpg.does_item_exist("state_label"):
            dpg.set_value("state_label", state_text)
        if dpg.does_item_exist("hb_label"):
            dpg.set_value("hb_label", heartbeat_text)
        if dpg.does_item_exist("tone_label"):
            dpg.set_value("tone_label", tone_text)
        if dpg.does_item_exist("sarcasm_label"):
            dpg.set_value("sarcasm_label", sarcasm_text)
        if dpg.does_item_exist("tailing_label"):
            dpg.set_value("tailing_label", tailing_text)
    except Exception:
        pass

def set_heartbeat(text: str) -> None:
    """Update the heartbeat label in the header if present."""
    try:
        if dpg.does_item_exist("hb_label"):
            dpg.set_value("hb_label", text)
    except Exception:
        pass
