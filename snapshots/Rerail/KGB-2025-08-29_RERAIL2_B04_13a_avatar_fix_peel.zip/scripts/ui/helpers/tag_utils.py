"""
B04.3 Tag utilities — extracted from ui/panes.py
No new literals; pure helpers.
"""
import dearpygui.dearpygui as dpg

def first_existing_tag(candidates):
    """Return the first tag from candidates that exists in DPG, else None."""
    for t in candidates:
        try:
            if dpg.does_item_exist(t):
                return t
        except Exception:
            pass
    return None
