﻿"""Header Bar pane (authoritative)."""
from __future__ import annotations
from typing import Optional
import dearpygui.dearpygui as dpg
# Match the state colors used elsewhere
_STATE_COLORS = {
    "SLEEPING":  (128, 128, 128, 255),
    "WAKING":    (255, 165,   0, 255),
    "LISTENING": ( 70, 130, 180, 255),
    "THINKING":  (255, 215,   0, 255),
    "SPEAKING":  (  0, 200, 100, 255),
}
_DEFAULT = (200, 200, 200, 255)

def build(log_path: Optional[str] = None) -> None:
    """
    Create the header row if it does not exist yet.
    Tags used elsewhere: state_dot_circle, state_label, hb_label, tone_label, sarcasm_label, tailing_label.
    Safe to call multiple times.
    """
    try:
        if dpg.does_item_exist("header_row"):
            return
        if not dpg.does_item_exist("root"):
            return  # panes will create it; we only attach under existing "root"

        with dpg.group(parent="root", tag="header_row", horizontal=True):
            dpg.add_text("Piper GUI", tag="title_label")
            dpg.add_spacer(width=16)
            with dpg.drawlist(width=14, height=14, tag="state_dot_draw"):
                dpg.draw_circle(center=(7, 7), radius=6, color=(0, 0, 0, 0),
                                fill=_DEFAULT, tag="state_dot_circle")
            dpg.add_spacer(width=6)
            dpg.add_text("State: SLEEPING", tag="state_label")
            dpg.add_spacer(width=12); dpg.add_text("·"); dpg.add_spacer(width=8)
            dpg.add_text("-", tag="hb_label")  # heartbeat text
            dpg.add_spacer(width=12); dpg.add_text("·"); dpg.add_spacer(width=8)
            dpg.add_text("Tone: neutral", tag="tone_label")
            dpg.add_spacer(width=12); dpg.add_text("·"); dpg.add_spacer(width=8)
            dpg.add_text("Sarcasm: off", tag="sarcasm_label")
            dpg.add_spacer(width=12); dpg.add_text("·"); dpg.add_spacer(width=8)
            dpg.add_text(f"Tailing: {str(log_path) if log_path else ''}", tag="tailing_label")
    except Exception:
        pass

def refresh(state_text: str,
            heartbeat_text: str,
            tone_text: str,
            sarcasm_text: str,
            tailing_text: str,
            state_name: str | None = None) -> None:
    """
    Update header labels AND recolor the state dot.
    If state_name is not provided, derive it from state_text.
    """
    import dearpygui.dearpygui as dpg

    # --- keep your existing label updates exactly as they are ---
    try: dpg.set_value("state_label", state_text)
    except Exception: pass
    try: dpg.set_value("heartbeat_text", heartbeat_text)
    except Exception: pass
    try: dpg.set_value("tone_text", tone_text)
    except Exception: pass
    try: dpg.set_value("sarcasm_text", sarcasm_text)
    except Exception: pass
    try: dpg.set_value("tailing_text", tailing_text)
    except Exception: pass

    # --- NEW: normalize the state name and force dot recolor every refresh ---
    if state_name is None or not str(state_name).strip():
        # derive from "State: WAKING · ..."
        try:
            _raw = (state_text or "")
            _after_colon = _raw.split(":", 1)[-1]
            _first_field = _after_colon.split("·", 1)[0]
            name = _first_field.strip().upper()
        except Exception:
            name = ""
    else:
        name = str(state_name).strip().upper()

    try:
        from . import header_bar as _hb  # self-import ok here
        _hb.set_state_dot(name)
    except Exception:
        pass
    """Update header labels; inputs are already composed strings."""
    try:
        if dpg.does_item_exist("state_label"):
            dpg.set_value("state_label", state_text)
        if dpg.does_item_exist("hb_label"):
            dpg.set_value("hb_label", heartbeat_text)
        if dpg.does_item_exist("tone_label"):
            dpg.set_value("tone_label", tone_text)
        if dpg.does_item_exist("sarcasm_label"):
            dpg.set_value("sarcasm_label", sarcasm_text)
        if dpg.does_item_exist("tailing_label"):
            dpg.set_value("tailing_label", tailing_text)
    except Exception:
        pass

# at module top (once)
_DOT_LAST = None

# at module top (once)
_DOT_LAST = None

def _find_dot_ids():
    """Return list of candidate dot item tags that may exist in different builds."""
    return [
        "state_dot_circle",
        "state_dot",           # older alias
        "hb_state_dot",        # some branches used this
    ]

def set_state_dot(state_name: str) -> None:
    """Update dot color and header label, only when changed. Robust across aliases."""
    import dearpygui.dearpygui as dpg
    global _DOT_LAST
    name = (state_name or "").strip().upper()
    if _DOT_LAST == name:
        return

    # Use your existing mapping if defined; else a safe default palette
    colors = globals().get("STATE_COLORS", {
        "SLEEPING":  (96, 96, 96, 255),
        "WAKING":    (255, 190,  60, 255),
        "LISTENING": (90, 160, 255, 255),
        "THINKING":  (160, 120, 255, 255),
        "SPEAKING":  ( 80, 220, 120, 255),
    })
    color = colors.get(name, colors.get("SLEEPING", (96, 96, 96, 255)))

    # Update "State: …" label if present
    try:
        dpg.set_value("state_label", f"State: {name}")
    except Exception:
        pass

    # Paint any existing circle aliases (both fill and outline for DPG quirks)
    for DOT in _find_dot_ids():
        try:
            dpg.configure_item(DOT, fill=color)
        except Exception:
            pass
        try:
            dpg.configure_item(DOT, color=color)
        except Exception:
            pass

    _DOT_LAST = name
def set_heartbeat(text: str) -> None:
    """Update the heartbeat label."""
    try:
        if dpg.does_item_exist("hb_label"):
            dpg.set_value("hb_label", text)
    except Exception:
        pass
