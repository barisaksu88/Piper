# scripts/core/bg_poller.py
from __future__ import annotations
import threading
import time
from typing import Any, Optional, Tuple


