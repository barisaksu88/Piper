﻿"""
B04.2 Scroll utilities — extracted from ui/panes.py
No new literals; pure helpers.
"""
import dearpygui.dearpygui as dpg
from typing import Iterable, Union, Optional

__all__ = [
    "is_at_bottom",
    "scroll_to_bottom_next_frame",
    "update_autoscroll_badges",
    ]

def is_at_bottom(tag: str, threshold: int = 48) -> bool:
    """Return True if scrollable region is near bottom within threshold px."""
    if not tag:
        return False
    try:
        cur = dpg.get_y_scroll(tag)
        mx = dpg.get_y_scroll_max(tag)
        return (mx - cur) <= threshold
    except Exception:
        return False

def scroll_to_bottom_next_frame(tag_or_tags: Union[Optional[str], Iterable[Optional[str]]]):
    """Scroll one or more containers to bottom on the next frame (single callback)."""
    try:
        # normalize input to a flat list without Nones/empties
        if isinstance(tag_or_tags, (list, tuple, set)):
            tags = [t for t in tag_or_tags if t]
        else:
            tags = [tag_or_tags] if tag_or_tags else []

        if not tags:
            return

        def _apply(_s=None, _a=None):
            for t in tags:
                try:
                    dpg.set_y_scroll(t, dpg.get_y_scroll_max(t))
                except Exception:
                    pass

        dpg.set_frame_callback(dpg.get_frame_count() + 1, _apply)
    except Exception:
        pass
    
def update_autoscroll_badges(chat_scroll_tag, chat_badge_tag, log_scroll_tag, log_badge_tag) -> None:
    """
    Show/hide tiny 'autoscroll' badges based on whether each pane is at bottom.
    Safe no-op if tags are missing.
    """
    try:
        if chat_scroll_tag and chat_badge_tag:
            dpg.configure_item(chat_badge_tag, show=not is_at_bottom(chat_scroll_tag))
    except Exception:
        pass
    try:
        if log_scroll_tag and log_badge_tag:
            dpg.configure_item(log_badge_tag, show=not is_at_bottom(log_scroll_tag))
    except Exception:
        pass