﻿"""Avatar pane — build + resize + fallback drawing (mutually exclusive surfaces)."""
from __future__ import annotations
from scripts.ui.layout_constants import L
import dearpygui.dearpygui as dpg

# --- B02 hotfix: ensure avatar image scales correctly after layout settles ---
def post_layout_fix(img_tag=None, container_tag=None):
    """
    After layout settles, size the avatar image to CONTAIN within its panel
    (no over-zoom), preserving aspect ratio. Runs twice to catch late layout.
    Safe no-op if tags are missing.
    """
    try:
        import dearpygui.dearpygui as dpg
    except Exception:
        return

