﻿# scripts/ui/components/logs_pane.py
from __future__ import annotations
import dearpygui.dearpygui as dpg
from typing import Optional

LOG_SCROLL_CANDIDATES = ["log_scroll", "logs_scroll", "log_view", "logs_view"]
LOG_TEXT_CANDIDATES   = ["log_text", "logs_text", "log_buffer"]

def _find_tag(cands):
    for t in cands:
        try:
            if dpg.does_item_exist(t):
                return t
        except Exception:
            pass
    return None

def build(parent: Optional[str] = None) -> None:
    """Idempotent: ensure a scroll container + a text sink exist for logs."""
    try:
        scroll = _find_tag(LOG_SCROLL_CANDIDATES)
        if not scroll:
            if parent is None:
                parent = "root" if dpg.does_item_exist("root") else None
            if parent is not None:
                with dpg.child_window(parent=parent, tag="logs_scroll", autosize_x=True, autosize_y=True):
                    pass
                scroll = "logs_scroll"
        text = _find_tag(LOG_TEXT_CANDIDATES)
        if not text and scroll and dpg.does_item_exist(scroll):
            dpg.add_text("", tag="log_text", parent=scroll)
    except Exception:
        pass

def refresh(text: str, autoscroll_on: bool) -> None:
    """Update logs text; autoscroll is handled centrally by refresh_core."""
    try:
        if dpg.does_item_exist("log_text"):
            dpg.set_value("log_text", text)
        # NOTE: no direct set_y_scroll here; refresh_core schedules the next-frame scroll.
    except Exception:
        pass