﻿# Placeholder for structured logging later.
def log(msg: str):
    print(msg)
__all__ = ["log"]

