# AUTO-GENERATED: B04 thin wrapper (no fallback)
from __future__ import annotations
try:
    from ._app_gui_entry_impl import run as run  # post-split impl
except Exception:
    from .app_gui_entry import run as run        # Compatibility shim for older panes imports. Do NOT use in new code. Scheduled for removal post-Phase B04.

if __name__ == "__main__":
    run()
