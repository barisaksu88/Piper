# C:\Piper\scripts\ui\heartbeat.py
from __future__ import annotations
import time
import dearpygui.dearpygui as dpg

class _Heartbeat:
    """Independent header ticker with a single .reset() signal."""
    def __init__(self) -> None:
        self._label_tag = "hb_label"
        self._interval_frames = 60   # ~1s at 60fps; caller sets via start()
        self._last_ts: float | None = None

    # ---- public API ----
    def start(self, poll_sec: float = 0.25, label_tag: str = "hb_label") -> None:
        self._label_tag = label_tag or "hb_label"
        self._interval_frames = max(1, int(max(0.05, float(poll_sec)) * 60))
        self._arm()

    def reset(self) -> None:
        """Signal: set 'now' and paint immediately."""
        self._last_ts = time.time()
        self._paint()

    # ---- internals ----
    def _arm(self) -> None:
        try:
            dpg.set_frame_callback(dpg.get_frame_count() + 1, self._tick)
        except Exception:
            pass

    def _human(self) -> str:
        if self._last_ts is None:
            return "Last update: -"
        try:
            delta = int(time.time() - self._last_ts)
        except Exception:
            delta = 0
        return f"Last update: {delta}s ago"

    def _paint(self) -> None:
        try:
            dpg.set_value(self._label_tag, self._human())
        except Exception:
            pass

    def _tick(self, sender=None, app_data=None) -> None:
        try:
            self._paint()
        finally:
            try:
                dpg.set_frame_callback(
                    dpg.get_frame_count() + self._interval_frames, self._tick
                )
            except Exception:
                pass

# singleton instance
heartbeat = _Heartbeat()
