﻿# DEV NOTE — B04 size cap
# Target size ≤ 150 lines before Phase H closure.
# No behavior changes here; only refactors and module peels count toward cap.

# DEV NOTE (B04 Size Target): keep this file ≤150 lines by delegating to ui/dpg_app.py and ui/pane_parts/*. 
# Do not add new logic here; only thin entry glue and argument parsing may remain.
# KGB target: KGB-2025-08-29_RERAIL2_B04_size_note_app_gui_entry

# LAYOUT/LOOK Rails – LL-R03 thin bootstrap
# - Theme lives in ui/theme.py
# - Tailer lives in ui/tailer.py
# - Panes (init_ui / refresh_ui / calibrate_to_viewport) live in ui/panes.py
# - This file wires them together + keeps minimal GUI-specific state

from __future__ import annotations

# --- DEV INPUT (IN01) imports: safe when flag is off
import os
import re
from collections import deque
from pathlib import Path
from datetime import datetime

import dearpygui.dearpygui as dpg
# Theme hook (supports both project-root and scripts-root launches)
try:
    from scripts.ui.theme import apply_theme_if_enabled   # running from C:\Piper
except Exception:
    from ui.theme import apply_theme_if_enabled           # running from C:\Piper\scripts

# Persona styling passthrough (Services)
try:
    from scripts.services.persona_adapter import style_line
except Exception:
    from services.persona_adapter import style_line

# Tailer + Panes adapters
try:
    from scripts.ui.tailer import Tailer
except Exception:
    from ui.tailer import Tailer

try:
    from scripts.ui.panes import init_ui, refresh_ui, calibrate_to_viewport, set_hb_text
except Exception:
    from ui.panes import init_ui, refresh_ui, calibrate_to_viewport, set_hb_text

# Try both package paths for ipc_child (depends on how you run modules)
try:
    from scripts.ui.ipc_child import spawn_cli  # our new helper (IN01)
except Exception:
    try:
        from ui.ipc_child import spawn_cli
    except Exception:
        spawn_cli = None  # type: ignore
        
# Dev tools module (flag-gated)
try:
    from scripts.ui.dev_tools import attach_dev_tools
except Exception:
    try:
        from ui.dev_tools import attach_dev_tools
    except Exception:
        attach_dev_tools = None  # type: ignore
# Heartbeat singleton for header timer
try:
    from scripts.ui.heartbeat import heartbeat
except Exception:
    from ui.heartbeat import heartbeat  # fallback when running from /scripts directly

# layout constants
try:
    from scripts.ui.layout_constants import L  # when launched as `python -m scripts...`
except Exception:
    from ui.layout_constants import L          # fallback if run from within scripts/

# Local pane updater (we’re inlining for stability; peel later in B04)
_update_panes = None  # will be defined below
_set_hb_text = None   # will be defined below


# Handle to the child CLI (dev-only). None when flag is off or unavailable.
_PIPER_CLI_CHILD = None
# -------------------------------
# Config (UI-only)
# -------------------------------
LOG_PATH = os.environ.get("PIPER_CORE_LOG", r"C:\Piper\run\core.log")
TAIL_FROM_START = os.environ.get("PIPER_UI_TAIL_FROM_START", "0") == "1"
POLL_INTERVAL_SEC = float(os.environ.get("PIPER_UI_POLL_SEC", "0.25"))
STATE_DWELL_SEC = float(os.environ.get("PIPER_UI_STATE_DWELL_SEC", "1.1"))
SPEAKING_IDLE_SEC = float(os.environ.get("PIPER_UI_SPEAKING_IDLE_SEC", "3.5"))

# -------------------------------
# Buffers & State (UI-only)
# -------------------------------
LOG_MAX_LINES = 1200
CHAT_MAX_LINES = 600

from collections import deque
log_buffer  = deque(maxlen=LOG_MAX_LINES)
chat_buffer = deque(maxlen=CHAT_MAX_LINES)

current_state = "SLEEPING"
_last_state_change_ts = 0.0  # UI timing sentinel

# Persona read-outs (UI-only, read-only)
persona_tone = os.environ.get("PIPER_PERSONA_TONE", "neutral").strip().lower()
persona_sarcasm = (os.environ.get("PIPER_PERSONA_SARCASM", "off").strip().lower() in ("1","on","true","yes"))

# State & timing
state_queue = deque()
last_update_ts: datetime | None = None
last_display_switch: datetime | None = None
# Heartbeat start instant (for the header ticker only)
heartbeat_start_ts: datetime | None = None
# Dirty flags (set True when NEW line appended; cleared after refresh)
_chat_dirty = False
_log_dirty  = False

# Render tick nudge
_refresh_needed = False

# RR03: last `[STATE]` line printed to Logs (for de‑dupe)
_last_state_log: str | None = None

# UI readiness guard (avoid painting before widgets exist)
_UI_READY = False
# -------------------------------
# Classifiers (robust parsing)
# -------------------------------
AVAILABLE_STATES_BANNER_RE = re.compile(r"\[STATE\].*available_states=", re.IGNORECASE)
STATE_RE = re.compile(
    r"\[STATE\]\s*(?:([A-Za-z_]+)\s*(?:→|->)\s*([A-Za-z_]+)|([A-Za-z_]+))",
    re.IGNORECASE
)
# Valid Piper states (whitelist to avoid parsing junk like "[STATE]TE]")
VALID_STATES = {"SLEEPING", "WAKING", "LISTENING", "THINKING", "SPEAKING"}
STATE_WORD_RE = re.compile(r"\b(sleeping|waking|listening|thinking|speaking)\b", re.IGNORECASE)
SLEEP_HINT_RE = re.compile(
    r"(going to sleep|back to sleep|piper is (now )?sleeping|^sleep$|sleeping\.\.\.)",
    re.IGNORECASE,
)

# Persona toggle lines (from CLI/log)
PERSONA_RE  = re.compile(r"\[PERSONA\].*?\btone\s*=\s*([A-Za-z]+).*?\bsarcasm\s*=\s*(on|off|true|false|1|0)", re.IGNORECASE)
TONE_RE     = re.compile(r"\[TONE\]\s*([A-Za-z]+)", re.IGNORECASE)
SARCASM_RE  = re.compile(r"\[SARCASM\]\s*(on|off|true|false|1|0)", re.IGNORECASE)

# -------------------------------
# Small helpers
# -------------------------------
def _tone_for_line(line: str) -> str:
    low = (line or "").lower()
    if "[state]" in low:
        return "status"
    if "[event]" in low or "[tts]" in low:
        return "info"
    if "error" in low or "[err]" in low or "traceback" in low:
        return "error"
    return "info"

def _badge_for_logs(line: str) -> str:
    """
    Normalize common log tags and prevent artifacts like '[STATE]TE]'.
    - Case-insensitive normalization for [STATE]/[EVENT]/[TTS]/[ERR]
    - Pulls [STATE] to the front if it appears later in the line
    - Ensures errors/tracebacks are [ERR]-prefixed
    """
    s = (line or "").strip()

    # Normalize tags (case-insensitive)
    s = re.sub(r"\[state\]", "[STATE]", s, flags=re.IGNORECASE)
    s = re.sub(r"\[event\]", "[EVT]", s, flags=re.IGNORECASE)
    s = re.sub(r"\[tts\]", "[TTS]", s, flags=re.IGNORECASE)
    s = re.sub(r"\[err\]", "[ERR]", s, flags=re.IGNORECASE)

    # Clean historical artifact like '[STATE]TE]'
    s = s.replace("[STATE]TE]", "[STATE]")

    low = s.lower()

    # Error/exception lines: force [ERR] prefix once
    if ("traceback" in low) or ("error" in low) or ("exception" in low):
        if not s.startswith("[ERR]"):
            s = f"[ERR] {s}"
        return s

    # If there's a [STATE] tag not at the start, pull it forward once
    if "[STATE]" in s and not s.startswith("[STATE]"):
        s = re.sub(r"^.*?\[STATE\]", "[STATE]", s, count=1)

    return s

def _compose(buf: deque) -> str:
    return "\n".join(buf)

def _human_when(ts: datetime | None) -> str:
    if not ts:
        return "Last update: -"
    delta = (datetime.now() - ts).total_seconds()
    return f"Last update: {int(delta)}s ago"

def _advance_state_if_needed():
    """Advance state_queue head after dwell time so transient states are visible."""
    global last_display_switch, _refresh_needed

    now = datetime.now()

    # Initialize queue with the current state and force a refresh
    if not state_queue:
        state_queue.append(current_state)
        last_display_switch = now
        _refresh_needed = True
        return

    head = state_queue[0]

    # Pop head after it has been displayed for STATE_DWELL_SEC and differs from current_state
    if head != current_state:
        # Guard if last_display_switch somehow wasn't set
        last_sw = last_display_switch or now
        if (now - last_sw).total_seconds() >= STATE_DWELL_SEC:
            state_queue.popleft()
            last_display_switch = now
            _refresh_needed = True  # <-- ensure header redraw on next tick

def _is_chat_line(line: str) -> bool:
    """
    Chat pane shows ONLY Piper's spoken output.
    Accept either explicit [TTS] or lines that start with '>'.
    """
    s = (line or "")
    if not s.strip():
        return False
    if s.startswith("? ") or "Tailing:" in s or s.startswith("[GUI]"):
        return False
    if "[TTS]" in s:
        return True
    if s.lstrip().startswith(">"):
        return True
    return False

# -------------------------------
# Tailer → GUI ingestion
# -------------------------------
def _consume_line(line: str):
    """Ingest one log line; route to Chat or Logs; request UI refresh."""
    global last_update_ts, current_state, _chat_dirty, _log_dirty, _refresh_needed, _last_state_log, hb_seconds

    # Normalize
    if line.endswith("\n"):
        line = line[:-1]
    s = (line or "")
    low = s.lower()

    # Drop noisy CLI banner like: "[STATE]TE] available_states=..."
    if AVAILABLE_STATES_BANNER_RE.search(s):
        return

    # Count only meaningful lines for the header heartbeat
    is_noise_for_clock = ("[tail]" in low) or low.startswith("[dev][trace]") or s.startswith("[GUI]")
    if not is_noise_for_clock:
        last_update_ts = datetime.now()
        heartbeat.reset()  # ← reset timer on meaningful line

    # Persona toggles (read-only display)
    try:
        pm = PERSONA_RE.search(s)
        if pm:
            t = pm.group(1).strip().lower()
            sv = pm.group(2).strip().lower()
            if t:
                globals()["persona_tone"] = t
            if sv:
                globals()["persona_sarcasm"] = (sv in ("on", "true", "1", "yes"))
            _refresh_needed = True
        else:
            tm = TONE_RE.search(s)
            if tm:
                globals()["persona_tone"] = tm.group(1).strip().lower()
                _refresh_needed = True
            sm = SARCASM_RE.search(s)
            if sm:
                sv = sm.group(1).strip().lower()
                globals()["persona_sarcasm"] = (sv in ("on", "true", "1", "yes"))
                _refresh_needed = True
    except Exception:
        pass

    # --- State detection (robust + heuristics) ---
    has_state_tag = "[STATE]" in s  # used to avoid duplicate echo
    new_state = None

    m = STATE_RE.search(s)
    if m:
        if m.group(2):       # OLD -> NEW
            new_state = m.group(2)
        elif m.group(3):     # NEW
            new_state = m.group(3)
    else:
        mw = STATE_WORD_RE.search(s)
        if mw:
            new_state = mw.group(1)
        elif SLEEP_HINT_RE.search(s):
            new_state = "SLEEPING"
        elif s.lstrip().startswith(">"):
            new_state = "SPEAKING"

        # Apply state if valid and changed (whitelist to block junk like "TE")
    if new_state:
        candidate = (new_state or "").strip().upper()
        if candidate in VALID_STATES and candidate != current_state:
            old_state = current_state
            current_state = candidate
            # record when WAKING began (for UI dwell advance)
            try:
                import time as _t
                if current_state == "WAKING":
                    globals()["_waking_seen_ts"] = _t.time()
                else:
                    # clear stamp if we leave WAKING
                    globals().pop("_waking_seen_ts", None)
            except Exception:
                pass

            # stamp the last-change time
            import time as _t
            globals()["_last_state_change_ts"] = _t.time()

            # Queue once
            if not state_queue or state_queue[-1] != candidate:
                state_queue.append(candidate)

            # If the incoming line didn't have a [STATE] tag, synthesize one for logs
            if not has_state_tag:
                syn = f"[STATE] {old_state} -> {candidate}"
                log_buffer.append(syn)
                _log_dirty = True

            # Mark repaint and hand off the new state to the UI thread
            # UI-thread: apply pending state to dot + label once
            pending = globals().pop("_pending_state_for_ui", None)
            if pending:
                current_state = str(pending)  # <-- make the closure var current
                try:
                    try:
                        from scripts.ui.pane_parts import header_bar as _hb
                    except Exception:
                        from ui.pane_parts import header_bar as _hb
                    _hb.set_state_dot(current_state)  # updates dot + "State: …"
                except Exception:
                    pass

            _refresh_needed = True
            
            # Update header state & dot immediately
            try:
                try:
                    from scripts.ui.pane_parts import header_bar as _hb
                except Exception:
                    from ui.pane_parts import header_bar as _hb
                _hb.set_state_dot(current_state)
            except Exception:
                pass
            if not state_queue or state_queue[-1] != candidate:
                state_queue.append(candidate)
            if not has_state_tag:
                syn = f"[STATE] {old_state} -> {candidate}"
                if _last_state_log != syn:
                    try:
                        log_buffer.append(style_line(syn, tone="status"))
                    except Exception:
                        log_buffer.append(syn)
                    _last_state_log = syn
                    _log_dirty = True
            _refresh_needed = True

    # --- Routing to Chat / Logs ---
    try:
        is_spoken = ("[TTS]" in s) or s.lstrip().startswith(">")
        is_status = any(tag in s for tag in (
            "[STATE]", "[EVENT]", "[Tail]", "[GUI]",
            "[PERSONA]", "[TONE]", "[SARCASM]", "[DEV]"
        ))
        is_error = ("error" in low) or ("[err]" in low) or ("traceback" in low)

        if is_spoken:
            chat_buffer.append(style_line(s.strip(), tone=_tone_for_line(s)))
            _chat_dirty = True

        if is_status or is_error:
            line_for_logs = _badge_for_logs(s)
            if "[STATE]" in line_for_logs:
                if (_last_state_log or "") != line_for_logs.strip():
                    try:
                        log_buffer.append(style_line(line_for_logs, tone=_tone_for_line(s)))
                    except Exception:
                        log_buffer.append(line_for_logs)
                    _last_state_log = line_for_logs.strip()
                    _log_dirty = True
            else:
                try:
                    log_buffer.append(style_line(line_for_logs, tone=_tone_for_line(s)))
                except Exception:
                    log_buffer.append(line_for_logs)
                _log_dirty = True

    except Exception:
        if ("[TTS]" in s) or s.lstrip().startswith(">"):
            chat_buffer.append(s.strip()); _chat_dirty = True
        if any(tag in s for tag in (
            "[STATE]", "[EVENT]", "[Tail]", "[GUI]",
            "[PERSONA]", "[TONE]", "[SARCASM]"
        )) or ("error" in low):
            log_buffer.append(_badge_for_logs(s)); _log_dirty = True

    while len(chat_buffer) > CHAT_MAX_LINES:
        chat_buffer.popleft()
    while len(log_buffer) > LOG_MAX_LINES:
        log_buffer.popleft()

    _refresh_needed = True

# ---- Local pane/update helpers (B04 hold) ----
def _update_panes(*args, **kwargs):
    """Safely push current buffers to the UI."""
    try:
        from scripts.ui.panes import refresh_ui as _refresh_ui
    except Exception:
        try:
            from ui.panes import refresh_ui as _refresh_ui
        except Exception:
            _refresh_ui = None
    if _refresh_ui is None:
        return

    _g = globals()
    def _update_panes(*args, **kwargs):
        """Safely push current buffers to the UI."""
        try:
            from scripts.ui.panes import refresh_ui as _refresh_ui
        except Exception:
            try:
                from ui.panes import refresh_ui as _refresh_ui
            except Exception:
                _refresh_ui = None
        if _refresh_ui is None:
            return

        _g = globals()

        def _choose(*names, default=""):
            ...

        def _choose(*names, default=""):
            for n in names:
                if n in _g and _g.get(n) is not None:
                    return _g.get(n)
            return default

    # Use provided args if 6 were passed, otherwise pull from globals
    if len(args) >= 6:
        # Compose authoritative header every time (persona/state are module globals)
        state_text = f"State: {current_state} · Tone: {persona_tone} · Sarcasm: {'on' if persona_sarcasm else 'off'}"
        # dev-only trace + repaint nudge
        log_buffer.append(f"[DEV][TRACE] header_now tone={persona_tone} sarcasm={'on' if persona_sarcasm else 'off'}"); _log_dirty = True; _refresh_needed = True
    else:
        state_text = _choose("_state_text", "STATE_TEXT", default="")
        hb_text    = _choose("_hb_text", "HB_TEXT", default="")
        chat_text  = _choose("chat_buffer", "_chat_text", "CHAT_BUFFER", default=[])
        log_text   = _choose("log_buffer", "_log_text", "LOG_BUFFER", default=[])
        chat_dirty = True
        log_dirty  = True

    # Normalize buffers to strings
    from collections import deque
    if isinstance(chat_text, (list, tuple, deque)):
        chat_text = "\n".join(map(str, chat_text))
    if isinstance(log_text, (list, tuple, deque)):
        log_text = "\n".join(map(str, log_text))

    try:
        _refresh_ui(state_text, hb_text, chat_text, log_text, bool(chat_dirty), bool(log_dirty))
    except Exception:
        pass

def _set_hb_text(text: str):
    """Local passthrough to header heartbeat label."""
    try:
        from scripts.ui.panes import set_hb_text as __set
    except Exception:
        try:
            from ui.panes import set_hb_text as __set  # legacy fallback
        except Exception:
            __set = None
    if __set is None:
        return
    try:
        __set(text)
    except Exception:
        pass
# ---- end local helpers ----

def _on_tailer_status(msg: str):
    # Send tail/status notices to LOGS (not Chat), but DO NOT bump last_update_ts.
    global _log_dirty, _refresh_needed
    try:
        log_buffer.append(style_line(msg, tone="status"))
    except Exception:
        log_buffer.append(msg)
    _log_dirty = True
    _refresh_needed = True


def _on_tailer_error(msg: str):
    global _log_dirty, _refresh_needed, last_update_ts, hb_seconds
    try:
        log_buffer.append(style_line(msg, tone="error"))
    except Exception:
        log_buffer.append(msg)
    last_update_ts = datetime.now()
    heartbeat.reset()  # ← errors also reset timer
    _log_dirty = True
    _refresh_needed = True
# -------------------------------
# UI refresh scheduling
# -------------------------------
def schedule_recurring_update():
    """Frame tick: handle dwell/snap + repaint panes when needed.
    NOTE: Do NOT touch hb_label here; the heartbeat singleton owns it.
    """
    frames_per_tick = max(1, int(POLL_INTERVAL_SEC * 60))  # ~every POLL_INTERVAL_SEC

    def _tick(sender=None, app_data=None):
        try:
            # Maintain queued-state dwell progression
            _advance_state_if_needed()

            # Auto-snap from SPEAKING to SLEEPING after idle
            try:
                if current_state == "SPEAKING" and last_update_ts:
                    idle = (datetime.now() - last_update_ts).total_seconds()
                    if idle >= SPEAKING_IDLE_SEC:
                        globals()["current_state"] = "SLEEPING"
                        globals()["_refresh_needed"] = True
            except Exception:
                pass
            # Auto-advance: if we've been WAKING for a moment, move to LISTENING
            try:
                import time as _t
                last = globals().get("_last_state_change_ts", 0.0)
                if current_state == "WAKING":
                    if last and (_t.time() - last) >= 0.6:
                        globals()["current_state"] = "LISTENING"
                        globals()["_last_state_change_ts"] = _t.time()
                        try:
                            try:
                                from scripts.ui.pane_parts import header_bar as _hb
                            except Exception:
                                from ui.pane_parts import header_bar as _hb
                            _hb.set_state_dot("LISTENING")
                        except Exception:
                            pass
            except Exception:
                pass
                    # Auto-advance WAKING → LISTENING after a short dwell
            try:
                import time as _t
                if globals().get("current_state", "") == "WAKING":
                    ts = globals().get("_waking_seen_ts", 0.0)
                    if ts and (_t.time() - ts) >= 0.6:
                        globals()["current_state"] = "LISTENING"
                        # update dot/label immediately
                        try:
                            try:
                                from scripts.ui.pane_parts import header_bar as _hb
                            except Exception:
                                from ui.pane_parts import header_bar as _hb
                            _hb.set_state_dot("LISTENING")
                        except Exception:
                            pass
            except Exception:
                pass

            # Redraw panes only if something changed (chat/log/state/persona)
            if _refresh_needed:
                _update_panes()

            # DO NOT call set_hb_text() or set_value("hb_label", ...) here.
            # The heartbeat singleton updates the label independently.

        except Exception:
            pass
        finally:
            # Re-arm next tick
            try:
                dpg.set_frame_callback(dpg.get_frame_count() + frames_per_tick, _tick)
            except Exception:
                pass

    # Kick off the loop once
    try:
        dpg.set_frame_callback(dpg.get_frame_count() + 1, _tick)
    except Exception:
        pass
# -------------------------------
# Bootstrap
# -------------------------------
def build_gui():
    init_ui(LOG_PATH)

def run() -> None:
    """
    RERAIL 3 — Behavior-preserving GUI entry that *owns* the DPG lifecycle.
    - Prints banner
    - Ensures logfile exists
    - Builds panes via init_ui(log_path)
    - Mounts Dev Tools when PIPER_UI_DEV_INPUT=1
    - Starts a UTF-8 tailer thread for core.log
    - Schedules Dear PyGui frame callbacks to push Chat/Logs + heartbeat
    - Shows viewport and starts the main loop
    """
    import os, io, threading, time, traceback
    from collections import deque
    from datetime import datetime
    from pathlib import Path

    print("[GUI] Starting Piper GUI (LL-R03).")

    # ---- Config from env ----
    log_path = os.environ.get("PIPER_CORE_LOG", r"C:\Piper\run\core.log")
    tail_from_start = os.environ.get("PIPER_UI_TAIL_FROM_START", "0") == "1"
    # Suppress boot noise (DEV/available_states/ready) for the first second
    _boot_suppress_deadline = datetime.now().timestamp() + float(os.environ.get("PIPER_UI_SUPPRESS_BOOT_SEC", "1.0"))
    poll_sec = float(os.environ.get("PIPER_UI_POLL_SEC", "0.25"))
    dev_input_enabled = os.environ.get("PIPER_UI_DEV_INPUT", "0") == "1"
    # Prefer separate Dev window; disallow embedded unless explicitly re-enabled.
    os.environ.setdefault("PIPER_UI_DEV_EMBED", "0")

    p = Path(log_path)
    p.parent.mkdir(parents=True, exist_ok=True)
    if not p.exists():
        p.write_text("[GUI] Tailing created. Start CLI to feed logs.\n", encoding="utf-8")

    # ---- Imports (robust paths) ----
    try:
        try:
            from scripts.ui.panes import init_ui, refresh_ui, set_hb_text  # type: ignore
        except Exception:
            from ui.panes import init_ui, refresh_ui, set_hb_text          # type: ignore
        # Dev Tools mounters (we'll try multiple names)
        mounters = []
        for modname, sym in [
            ("scripts.ui.helpers.dev_controls_mount", "lazy_mount_under_logs"),
            ("ui.helpers.dev_controls_mount", "lazy_mount_under_logs"),
            ("scripts.ui.dev_tools", "attach_dev_tools"),
            ("ui.dev_tools", "attach_dev_tools"),
            ("scripts.ui.helpers.dev_controls_mount", "mount_dev_input"),
            ("ui.helpers.dev_controls_mount", "mount_dev_input"),
        ]:
            try:
                mod = __import__(modname, fromlist=[sym])
                fn = getattr(mod, sym, None)
                if callable(fn):
                    mounters.append(fn)
            except Exception:
                pass
        import dearpygui.dearpygui as dpg
    except Exception:
        traceback.print_exc()
        raise

    # ---- Buffers & state (UI-local) ----
    LOG_MAX, CHAT_MAX = 1200, 600
    log_buffer, chat_buffer = deque(maxlen=LOG_MAX), deque(maxlen=CHAT_MAX)
    last_update_ts: datetime | None = None
    _refresh_needed = False
    _chat_dirty = False
    _log_dirty = False

    def _classify_and_buffer(line: str):
        nonlocal last_update_ts, _refresh_needed, _chat_dirty, _log_dirty
        global persona_tone, persona_sarcasm
        s = line.rstrip("\r\n")
        if not s:
            return
        # Normalize CLI-formatted structured lines: "> [STATE] ..." -> "[STATE] ..."
        raw = s.lstrip()
        if raw.startswith("> ["):
            s = raw[2:].lstrip()
            raw = s

        # Drop early boot noise in logs for the first second (keeps panes clean at launch)
        now_ts = datetime.now().timestamp()
        if now_ts < _boot_suppress_deadline:
            low = s.lower()
            if s.startswith("[dev]") or "available_states=" in low or "piper is ready" in low:
                # allow spoken/chat lines through if any (we only suppress loggy boot chatter)
                # Chat-only lines unless they are structured bracketed events like [STATE]
                is_spoken = ((s.startswith("> ") and not s.startswith("> [")) or s.startswith("[TTS]") or s.lower().startswith("hello"))
                if not is_spoken:
                    return

        # Chat-only lines: start with "> " or carry [TTS]
        is_spoken = s.startswith("> ") or s.startswith("[TTS]") or s.lower().startswith("hello")

        # Status/error-ish lines that belong in Logs
        low = s.lower()
        is_status = ("[STATE]" in s) or ("[EVT]" in s) or ("[GUI]" in s) \
                    or ("[PERSONA]" in s) or ("[TONE]" in s) or ("[SARCASM]" in s)
        is_error  = ("[ERR]" in s) or ("error" in low) or ("traceback" in low)
                # --- STATE updates -------------------------------------------------
        # Accept either "[STATE] A -> B" or "[STATE] B"
        if "[STATE]" in s:
            try:
                import re as _re
                m = _re.search(r"\[STATE\]\s*(?:[A-Z]+\s*->\s*)?([A-Z]+)", s)
                if m:
                    new_state = (m.group(1) or "").strip().upper()
                    if new_state:
                        # Record and publish the new state
                        globals()["current_state"] = new_state
                        _refresh_needed = True
                        # Update the dot immediately via the header module (UI-thread safe helper)
                        try:
                            try:
                                from scripts.ui.pane_parts import header_bar as _hb
                            except Exception:
                                from ui.pane_parts import header_bar as _hb
                            _hb.set_state_dot(new_state)
                        except Exception:
                            pass
            except Exception:
                pass

        # Update header persona vars when persona directives arrive
        # Persona toggles (Dev Tools path): mirror tailer’s logic
        if "[PERSONA]" in s or "[TONE]" in s or "[SARCASM]" in s:
            try:
                pm = re.search(r"\[PERSONA\].*?\btone\s*=\s*([A-Za-z]+).*?\bsarcasm\s*=\s*(on|off|true|false|1|0)", s, re.IGNORECASE)
                if pm:
                    t  = pm.group(1).strip().lower()
                    sv = pm.group(2).strip().lower()
                    if t:
                        globals()["persona_tone"] = t
                    globals()["persona_sarcasm"] = (sv in ("on", "true", "1", "yes"))
                    _refresh_needed = True
                else:
                    tm = re.search(r"\[TONE\]\s*([A-Za-z]+)", s, re.IGNORECASE)
                    if tm:
                        globals()["persona_tone"] = tm.group(1).strip().lower()
                        _refresh_needed = True
                    sm = re.search(r"\[SARCASM\]\s*(on|off|true|false|1|0)", s, re.IGNORECASE)
                    if sm:
                        sv = sm.group(1).strip().lower()
                        globals()["persona_sarcasm"] = (sv in ("on", "true", "1", "yes"))
                        _refresh_needed = True
            except Exception:
                pass

        if "[TONE]" in s:
            import re as _re
            m = _re.search(r"\[TONE\]\s*([A-Za-z\-]+)", s, _re.IGNORECASE)
            if m:
                globals()["persona_tone"] = m.group(1).strip().lower()
                _refresh_needed = True

        if "[SARCASM]" in s:
            import re as _re
            m = _re.search(r"\[SARCASM\]\s*(on|off|true|false|1|0)", s, _re.IGNORECASE)
            if m:
                val = m.group(1).strip().lower()
                globals()["persona_sarcasm"] = (val in ("on","true","1"))
                _refresh_needed = True
        # --- State detection from logs (mirror of top-level logic) ---
        try:
            ns = None
            m = STATE_RE.search(s)
            if m:
                if m.group(2):      # OLD -> NEW
                    ns = m.group(2)
                elif m.group(3):    # NEW
                    ns = m.group(3)
            else:
                mw = STATE_WORD_RE.search(s)
                if mw:
                    ns = mw.group(1)
                elif SLEEP_HINT_RE.search(s):
                    ns = "SLEEPING"
                elif s.lstrip().startswith(">"):
                    ns = "SPEAKING"

            if ns:
                cand = (ns or "").strip().upper()
                if cand in VALID_STATES and cand != globals().get("current_state"):
                    globals()["current_state"] = cand
                    try:
                        from scripts.ui.pane_parts import header_bar as _hb
                    except Exception:
                        from ui.pane_parts import header_bar as _hb
                    _hb.set_state_dot(current_state)

                    globals()["_refresh_needed"] = True
        except Exception:
            pass

        if is_spoken:
            chat_buffer.append(s); _chat_dirty = True

        # Only log status/error lines, or non-chat leftovers
        if (is_status or is_error) or (not is_spoken):
            log_buffer.append(s); _log_dirty = True

        last_update_ts = datetime.now()
        _refresh_needed = True

    # ---- UTF-8 tailer thread ----
    _tailer_stop = False
    def _tailer():
        try:
            with io.open(p, "r", encoding="utf-8", errors="replace", newline="") as f:
                if not tail_from_start:
                    f.seek(0, os.SEEK_END)
                while not _tailer_stop:
                    pos = f.tell()
                    line = f.readline()
                    if not line:
                        time.sleep(poll_sec)
                        f.seek(pos)
                        continue
                    _classify_and_buffer(line)
        except Exception:
            traceback.print_exc()

    # ---- Heartbeat text ----
    def _hb_text() -> str:
        try:
            if last_update_ts:
                secs = max(0, int((datetime.now() - last_update_ts).total_seconds()))
                return f"last change = {secs} seconds ago"
        except Exception:
            pass
        return "last change = 0 seconds ago"

    # ---- Schedule frame ticks ----
    def _schedule_ticks():
        frames_per_tick = max(1, int(poll_sec * 60))
        def _tick(sender=None, app_data=None):
            nonlocal _refresh_needed, _chat_dirty, _log_dirty
            try:
                # Heartbeat label
                try: set_hb_text(_hb_text())
                except Exception: pass
                # Push buffers when dirty
                if _refresh_needed:
                    chat_text = "\n".join(map(str, chat_buffer))
                    log_text  = "\n".join(map(str, log_buffer))
                    # Force header labels to reflect persona (bypass any stale adapter)
                    try:
                        try:
                            from scripts.ui.pane_parts import header_bar as _hb
                        except Exception:
                            from ui.pane_parts import header_bar as _hb  # fallback import

                        _hb.refresh(
                            f"State: {current_state}",
                            _hb_text(),
                            f"Tone: {persona_tone}",
                            f"Sarcasm: {'on' if persona_sarcasm else 'off'}",
                            ""   # empty tailing text so nothing shows there
                        )
                        try:
                            # Force the state label/dot to match current_state every tick
                            if hasattr(_hb, "set_state"):
                                _hb.set_state(current_state)
                            elif hasattr(_hb, "refresh_state"):
                                _hb.refresh_state(current_state)
                            elif hasattr(_hb, "refresh"):
                                # Some builds accept state_text as first arg in refresh
                                _hb.refresh(f"State: {current_state}", _hb_text(),
                                            f"Tone: {persona_tone}",
                                            f"Sarcasm: {'on' if persona_sarcasm else 'off'}",
                                            "")
                        except Exception:
                            pass
                            
                        try:
                            # Some builds expose a dedicated setter for the state/dot — call whichever exists.
                            if hasattr(_hb, "set_state"):
                                _hb.set_state(current_state)
                            elif hasattr(_hb, "set_state_dot"):
                                    _hb.set_state_dot(current_state)
                            elif hasattr(_hb, "refresh_state"):
                                    _hb.refresh_state(current_state)
                        except Exception:
                            pass
                        # Ensure state label + dot update every frame
                        try:
                            from scripts.ui.pane_parts import header_bar as _hb
                        except Exception:
                            from ui.pane_parts import header_bar as _hb  # fallback

                        try:
                            _hb.set_state_dot(current_state)
                        except Exception:
                            pass

                    except Exception:
                        pass
                    refresh_ui(
                        f"State: {current_state} · Tone: {persona_tone} · Sarcasm: {'on' if persona_sarcasm else 'off'}",
                        f"{_hb_text()} · Tone: {persona_tone} · Sarcasm: {'on' if persona_sarcasm else 'off'}",
                        chat_text,
                        log_text,
                        _chat_dirty,
                        _log_dirty
                    )
            finally:
                _chat_dirty = _log_dirty = False
                _refresh_needed = False
                try:
                    dpg.set_frame_callback(dpg.get_frame_count() + frames_per_tick, _tick)
                except Exception:
                    pass
        try:
            dpg.set_frame_callback(dpg.get_frame_count() + 1, _tick)
        except Exception:
            pass

    # ---- Dear PyGui lifecycle (owned here) ----
    dpg.create_context()
    try:
        # Build UI
        init_ui(str(p))
        # -- Lock root windows (no global scroll); keep scroll only in child panes (chat/logs)
        try:
            import dearpygui.dearpygui as dpg
            _allow_scroll_tags = {"chat_child", "logs_child", "chat", "logs"}  # tolerate older tag names

            def _lock_root_scrollbars():
                for item in dpg.get_all_items():
                    try:
                        t = dpg.get_item_type(item)  # e.g., "mvAppItemType::Window", "mvAppItemType::ChildWindow"
                        alias = dpg.get_item_alias(item) or str(item)
                    except Exception:
                        continue
                    # Lock only top-level windows; do NOT touch child windows (they should scroll)
                    if isinstance(t, str) and "Window" in t and "ChildWindow" not in t:
                        if alias not in _allow_scroll_tags:
                            try:
                                dpg.configure_item(item, no_scrollbar=True)
                            except Exception:
                                pass

            _lock_root_scrollbars()
        except Exception:
            pass
        # -------- Dev Tools (separate window preferred; fallback to embedded) --------
        if dev_input_enabled:
            def _append_utf8_line_to_log(line: str):
                import io
                with io.open(p, "a", encoding="utf-8", newline="\n", errors="replace") as f:
                    f.write((line or "").rstrip("\r\n") + "\n")

            # Adapters expected by KGB dev_tools.attach_dev_tools
            def _emit_to_logs(text: str, tone: str = "info"):
                # Route through your existing parser -> same badges/flow as CLI
                try:
                    s = (text or "").rstrip("\n")
                    if not s:
                        return
                    _classify_and_buffer(s)
                except Exception:
                    # last-ditch: drop raw text to logs
                    log_buffer.append(str(text))
                    globals()["_log_dirty"] = True
                    globals()["_refresh_needed"] = True

            def _tone_for_line(line: str) -> str:
                low = (line or "").lower()
                if "[state]" in low:
                    return "status"
                if "[event]" in low or "[tts]" in low:
                    return "info"
                if "error" in low or "[err]" in low or "traceback" in low:
                    return "error"
                return "info"

            def _badge_for_logs(line: str) -> str:
                import re
                s = (line or "").strip()
                s = re.sub(r"\[state\]", "[STATE]", s, flags=re.IGNORECASE)
                s = re.sub(r"\[event\]", "[EVT]", s, flags=re.IGNORECASE)
                s = re.sub(r"\[tts\]", "[TTS]", s, flags=re.IGNORECASE)
                s = re.sub(r"\[err\]", "[ERR]", s, flags=re.IGNORECASE)
                return s

            # Prefer the separate “Dev Tools” window (KGB API)
            mounted = False
            try:
                try:
                    from scripts.ui.dev_tools import attach_dev_tools as _attach  # type: ignore
                except Exception:
                    from ui.dev_tools import attach_dev_tools as _attach          # type: ignore

                _attach(
                    get_state=lambda: str(globals().get("current_state", "?")),
                    get_queue=lambda: list(globals().get("state_queue", [])),
                    get_last_ts=lambda: globals().get("last_update_ts", None),
                    log_emit=_emit_to_logs,
                    tone_for_line=_tone_for_line,
                    badge_for_logs=_badge_for_logs,
                )
                mounted = True
                _emit_to_logs("[DEV][TRACE] dev_tools window mounted.", "status")
            except Exception as e:
                _emit_to_logs(f"[DEV][WARN] attach_dev_tools failed: {e}", "error")

            # Fallback: embedded controls if window API is absent
            if not mounted:
                for modname, sym in [
                    ("scripts.ui.helpers.dev_controls_mount", "lazy_mount_under_logs"),
                    ("ui.helpers.dev_controls_mount", "lazy_mount_under_logs"),
                    ("scripts.ui.helpers.dev_controls_mount", "mount_dev_input"),
                    ("ui.helpers.dev_controls_mount", "mount_dev_input"),
                ]:
                    try:
                        mod = __import__(modname, fromlist=[sym])
                        fn  = getattr(mod, sym, None)
                        if callable(fn):
                            try:
                                fn(log_writer=_append_utf8_line_to_log, log_path=str(p))
                            except TypeError:
                                try: fn(str(p))
                                except TypeError: fn()
                            _emit_to_logs("[DEV][TRACE] embedded dev controls mounted.", "status")
                            break
                    except Exception:
                        pass
    # ---------------------------------------------------------------------------
        # Start tailer
        threading.Thread(target=_tailer, name="PiperTailer", daemon=True).start()
        # Ticks
        _schedule_ticks()
        # Viewport + loop
        dpg.create_viewport(
            title="Piper GUI",
            width=L.WINDOW.WIDTH,
            height=L.WINDOW.HEIGHT,
        )
        dpg.setup_dearpygui()
        dpg.show_viewport()
        dpg.start_dearpygui()
    finally:
        try: dpg.destroy_context()
        except Exception: pass
def main():
    run()

if __name__ == "__main__":
    main()