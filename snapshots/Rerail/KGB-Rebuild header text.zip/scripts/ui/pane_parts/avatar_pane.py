﻿"""Avatar pane — build + resize + fallback drawing (mutually exclusive surfaces)."""
from __future__ import annotations
from scripts.ui.layout_constants import L
from typing import Tuple, Optional
import dearpygui.dearpygui as dpg

def build() -> None:
    """
    Create the avatar panel & draw surface if missing.
    """
    try:
        if not dpg.does_item_exist("logs_container"):
            return
        if not dpg.does_item_exist("avatar_panel"):
            with dpg.child_window(
                tag="avatar_panel",
                autosize_x=True,
                autosize_y=False,
                no_scrollbar=True,              # <- no scrollbars in avatar panel
            ):
                pass
        # Ensure a drawlist exists for fallback glyph
        if not dpg.does_item_exist("avatar_draw"):
            dpg.add_drawlist(tag="avatar_draw", parent="avatar_panel", show=True)
        # If an image widget exists, start hidden (we'll toggle in resize)
        if dpg.does_item_exist("avatar_image"):
            dpg.configure_item("avatar_image", show=False)
    except Exception:
        pass

def _fallback_draw(ap_w: int, ap_h: int) -> None:
    """Draw a pill + 'P' glyph when image texture is not available."""
    try:
        if not dpg.does_item_exist("avatar_draw"):
            return
        dpg.delete_item("avatar_draw", children_only=True)
        dpg.draw_rectangle(
            (0, 0), (ap_w, ap_h),
            color=(0, 0, 0, 0),
            fill=(24, 48, 96, 255),
            rounding=12,
            parent="avatar_draw",
        )
        dpg.draw_text(
            (ap_w // 2 - 12, ap_h // 2 - 24),
            "P",
            size=48,
            color=(230, 240, 255, 255),
            parent="avatar_draw",
        )
    except Exception:
        pass

def resize(
    panel_size: Tuple[int, int],
    pad: int,
    avatar_tex: Optional[int],
    img_w: Optional[int],
    img_h: Optional[int],
) -> None:
    """
    Fit avatar image/draw into panel_size with padding.
    - If texture + size known: show image, hide drawlist.
    - Else: hide image, show drawlist with fallback glyph.
    Ensures no child is larger than the panel (prevents scrolling).
    """
    try:
        ap_w, ap_h = int(panel_size[0]), int(panel_size[1])
        avail_w = max(50, ap_w - pad)
        avail_h = max(50, ap_h - pad)

        has_img_dims = bool(img_w) and bool(img_h)
        has_tex = bool(avatar_tex)

        # Always keep the container non-scrollable
        if dpg.does_item_exist("avatar_panel"):
            dpg.configure_item("avatar_panel", no_scrollbar=True)

        if has_tex and has_img_dims and dpg.does_item_exist("avatar_image"):
            # Scale image with aspect ratio within available area
            scale = min(avail_w / float(img_w), avail_h / float(img_h))
            tw = max(1, int(float(img_w) * scale))
            th = max(1, int(float(img_h) * scale))
            dpg.configure_item("avatar_image", width=tw, height=th, show=True)

            # Hide/neutralize drawlist so it doesn't add height
            if dpg.does_item_exist("avatar_draw"):
                dpg.configure_item("avatar_draw", width=int(avail_w), height=int(avail_h), show=False)
                dpg.delete_item("avatar_draw", children_only=True)
        else:
            # No image → use fallback glyph on the drawlist, hide image
            if dpg.does_item_exist("avatar_image"):
                dpg.configure_item("avatar_image", show=False)
            if dpg.does_item_exist("avatar_draw"):
                dpg.configure_item("avatar_draw", width=int(avail_w), height=int(avail_h), show=True)
                _fallback_draw(int(avail_w), int(avail_h))
    except Exception:
        pass
# --- B02 hotfix: ensure avatar image scales correctly after layout settles ---
def post_layout_fix(img_tag=None, container_tag=None):
    """
    After layout settles, size the avatar image to CONTAIN within its panel
    (no over-zoom), preserving aspect ratio. Runs twice to catch late layout.
    Safe no-op if tags are missing.
    """
    try:
        import dearpygui.dearpygui as dpg
    except Exception:
        return

    # Resolve tags if not provided (tolerant to legacy names)
    def _first_tag(cands):
        for t in cands:
            try:
                if dpg.does_item_exist(t):
                    return t
            except Exception:
                pass
        return None

    img = img_tag or _first_tag(["avatar_image", "avatar_img", "avatar_texture", "avatar_pic", "avatar"])
    panel = container_tag or _first_tag(["avatar_panel", "avatar_pane", "avatar_container",
                                         "avatar_region", "avatar_group", "right_avatar"])
    if not (img and panel):
        return

    def _get_tex_size(image_tag):
        """Try to get intrinsic texture size; fall back to current item size."""
        tw = th = None
        try:
            icfg = dpg.get_item_configuration(image_tag)
            tex = icfg.get("texture_tag", None)
            if tex:
                tcfg = dpg.get_item_configuration(tex)
                tw = tcfg.get("width", None)
                th = tcfg.get("height", None)
        except Exception:
            pass
        if not tw or not th:
            try:
                icfg = dpg.get_item_configuration(image_tag)
                tw = icfg.get("width", None)
                th = icfg.get("height", None)
            except Exception:
                pass
        return (tw or 1), (th or 1)

    def _fit_once():
        try:
            # Panel client size
            pw, ph = dpg.get_item_rect_size(panel)
            if not pw or not ph:
                return
            tw, th = _get_tex_size(img)

            # contain-fit with tiny margin (avoid scrollbar jitter)
            scale = min(max(pw, 1) / max(tw, 1), max(ph, 1) / max(th, 1)) * L.AVATAR.FIT_MARGIN
            new_w = max(1, int(tw * scale))
            new_h = max(1, int(th * scale))

            dpg.configure_item(img, width=new_w, height=new_h)
        except Exception:
            pass

    # Run after layout and once more a few frames later (to catch dev-pane toggles)
    try:
        fc = dpg.get_frame_count()
        dpg.set_frame_callback(fc + 1,  lambda s=None, a=None: _fit_once())
        dpg.set_frame_callback(fc + 5,  lambda s=None, a=None: _fit_once())
    except Exception:
        _fit_once()
