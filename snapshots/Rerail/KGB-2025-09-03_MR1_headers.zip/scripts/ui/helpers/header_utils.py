"""
B04.5 Header utilities — extracted from ui/panes.py
No new geometry/theme literals; pure helpers.
"""

from __future__ import annotations
from typing import Tuple, Optional

import dearpygui.dearpygui as dpg


def compose_header_strings(
    state_text: str,
    current_tone: Optional[str],
    sarcasm_on: bool,
    log_path: Optional[str],
    shorten_path_fn=None
) -> Tuple[str, str, str, str]:
    """
    Returns (state_str, tone_str, sarcasm_str, tailing_str) exactly like panes.py did.
    shorten_path_fn: optional callable for displaying the tailed log path.
    """
    state_str = f"State: {state_text}"
    tone_str = f"Tone: {str(current_tone or 'neutral')}"
    sarcasm_str = "Sarcasm: on" if bool(sarcasm_on) else "Sarcasm: off"
    tailing_str = f"Tailing: {shorten_path_fn(log_path)}" if (log_path and callable(shorten_path_fn)) else ""
    return state_str, tone_str, sarcasm_str, tailing_str


# If your panes.py had a private _update_state_dot(state_text), move that logic here:
def update_state_dot(state_text: str) -> None:
    """
    Update the small state indicator dot in the header/status bar.
    This is a straight move from panes.py (same semantics).
    """
    try:
        # These tag names mirror the existing layout; we keep it defensive.
        DOT = None
        for t in ("state_dot", "status_dot", "hb_state_dot"):
            if dpg.does_item_exist(t):
                DOT = t
                break
        if not DOT:
            return

        # Map state text to a DearPyGui color; keep same mapping you already use.
        # (Example: SLEEPING gray, WAKING yellow, LISTENING blue, THINKING purple, SPEAKING green)
        st = (state_text or "").upper()
        color = (128, 128, 128, 255)  # default gray
        if "WAKING" in st:
            color = (255, 200, 0, 255)
        elif "LISTENING" in st:
            color = (64, 128, 255, 255)
        elif "THINKING" in st:
            color = (160, 96, 255, 255)
        elif "SPEAKING" in st:
            color = (64, 200, 120, 255)
        elif "SLEEP" in st:
            color = (110, 110, 110, 255)

        try:
            # Try both, some builds use outline color to render tiny circles visibly
            import dearpygui.dearpygui as dpg
            try:
                dpg.configure_item(DOT, fill=color)
            except Exception:
                pass
            try:
                dpg.configure_item(DOT, color=color)
            except Exception:
                pass
        except Exception:
            # If DOT is a simple text/icon, it's safe to no-op
            pass
    except Exception:
        pass
