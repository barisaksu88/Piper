﻿from __future__ import annotations
from typing import Callable, Optional, Dict, Any
import dearpygui.dearpygui as dpg

_TAGS: Dict[str, int] = {}
_ADAPTERS: Dict[str, Callable[..., Any]] = {}

def _T(name: str) -> str:
    return f"controls_pane::{name}"

def _adapter(name: str):
    fn = _ADAPTERS.get(name)
    return fn if callable(fn) else None

def _cb_submit_dev_input():
    entry = dpg.get_value(_T("dev_input"))
    if not entry:
        return
    h = _adapter("on_dev_submit")
    if h:
        h(entry)
    dpg.set_value(_T("dev_input"), "")

def _cb_inject_chat():
    entry = dpg.get_value(_T("dev_input")) or ""
    h = _adapter("on_inject_chat")
    if h:
        h(entry)

def _cb_inject_log():
    entry = dpg.get_value(_T("dev_input")) or ""
    h = _adapter("on_inject_log")
    if h:
        h(entry)

def _cb_set_state(sender, app_data, user_data):
    target = user_data if isinstance(user_data, str) else None
    h = _adapter("on_set_state")
    if h and target:
        h(target)

def _cb_toggle_sarcasm():
    h = _adapter("on_toggle_sarcasm")
    if h:
        h()

def _cb_cycle_tone():
    h = _adapter("on_cycle_tone")
    if h:
        h()

def build(parent: int, adapters: Optional[Dict[str, Callable[..., Any]]] = None) -> Dict[str, int]:
    """Mount developer controls inside 'parent'. Caller handles flag-gating."""
    global _ADAPTERS, _TAGS
    _ADAPTERS = adapters or {}
    _TAGS = {}

    with dpg.child_window(parent=parent, border=True, tag=_T("root")):
        with dpg.group(horizontal=True):
            _TAGS["dev_input"] = dpg.add_input_text(tag=_T("dev_input"), hint="Dev inputâ€¦ (flag-gated)")
            dpg.add_button(label="Submit", callback=_cb_submit_dev_input)

        with dpg.group(horizontal=True):
            dpg.add_button(label="Inject â†’ Chat", callback=_cb_inject_chat)
            dpg.add_button(label="Inject â†’ Log", callback=_cb_inject_log)

        with dpg.group(horizontal=True):
            for s in ("SLEEPING", "WAKING", "LISTENING", "THINKING", "SPEAKING"):
                dpg.add_button(label=s, callback=_cb_set_state, user_data=s)

        with dpg.group(horizontal=True):
            dpg.add_button(label="Toggle Sarcasm", callback=_cb_toggle_sarcasm)
            dpg.add_button(label="Cycle Tone", callback=_cb_cycle_tone)

    return dict(_TAGS)

def refresh(state: Optional[Dict[str, Any]] = None) -> None:
    if not _TAGS:
        return
    _ = state  # no-op (future: reflect tone/sarcasm)

