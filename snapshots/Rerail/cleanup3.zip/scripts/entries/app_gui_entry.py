﻿# AUTO-GENERATED: B04 thin wrapper (no fallback)  
from __future__ import annotations          
try:                                              
    from ._app_gui_entry_impl import run as run  
except Exception:                                 
    from .app_gui_entry import run as run       

if __name__ == "__main__":                      
    run()                                  