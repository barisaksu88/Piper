﻿# Ring-1 Services: placeholder manager API (no-op implementations).
def is_speaking() -> bool:
    return False
def stop_tts():
    pass
__all__ = ["is_speaking", "stop_tts"]

