﻿"""
B04.2 Scroll utilities â€” extracted from ui/panes.py
No new literals; pure helpers.
"""
import dearpygui.dearpygui as dpg

def is_at_bottom(tag: str, threshold: int = 48) -> bool:
    """Return True if scrollable region is near bottom within threshold px."""
    if not tag:
        return False
    try:
        cur = dpg.get_y_scroll(tag)
        mx = dpg.get_y_scroll_max(tag)
        return (mx - cur) <= threshold
    except Exception:
        return False

def scroll_to_bottom_next_frame(tag: str) -> None:
    """Schedule a scroll-to-bottom for next frame."""
    if not tag:
        return
    try:
        dpg.set_frame_callback(
            dpg.get_frame_count() + 1,
            lambda s=None, a=None: dpg.set_y_scroll(tag, dpg.get_y_scroll_max(tag))
        )
    except Exception:
        pass

def update_autoscroll_badges(chat_scroll_tag, chat_badge_tag, log_scroll_tag, log_badge_tag) -> None:
    """
    Show/hide tiny 'autoscroll' badges based on whether each pane is at bottom.
    Safe no-op if tags are missing.
    """
    try:
        if chat_scroll_tag and chat_badge_tag:
            dpg.configure_item(chat_badge_tag, show=not is_at_bottom(chat_scroll_tag))
    except Exception:
        pass
    try:
        if log_scroll_tag and log_badge_tag:
            dpg.configure_item(log_badge_tag, show=not is_at_bottom(log_scroll_tag))
    except Exception:
        pass

