# Project module: ui/state_header.py
# === DEV NOTE · Rerail (B02, additive-only) ===
# Purpose: A single place to compute state header text/color.
# Behavior TODAY: Helpers only; no UI calls, no side effects.
# Next step: _panes_impl (or a status pane) will call these to render.

from __future__ import annotations
from typing import Tuple
try:
    # central palette you already keep
    from scripts.ui.state_colors import STATE_COLOR  # type: ignore
except Exception:
    STATE_COLOR = {
        "SLEEPING": (120, 120, 120),
        "WAKING":   (153, 153, 255),
        "LISTENING":(70, 130, 180),
        "THINKING": (255, 200, 80),
        "SPEAKING": (0, 180, 120),
    }

_VALID = {"SLEEPING","WAKING","LISTENING","THINKING","SPEAKING"}

def resolve_label(state: str) -> str:
    """Return the human-facing label for the header."""
    s = (state or "").upper()
    return s if s in _VALID else "SLEEPING"

def resolve_color(state: str) -> Tuple[int,int,int]:
    """Return the RGB color tuple for the state dot."""
    s = (state or "").upper()
    if s not in STATE_COLOR:
        s = "SLEEPING"
    return STATE_COLOR[s]
