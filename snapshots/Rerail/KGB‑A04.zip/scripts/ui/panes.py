# LAYOUT/LOOK – LL04C independent, intent-based autoscroll (final, avatar-ready)
from __future__ import annotations
import os
import time
import dearpygui.dearpygui as dpg

# ---------- layout ----------
VIEWPORT_W = 1345
VIEWPORT_H = 720
LEFT_W     = int(VIEWPORT_W * 0.58)
RIGHT_W    = VIEWPORT_W - LEFT_W - 250
ROW_H      = VIEWPORT_H - 120
PAD        = 12

# ---------- state colors ----------
STATE_COLORS = {
    "SLEEPING":  (128, 128, 128, 255),
    "WAKING":    (255, 165,   0, 255),
    "LISTENING": ( 70, 130, 180, 255),
    "THINKING":  (255, 215,   0, 255),
    "SPEAKING":  (  0, 200, 100, 255),
}
_DEFAULT_DOT = (200, 200, 200, 255)
_DWELL_SEC   = 0.35

_last_state  = None
_last_change = 0.0

# ---------- autoscroll control ----------
_first_chat  = True
_first_logs  = True

# user-intent autofollow flags (True = follow to bottom)
_chat_autofollow = True
_logs_autofollow = True

# multi-frame snapping windows (only if autofollow True)
_chat_stick_frames = 0
_logs_stick_frames = 0

# detect continued growth of scrollable height; require stability before releasing
_chat_last_max = 0.0
_logs_last_max = 0.0
_chat_growth_stable = 0
_logs_growth_stable = 0

# detect user scroll (track last y-scroll)
_chat_last_scroll = 0.0
_logs_last_scroll = 0.0

# tolerance for "at bottom"
_EPS = 28.0  # px

# ---------- copy helpers ----------
def _copy_chat():
    try:
        dpg.set_clipboard_text(dpg.get_value("chat_text") or "")
    except Exception:
        pass

def _copy_logs():
    try:
        dpg.set_clipboard_text(dpg.get_value("log_text") or "")
    except Exception:
        pass

# ---------- avatar helpers (single, consistent version) ----------
_AVATAR_TEX = None          # texture id (if image loaded)
_AVATAR_IMG_W = 0           # source image width
_AVATAR_IMG_H = 0           # source image height
_AVATAR_W, _AVATAR_H = 48, 48  # header icon size

def _ensure_texture_registry():
    if not dpg.does_item_exist("texture_registry"):
        with dpg.texture_registry(tag="texture_registry"):
            pass

def _load_avatar_from_file(path: str):
    """Load file into a static texture and remember dimensions; return texture id or None."""
    global _AVATAR_TEX, _AVATAR_IMG_W, _AVATAR_IMG_H
    if not path or not os.path.exists(path):
        return None
    try:
        _ensure_texture_registry()
        w, h, c, data = dpg.load_image(path)
        tex_id = dpg.add_static_texture(w, h, data, parent="texture_registry")
        _AVATAR_TEX, _AVATAR_IMG_W, _AVATAR_IMG_H = tex_id, w, h
        return tex_id
    except Exception:
        return None

# ---------- helpers ----------
def _update_bottom_padding():
    """Let the user scroll ~1/3 pane beyond last line."""
    try:
        _, h = dpg.get_item_rect_size("chat_scroll")
        dpg.configure_item("chat_pad", height=max(12, int(h * 0.33)))
    except Exception:
        pass
    try:
        _, h = dpg.get_item_rect_size("logs_scroll")
        dpg.configure_item("logs_pad", height=max(12, int(h * 0.33)))
    except Exception:
        pass

def _is_at_bottom(tag: str) -> bool:
    try:
        cur = dpg.get_y_scroll(tag)
        mx  = dpg.get_y_scroll_max(tag)
        return (mx - cur) <= _EPS
    except Exception:
        return True  # default sticky until mounted

def _scroll_to_bottom(tag: str):
    def _snap():
        try:
            dpg.set_y_scroll(tag, dpg.get_y_scroll_max(tag))
        except Exception:
            pass
    _snap()
    try:
        fc = dpg.get_frame_count()
        for k in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10):
            dpg.set_frame_callback(fc + k, lambda s=None, a=None, u=None: _snap())
    except Exception:
        pass

def _apply_wraps():
    try:
        w,_ = dpg.get_item_rect_size("chat_scroll")
        dpg.configure_item("chat_text", wrap=max(0, int(w - PAD)))
    except Exception:
        pass
    try:
        w,_ = dpg.get_item_rect_size("logs_scroll")
        dpg.configure_item("log_text", wrap=max(0, int(w - PAD)))
    except Exception:
        pass

def _update_state_dot(state_text: str):
    global _last_state, _last_change
    now = time.time()
    if state_text != _last_state:
        _last_state, _last_change = state_text, now
    show_state = _last_state if (now - _last_change) < _DWELL_SEC and _last_state else state_text
    color = STATE_COLORS.get(show_state, _DEFAULT_DOT)
    try:
        dpg.configure_item("state_dot_circle", fill=color)
    except Exception:
        pass
    try:
        dpg.set_value("state_label", f"State: {state_text}")
    except Exception:
        pass

def _shorten_path(p: str, max_chars: int = 72) -> str:
    try:
        s = str(p)
        if len(s) <= max_chars:
            return s
        head = s[: max_chars // 2 - 2].rstrip("\\/")
        tail = s[-(max_chars // 2 - 3):]
        return f"{head}…{tail}"
    except Exception:
        return p

def _ensure_pane_theme():
    if dpg.does_item_exist("pane_pad_theme"):
        return "pane_pad_theme"
    with dpg.theme(tag="pane_pad_theme"):
        with dpg.theme_component(dpg.mvAll):
            dpg.add_theme_style(dpg.mvStyleVar_WindowPadding, 10, 8, category=dpg.mvThemeCat_Core)
            dpg.add_theme_style(dpg.mvStyleVar_ItemSpacing,    6, 4, category=dpg.mvThemeCat_Core)
            dpg.add_theme_style(dpg.mvStyleVar_FramePadding,   6, 4, category=dpg.mvThemeCat_Core)
    return "pane_pad_theme"

# ---------- Public API ----------
def init_ui(log_path: str) -> None:
    """Root fixed & primary. Non‑scrolling headers. Dedicated scroll windows for content."""
    if dpg.does_item_exist("root"):
        dpg.delete_item("root")

    root = dpg.add_window(
        tag="root",
        pos=(0, 0),
        no_title_bar=True,
        no_move=True,
        no_resize=True,
        no_scrollbar=True,
    )
    dpg.set_item_width("root",  VIEWPORT_W)
    dpg.set_item_height("root", VIEWPORT_H)
    dpg.set_primary_window("root", True)

    pane_theme = _ensure_pane_theme()

    # ---- App header (no avatar icon here) ----
    with dpg.group(parent=root, tag="header_row", horizontal=True):
        dpg.add_text("Piper GUI", tag="title_label")
        dpg.add_spacer(width=16)
        with dpg.drawlist(width=14, height=14, tag="state_dot_draw"):
            dpg.draw_circle(center=(7, 7), radius=6, color=(0, 0, 0, 0),
                            fill=_DEFAULT_DOT, tag="state_dot_circle")
        dpg.add_spacer(width=6)
        dpg.add_text("State: SLEEPING", tag="state_label")
        dpg.add_spacer(width=12); dpg.add_text("·"); dpg.add_spacer(width=8)
        dpg.add_text("Last update: -", tag="hb_label")
        dpg.add_spacer(width=12); dpg.add_text("·"); dpg.add_spacer(width=8)
        dpg.add_text("Tone: neutral", tag="tone_label")
        dpg.add_spacer(width=12); dpg.add_text("·"); dpg.add_spacer(width=8)
        dpg.add_text("Sarcasm: off", tag="sarcasm_label")
        dpg.add_spacer(width=12); dpg.add_text("·"); dpg.add_spacer(width=8)
        dpg.add_text(_shorten_path(log_path), tag="tailing_label")

    # ---- Body row: Left = Chat, Right = Logs + Avatar ----
    with dpg.group(parent=root, tag="body_row", horizontal=True):
        # ----- Chat column (LEFT) -----
        with dpg.group(tag="chat_container"):
            with dpg.group(horizontal=True):
                dpg.add_text("Chat", tag="chat_hdr")
                dpg.add_spacer(width=10)
                dpg.add_button(label="Copy Chat", callback=_copy_chat)
                dpg.add_spacer(width=10)
                dpg.add_text("[⏸ autoscroll]", tag="chat_autoscroll_badge", show=False)
            dpg.add_separator()
            dpg.add_spacer(height=6)

            with dpg.child_window(tag="chat_scroll", width=(LEFT_W - 12), height=ROW_H,
                                  autosize_x=False, autosize_y=False):
                dpg.add_text("", tag="chat_text", wrap=LEFT_W - PAD)
                dpg.add_spacer(tag="chat_pad", height=8)
            dpg.bind_item_theme("chat_scroll", pane_theme)

        # ----- Logs + Avatar column (RIGHT) -----
        with dpg.group(tag="logs_container"):
            with dpg.group(horizontal=True):
                dpg.add_text("Logs")  # static label; no tag to avoid alias clashes
                dpg.add_spacer(width=10)
                dpg.add_button(label="Copy Logs", callback=_copy_logs)
                dpg.add_spacer(width=10)
                # Single badge tag (refresh_ui handles log_autoscroll_badge or logs_autoscroll_badge)
                if not dpg.does_item_exist("log_autoscroll_badge"):
                    dpg.add_text("[⏸ autoscroll]", tag="log_autoscroll_badge", show=False)
            dpg.add_separator()
            dpg.add_spacer(height=6)

            with dpg.child_window(tag="logs_scroll", width=(RIGHT_W - 12), height=ROW_H,
                                  autosize_x=False, autosize_y=False):
                dpg.add_text("", tag="log_text", wrap=RIGHT_W - PAD)
                dpg.add_spacer(tag="logs_pad", height=8)
            dpg.bind_item_theme("logs_scroll", pane_theme)

            dpg.add_spacer(height=8)

            # Avatar panel (bottom right; resized in calibrate_to_viewport)
            avatar_path = os.environ.get("PIPER_UI_AVATAR", "").strip() or r"C:\Piper\Library\Urban Night Glow.png"
            _load_avatar_from_file(avatar_path)  # sets _AVATAR_TEX and dims if present

            with dpg.child_window(tag="avatar_panel", width=(RIGHT_W - 12), height=180,
                                  autosize_x=False, autosize_y=False, no_scrollbar=True):
                if _AVATAR_TEX:
                    dpg.add_image(_AVATAR_TEX, tag="avatar_image")
                else:
                    with dpg.drawlist(tag="avatar_draw"):
                        dpg.draw_rectangle((0,0),(10,10),color=(0,0,0,0))  # redrawn in calibrate
def calibrate_to_viewport() -> None:
    """Match root to viewport; split right column into logs + avatar; scale avatar."""
    try:
        # Safe guards for lifecycle
        try:
            running = dpg.is_dearpygui_running()
        except Exception:
            running = True
        if not running or not dpg.does_item_exist("root"):
            return

        w = dpg.get_viewport_client_width()
        h = dpg.get_viewport_client_height()
        dpg.set_item_width("root",  w)
        dpg.set_item_height("root", h)

        # header height
        try:
            _, hdr_h = dpg.get_item_rect_size("header_row")
        except Exception:
            hdr_h = 40

        body_h = max(120, int(h - hdr_h - 65))

        # Left pane sizing
        if dpg.does_item_exist("chat_scroll"):
            dpg.configure_item("chat_scroll", height=body_h)

        # Right pane split
        logs_h_ratio = 0.3
        logs_h = max(120, int(body_h * logs_h_ratio))
        avatar_h = max(120, body_h - logs_h - 8)

        if dpg.does_item_exist("logs_scroll"):
            dpg.configure_item("logs_scroll", height=logs_h)
        if dpg.does_item_exist("avatar_panel"):
            dpg.configure_item("avatar_panel", height=avatar_h)

        # Avatar sizing / fallback drawing
        try:
            ap_w, ap_h = dpg.get_item_rect_size("avatar_panel")
            avail_w = max(50, ap_w - 12)
            avail_h = max(50, ap_h - 12)

            if dpg.does_item_exist("avatar_image") and _AVATAR_TEX and _AVATAR_IMG_W and _AVATAR_IMG_H:
                scale = min(avail_w / _AVATAR_IMG_W, avail_h / _AVATAR_IMG_H)
                tw, th = max(1, int(_AVATAR_IMG_W * scale)), max(1, int(_AVATAR_IMG_H * scale))
                dpg.configure_item("avatar_image", width=tw, height=th)
            elif dpg.does_item_exist("avatar_draw"):
                dpg.delete_item("avatar_draw", children_only=True)
                dpg.draw_rectangle((0,0), (ap_w, ap_h),
                                   color=(0,0,0,0),
                                   fill=(24,48,96,255),
                                   rounding=12,
                                   parent="avatar_draw")
                dpg.draw_text((ap_w//2 - 12, ap_h//2 - 24), "P",
                              size=48, color=(230,240,255,255),
                              parent="avatar_draw")
        except Exception:
            pass

        _apply_wraps()
        _update_bottom_padding()
    except Exception:
        pass

def refresh_ui(
    state_text: str,
    heartbeat_text: str,
    chat_text: str,
    log_text: str,
    chat_dirty: bool,
    log_dirty: bool
) -> None:
    """Update header + panes; autoscroll if user is already near bottom."""
    import dearpygui.dearpygui as dpg

    # ---------- tag resolver (handles legacy/alt names) ----------
    def _first_existing_tag(candidates):
        for t in candidates:
            try:
                if dpg.does_item_exist(t):
                    return t
            except Exception:
                pass
        return None

    CHAT_SCROLL = _first_existing_tag(["chat_scroll", "chat_view", "chat_region"])
    CHAT_TEXT   = _first_existing_tag(["chat_text", "chat_buffer"])
    LOG_SCROLL  = _first_existing_tag(["log_scroll", "logs_scroll", "log_view", "logs_view"])
    LOG_TEXT    = _first_existing_tag(["log_text", "logs_text", "log_buffer"])

    # ---------- helpers ----------
    def _is_at_bottom(tag: str, threshold: int = 48) -> bool:
        if not tag:
            return False
        try:
            cur = dpg.get_y_scroll(tag)
            mx  = dpg.get_y_scroll_max(tag)
            return (mx - cur) <= threshold
        except Exception:
            return False

    def _scroll_to_bottom_next_frame(tag: str) -> None:
        if not tag:
            return
        try:
            dpg.set_frame_callback(
                dpg.get_frame_count() + 1,
                lambda s=None, a=None: dpg.set_y_scroll(tag, dpg.get_y_scroll_max(tag))
            )
        except Exception:
            pass

    # ---------- Header ----------
    try:
        dpg.set_value("hb_label", heartbeat_text)
    except Exception:
        pass
    try:
        dpg.set_value("state_label", f"State: {state_text}")
    except Exception:
        pass
    try:
        _update_state_dot(state_text)
    except Exception:
        pass

    # Optional header notices (only if these labels exist in your layout)
    # --- Pane autoscroll badges (compact, per-pane)
    LOG_BADGE  = _first_existing_tag(["log_autoscroll_badge", "logs_autoscroll_badge"])
    CHAT_BADGE = _first_existing_tag(["chat_autoscroll_badge"])

    try:
        if CHAT_SCROLL and CHAT_BADGE:
            dpg.configure_item(CHAT_BADGE, show=not _is_at_bottom(CHAT_SCROLL))
    except Exception:
        pass
    try:
        if LOG_SCROLL and LOG_BADGE:
            dpg.configure_item(LOG_BADGE, show=not _is_at_bottom(LOG_SCROLL))
    except Exception:
        pass
    # ---------- Chat pane ----------
    if chat_dirty and CHAT_TEXT:
        chat_was_bottom = _is_at_bottom(CHAT_SCROLL)
        try:
            dpg.set_value(CHAT_TEXT, chat_text or "")
        except Exception:
            pass
        if chat_was_bottom:
            _scroll_to_bottom_next_frame(CHAT_SCROLL)

    # ---------- Logs pane ----------
    if log_dirty and LOG_TEXT:
        log_was_bottom = _is_at_bottom(LOG_SCROLL)
        try:
            dpg.set_value(LOG_TEXT, log_text or "")
        except Exception:
            pass
        if log_was_bottom:
            _scroll_to_bottom_next_frame(LOG_SCROLL)
# HB-P1h: direct header heartbeat setter (no other UI mutations)
def set_hb_text(text: str) -> None:
    try:
        import dearpygui.dearpygui as dpg
        dpg.set_value("hb_label", "Last update: -" if text is None else str(text))
    except Exception:
        pass
