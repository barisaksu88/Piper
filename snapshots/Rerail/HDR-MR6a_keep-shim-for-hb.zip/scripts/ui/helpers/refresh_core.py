"""B04.13b refresh core — extracted from ui/panes.py (behavior-preserving)."""
from __future__ import annotations

# --- imports the function relied on when refresh_ui lived in panes.py ---
import dearpygui.dearpygui as dpg
from scripts.ui.helpers.header_utils import compose_header_strings
from scripts.ui.helpers.header_bridge import apply_header_updates
from scripts.ui.helpers.scroll_utils import (
    is_at_bottom,
    scroll_to_bottom_next_frame,
    update_autoscroll_badges,
)
from scripts.ui.helpers.chatlog_writer import write_chat, write_logs
from scripts.ui.helpers.dev_controls_mount import lazy_mount_under_logs
from scripts.ui.helpers.dev_adapters import build_dev_adapters
from scripts.ui.helpers.layout_utils import apply_wraps_if_present, update_bottom_padding_if_present
# Layout constants (wrap widths & bottom pads) — fall back to 0 if not defined
try:
    from scripts.ui.layout_constants import CHAT_WRAP, LOG_WRAP, CHAT_BOTTOM_PAD, LOG_BOTTOM_PAD
except Exception:
    CHAT_WRAP = 0
    LOG_WRAP = 0
    CHAT_BOTTOM_PAD = 0
    LOG_BOTTOM_PAD = 0
# optional component delegates
try:
    from scripts.ui.components.chat_pane import refresh as _chat_refresh
except Exception:
    _chat_refresh = None
try:
    from scripts.ui.components.logs_pane import refresh as _logs_refresh
except Exception:
    _logs_refresh = None


# local copy of a tiny utility that used to live next to refresh_ui
def first_existing_tag(candidates):
    for t in candidates:
        try:
            if dpg.does_item_exist(t):
                return t
        except Exception:
            pass
    return None

def _ensure_text_widgets(CHAT_SCROLL, CHAT_TEXT, LOG_SCROLL, LOG_TEXT):
    """
    Make sure chat/log text widgets exist so set_value() works (including Dev injectors).
    If missing, create simple dpg.add_text() children inside their scroll containers.
    Safe no-op if tags already exist or containers are absent.
    """
    try:
        if CHAT_SCROLL and not CHAT_TEXT and dpg.does_item_exist(CHAT_SCROLL):
            dpg.add_text("", parent=CHAT_SCROLL, tag="chat_text")
    except Exception:
        pass
    try:
        if LOG_SCROLL and not LOG_TEXT and dpg.does_item_exist(LOG_SCROLL):
            dpg.add_text("", parent=LOG_SCROLL, tag="log_text")
    except Exception:
        pass

def refresh_ui(
    state_text: str,
    heartbeat_text: str,
    chat_text: str,
    log_text: str,
    chat_dirty: bool,
    log_dirty: bool
) -> None:
    """Update header + panes; ensure text widgets exist; handle autoscroll + badges."""
    # ---- Resolve scroll regions & text widgets (accept legacy tag names) ----
    def first_existing_tag(cands):
        for t in cands:
            try:
                if dpg.does_item_exist(t):
                    return t
            except Exception:
                pass
        return None

    CHAT_SCROLL = first_existing_tag(["chat_scroll", "chat_view", "chat_region"])
    LOG_SCROLL  = first_existing_tag(["log_scroll", "logs_scroll", "log_view", "logs_view"])
    CHAT_TEXT   = first_existing_tag(["chat_text", "chat_buffer"])
    LOG_TEXT    = first_existing_tag(["log_text", "logs_text", "log_buffer"])

    # Create missing text widgets under their scroll parents so set_value works
    try:
        if CHAT_SCROLL and not CHAT_TEXT and dpg.does_item_exist(CHAT_SCROLL):
            dpg.add_text("", parent=CHAT_SCROLL, tag="chat_text")
            CHAT_TEXT = "chat_text"
    except Exception:
        pass
    try:
        if LOG_SCROLL and not LOG_TEXT and dpg.does_item_exist(LOG_SCROLL):
            dpg.add_text("", parent=LOG_SCROLL, tag="log_text")
            LOG_TEXT = "log_text"
    except Exception:
        pass

    # ---- Autoscroll intent: remember whether user was at bottom BEFORE update ----
    chat_was_bottom = False
    log_was_bottom = False
    try:
        if CHAT_SCROLL:
            chat_was_bottom = is_at_bottom(CHAT_SCROLL)
    except Exception:
        pass
    try:
        if LOG_SCROLL:
            log_was_bottom = is_at_bottom(LOG_SCROLL)
    except Exception:
        pass

    # ---- Apply wrap widths + ensure bottom padding spacers (if those helpers exist) ----
    try:
        apply_wraps_if_present(["chat_text", "chat_buffer"], CHAT_WRAP)        # graceful if tag missing
        apply_wraps_if_present(["log_text",  "logs_text", "log_buffer"], LOG_WRAP)
    except Exception:
        pass
    try:
        update_bottom_padding_if_present(CHAT_SCROLL, "chat_bottom_pad", CHAT_BOTTOM_PAD)
        update_bottom_padding_if_present(LOG_SCROLL,  "logs_bottom_pad", LOG_BOTTOM_PAD)
    except Exception:
        pass

    # ---- Write buffers when dirty (safe if widget tags are missing) ----
    # ---- Write chat ----
    try:
        if chat_dirty:
            if _chat_refresh is not None:
                _chat_refresh(chat_text or "", chat_was_bottom)
            elif CHAT_TEXT:
                dpg.set_value(CHAT_TEXT, chat_text or "")
    except Exception:
        pass

    # ---- Write logs ----
    try:
        if log_dirty:
            if _logs_refresh is not None:
                _logs_refresh(log_text or "", log_was_bottom)
            elif LOG_TEXT:
                dpg.set_value(LOG_TEXT, log_text or "")
    except Exception:
        pass

    # ---- Update autoscroll badges (small “↑ new” hint) ----
    try:
        update_autoscroll_badges(
            chat_scroll=CHAT_SCROLL, chat_badge=first_existing_tag(["chat_autoscroll_badge"]),
            log_scroll=LOG_SCROLL,   log_badge=first_existing_tag(["log_autoscroll_badge","logs_autoscroll_badge"]),
        )
    except Exception:
        pass

    # ---- If user was already at bottom, keep them at bottom after update ----
    try:
        if chat_was_bottom and CHAT_SCROLL:
            scroll_to_bottom_next_frame(CHAT_SCROLL)
    except Exception:
        pass
    try:
        if log_was_bottom and LOG_SCROLL:
            scroll_to_bottom_next_frame(LOG_SCROLL)
    except Exception:
        pass

    # ---- Dev controls: lazy mount under logs (no dependencies on _hb/_shorten_path) ----
    try:
        # adapters can be simple; None arguments are fine in our thin shim
        # use real header module + path shortener so header updates work
        try:
            from scripts.ui.pane_parts import header_bar as _hb
        except Exception:
            try:
                from ui.pane_parts import header_bar as _hb
            except Exception:
                _hb = None  # defensive

        try:
            from scripts.ui.helpers.tag_utils import shorten_path as _shorten_path
        except Exception:
            try:
                from ui.helpers.tag_utils import shorten_path as _shorten_path
            except Exception:
                _shorten_path = (lambda p: p)

        adapters = build_dev_adapters(_hb, _shorten_path)

        lazy_mount_under_logs(LOG_SCROLL, LOG_TEXT, adapters=adapters)
    except Exception:
        pass
    # ---- Ensure state dot matches the actual current_state (UI thread safe) ----
    try:
        from scripts.ui.pane_parts import header_bar as _hb
        _name = str(globals().get("current_state", "")).strip().upper()
        if _name:
            _hb.set_state_dot(_name)
    except Exception:
        pass


# ---- Header state/tone/etc. text (use bridge with correct signature) ----
try:
    # bring header module + path shortener (same defensive pattern as above)
    try:
        from scripts.ui.pane_parts import header_bar as _hb
    except Exception:
        try:
            from ui.pane_parts import header_bar as _hb
        except Exception:
            _hb = None  # defensive

    # compose the three header strings using the existing helper
    from scripts.ui.helpers.header_utils import compose_header_strings
    state_str, tone_str, sarcasm_str, tailing_str = compose_header_strings(
        state_text=state_text,
        current_tone=str(globals().get("current_tone", "neutral")),
        sarcasm_on=bool(globals().get("sarcasm_on", False)),
        log_path=globals().get("_LOG_PATH"),
        shorten_path_fn=(lambda p: p)  # tailing_str is often blank; safe fallback
    )

    # correct call: hb module first, then the 5 texts
    from scripts.ui.helpers.header_bridge import apply_header_updates
    apply_header_updates(_hb, state_str, heartbeat_text, tone_str, sarcasm_str, tailing_str or "")
except Exception:
    pass
