﻿"""Header Bar pane (authoritative)."""
from __future__ import annotations
from typing import Optional

# scripts/ui/pane_parts/header_bar.py
from pathlib import Path
import dearpygui.dearpygui as dpg

def build(*, parent: str | int, log_path: str | None = None) -> str:
    """
    Build the header inside the given parent container.
    Returns the tag of the header group ('header_group').
    """
    if not parent:
        raise ValueError("header_bar.build() requires an explicit parent")

    # Root group for the header row
    if not dpg.does_item_exist("header_group"):
        dpg.add_group(tag="header_group", horizontal=True, parent=parent)

    # Left cluster
    dpg.add_text("Piper GUI", parent="header_group")
    dpg.add_spacer(width=12, parent="header_group")
    dot = dpg.add_drawlist(width=14, height=14, parent="header_group", tag="state_dot_draw")
    if not dpg.does_item_exist("state_dot_circle"):
        dpg.draw_circle(center=(7, 7), radius=6,
                        color=(0, 0, 0, 0),
                        fill=(120, 120, 120, 255),
                        tag="state_dot_circle",
                        parent="state_dot_draw")
    dpg.add_spacer(width=8, parent="header_group")
    dpg.add_text("State: ", parent="header_group")
    if not dpg.does_item_exist("state_label"):
        dpg.add_text("-", tag="state_label", parent="header_group")

    # Separators + labels (ASCII '-' to avoid glyph issues)
    def _sep(tag): dpg.add_spacer(width=12, parent="header_group"); dpg.add_text("-", tag=tag, parent="header_group"); dpg.add_spacer(width=8, parent="header_group")

    _sep("sep_state_hb")
    if not dpg.does_item_exist("hb_label"):
        dpg.add_text("", tag="hb_label", parent="header_group")

    _sep("sep_hb_tone")
    if not dpg.does_item_exist("tone_label"):
        dpg.add_text("Tone: neutral", tag="tone_label", parent="header_group")

    _sep("sep_tone_sarc")
    if not dpg.does_item_exist("sarcasm_label"):
        dpg.add_text("Sarcasm: off", tag="sarcasm_label", parent="header_group")

    _sep("sep_sarc_tail")
    tail = ""
    if log_path:
        try: tail = f"Tailing: {Path(log_path).name or log_path}"
        except Exception: tail = f"Tailing: {log_path}"
    if not dpg.does_item_exist("tailing_label"):
        dpg.add_text(tail, tag="tailing_label", parent="header_group")
    else:
        dpg.set_value("tailing_label", tail)

    return "header_group"
        
def refresh(state_text: str,
            heartbeat_text: str,
            tone_text: str,
            sarcasm_text: str,
            tailing_text: str,
            state_name: str | None = None) -> None:
    # existing state_name normalization + _hb.set_state_dot(name) stays as-is

    try:
        if dpg.does_item_exist("state_label"):
            dpg.set_value("state_label", state_text)
        if dpg.does_item_exist("hb_label"):
            dpg.set_value("hb_label", heartbeat_text or "last change = n/a")
        if dpg.does_item_exist("tone_label"):
            dpg.set_value("tone_label", tone_text)
        if dpg.does_item_exist("sarcasm_label"):
            dpg.set_value("sarcasm_label", sarcasm_text)
        if dpg.does_item_exist("tailing_label"):
            dpg.set_value("tailing_label", tailing_text)
    except Exception:
        pass

# at module top (once)
_DOT_LAST = None

def _find_dot_ids():
    return ["state_dot_circle"]
def set_state_dot(state_name: str) -> None:
    """Update dot color and header label, only when changed. Robust across aliases."""
    import dearpygui.dearpygui as dpg
    global _DOT_LAST
    name = (state_name or "").strip().upper()
    if _DOT_LAST == name:
        return

    # Use your existing mapping if defined; else a safe default palette
    colors = globals().get("STATE_COLORS", {
        "SLEEPING":  (96, 96, 96, 255),
        "WAKING":    (255, 190,  60, 255),
        "LISTENING": (90, 160, 255, 255),
        "THINKING":  (160, 120, 255, 255),
        "SPEAKING":  ( 80, 220, 120, 255),
    })
    color = colors.get(name, colors.get("SLEEPING", (96, 96, 96, 255)))

    # Update "State: …" label if present
    try:
        dpg.set_value("state_label", f"State: {name}")
    except Exception:
        pass

    # Paint any existing circle aliases (both fill and outline for DPG quirks)
    for DOT in _find_dot_ids():
        try:
            dpg.configure_item(DOT, fill=color)
        except Exception:
            pass
        try:
            dpg.configure_item(DOT, color=color)
        except Exception:
            pass

    _DOT_LAST = name
