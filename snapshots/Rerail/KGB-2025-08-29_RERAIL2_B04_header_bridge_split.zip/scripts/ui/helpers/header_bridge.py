"""
B04.8 Header bridge — tiny wrapper around header bar refresh.
Keeps panes.py slim. No new literals.
"""
from __future__ import annotations

def apply_header_updates(hb_module, state_text: str, heartbeat_text: str,
                         tone_text: str, sarcasm_text: str, tailing_text: str) -> None:
    """Call header bar's refresh() if present, guarded."""
    try:
        if hb_module is not None and hasattr(hb_module, "refresh"):
            hb_module.refresh(
                state_text=state_text,
                heartbeat_text=heartbeat_text,
                tone_text=tone_text,
                sarcasm_text=sarcasm_text,
                tailing_text=tailing_text,
            )
    except Exception:
        # Keep UI resilient
        pass
