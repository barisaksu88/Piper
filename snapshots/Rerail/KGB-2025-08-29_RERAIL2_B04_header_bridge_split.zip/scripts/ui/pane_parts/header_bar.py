﻿"""Header Bar pane."""
from __future__ import annotations
import dearpygui.dearpygui as dpg
from typing import Optional

def build(log_path: Optional[str] = None) -> None:
    """
    Create the header row if it does not exist yet.
    Also ensures the state dot exists even if header_row was previously created.
    Tags:
      header_row, state_dot, state_label, hb_label, tone_label, sarcasm_label, tailing_label
    Safe to call multiple times.
    """
    try:
        # If header exists already, ensure the state dot exists and return.
        if dpg.does_item_exist("header_row"):
            # If dot missing, insert it before state_label (if present) for proper order.
            if not dpg.does_item_exist("state_dot"):
                before = "state_label" if dpg.does_item_exist("state_label") else None
                if before:
                    dpg.add_text("●", tag="state_dot", parent="header_row", before=before)
                    dpg.add_spacer(width=6, parent="header_row", before=before)
                else:
                    dpg.add_text("●", tag="state_dot", parent="header_row")
                    dpg.add_spacer(width=6, parent="header_row")
            return

        # Otherwise, create the full header fresh.
        if not dpg.does_item_exist("root"):
            return

        with dpg.group(parent="root", tag="header_row", horizontal=True):
            # State dot + label
            dpg.add_text("●", tag="state_dot")
            dpg.add_spacer(width=6)
            dpg.add_text("State: ?", tag="state_label")

            dpg.add_spacer(width=12)
            dpg.add_text("0", tag="hb_label")  # heartbeat (parked)

            dpg.add_spacer(width=12)
            dpg.add_text("Tone: neutral", tag="tone_label")

            dpg.add_spacer(width=12)
            dpg.add_text("Sarcasm: off", tag="sarcasm_label")

            dpg.add_spacer(width=12)
            tailing = f"Tailing: {log_path}" if log_path else "Tailing:"
            dpg.add_text(tailing, tag="tailing_label")
    except Exception:
        pass
def refresh(
    state_text: str,
    heartbeat_text: str,
    tone_text: str,
    sarcasm_text: str,
    tailing_text: str,
) -> None:
    """Update header labels if they exist (tags from current panes.py)."""
    try:
        if dpg.does_item_exist("state_label"):
            dpg.set_value("state_label", state_text)
        if dpg.does_item_exist("hb_label"):
            dpg.set_value("hb_label", heartbeat_text)
        if dpg.does_item_exist("tone_label"):
            dpg.set_value("tone_label", tone_text)
        if dpg.does_item_exist("sarcasm_label"):
            dpg.set_value("sarcasm_label", sarcasm_text)
        if dpg.does_item_exist("tailing_label"):
            dpg.set_value("tailing_label", tailing_text)
    except Exception:
        pass

def set_heartbeat(text: str) -> None:
    """Update the heartbeat label in the header if present."""
    try:
        if dpg.does_item_exist("hb_label"):
            dpg.set_value("hb_label", text)
    except Exception:
        pass

def set_state_dot(state_text: str) -> None:
    """Robustly color the state dot regardless of its underlying widget type."""
    try:
        import dearpygui.dearpygui as dpg

        # 1) Resolve target tag; ensure it exists (build() should have created it)
        if not dpg.does_item_exist("state_dot"):
            return

        # 2) Map desired color from state
        st = (state_text or "").upper()
        color = (128, 128, 128, 255)  # default gray
        if "WAKING" in st:
            color = (255, 200, 0, 255)
        elif "LISTENING" in st:
            color = (64, 128, 255, 255)
        elif "THINKING" in st:
            color = (160, 96, 255, 255)
        elif "SPEAKING" in st:
            color = (64, 200, 120, 255)
        elif "SLEEP" in st:
            color = (110, 110, 110, 255)

        # 3) Try common update paths in order; succeed-fast
        ok = False

        # a) Text item (mvAppItemType::Text): foreground color
        try:
            dpg.configure_item("state_dot", color=color)
            ok = True
        except Exception:
            pass

        # b) Draw node (e.g., mvAppItemType::DrawCircle / DrawList children): fill or color
        if not ok:
            try:
                dpg.configure_item("state_dot", fill=color)  # circles/rectangles
                ok = True
            except Exception:
                pass
        if not ok:
            try:
                dpg.configure_item("state_dot", pmin=(0, 0), pmax=(0, 0), color=color)  # e.g., line/triangle nodes
                ok = True
            except Exception:
                pass

        # c) Theme fallback: bind a one-off theme with text color
        if not ok:
            try:
                theme_tag = "__state_dot_theme"
                if not dpg.does_item_exist(theme_tag):
                    with dpg.theme(tag=theme_tag):
                        with dpg.theme_component(dpg.mvAll):
                            dpg.add_theme_color(dpg.mvThemeCol_Text, color)
                dpg.bind_item_theme("state_dot", theme_tag)
                ok = True
            except Exception:
                pass

        # d) Last resort: recreate as a colored text bullet at the same position
        if not ok:
            try:
                parent = dpg.get_item_parent("state_dot")
                before = None
                # Try to keep it before the state label if present
                if dpg.does_item_exist("state_label"):
                    before = "state_label"
                dpg.delete_item("state_dot")
                if before:
                    dpg.add_text("●", tag="state_dot", parent=parent, before=before, color=color)
                else:
                    dpg.add_text("●", tag="state_dot", parent=parent, color=color)
                ok = True
            except Exception:
                pass

        # We don't raise if not ok; we just keep UI running
    except Exception:
        pass
