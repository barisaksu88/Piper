﻿# expose legacy functions so imports still work
from .panes import init_ui, refresh_ui, calibrate_to_viewport, set_hb_text

# still export stubs
from . import header_bar, chat_pane, logs_pane, avatar_pane

__all__ = [
    "init_ui",
    "refresh_ui",
    "calibrate_to_viewport",
    "set_hb_text",
    "header_bar",
    "chat_pane",
    "logs_pane",
    "avatar_pane",
]
