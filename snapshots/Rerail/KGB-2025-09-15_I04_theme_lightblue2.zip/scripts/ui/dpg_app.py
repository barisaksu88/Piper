﻿# Ringâ€‘2 UI bootstrap: Dear PyGui lifecycle (behaviorâ€‘preserving wrapper)
from __future__ import annotations
from typing import Callable, Optional
import dearpygui.dearpygui as dpg

def run(
    build_gui_fn: Callable[[], None],
    apply_theme_fn: Optional[Callable[[], None]] = None,
    resize_cb_fn: Optional[Callable[[int, dict], None]] = None,
    pre_show_fn: Optional[Callable[[], None]] = None,
    post_show_tick_setup_fn: Optional[Callable[[], None]] = None,
    vp_title: str = "Piper GUI",
    vp_width: int = 1116,
    vp_height: int = 780,
) -> None:
    """
    Minimal, reusable Dear PyGui lifecycle:
      - create_context
      - (optional) apply_theme_fn()
      - build_gui_fn() must create the UI tree
      - create/setup/show viewport
      - (optional) pre_show_fn() just before show (e.g., calibrate)
      - (optional) resize_cb_fn via set_viewport_resize_callback()
      - (optional) post_show_tick_setup_fn() after show (e.g., schedule frame callbacks)
      - start_dearpygui() event loop
      - destroy_context
    """
    dpg.create_context()
    try:
        # Theme (idempotent)
        if apply_theme_fn:
            try:
                apply_theme_fn()
            except Exception:
                pass

        # Build UI
        build_gui_fn()

        # Viewport
        dpg.create_viewport(title=vp_title, width=vp_width, height=vp_height)
        dpg.setup_dearpygui()

        # Optional pre-show hook (e.g., initial calibration/paint)
        if pre_show_fn:
            try:
                pre_show_fn()
            except Exception:
                pass

        dpg.show_viewport()

        # Optional resize callback
        if resize_cb_fn:
            try:
                dpg.set_viewport_resize_callback(resize_cb_fn)
            except Exception:
                pass

        # Optional post-show scheduling (e.g., frame callbacks / UI ticks)
        if post_show_tick_setup_fn:
            try:
                post_show_tick_setup_fn()
            except Exception:
                pass

        # Main loop
        dpg.start_dearpygui()
    finally:
        dpg.destroy_context()

