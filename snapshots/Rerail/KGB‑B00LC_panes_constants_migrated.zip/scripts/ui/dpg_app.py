# Ring‑2 UI bootstrap: Dear PyGui app runner (behavior‑preserving).
from __future__ import annotations

import dearpygui.dearpygui as dpg
from typing import Callable, Optional

def run(
    build_gui_fn: Callable[[], None],
    apply_theme_fn: Callable[[], None],
    resize_cb_fn: Optional[Callable[[int, dict], None]] = None,
    tick_setup_fn: Optional[Callable[[], None]] = None,
    vp_title: str = "Piper GUI",
    vp_width: int = 1116,
    vp_height: int = 780,
) -> None:
    """
    Minimal, reusable Dear PyGui lifecycle:
      - create_context
      - apply theme
      - build_gui_fn() must create the root/window
      - create/setup/show viewport
      - optional: set viewport resize callback
      - optional: schedule recurring tick via tick_setup_fn()
      - event loop
      - destroy_context
    """
    dpg.create_context()
    try:
        # Theme is idempotent; ignore failures to keep behavior unchanged.
        try:
            apply_theme_fn()
        except Exception:
            pass

        # Build UI tree
        build_gui_fn()

        # Viewport
        dpg.create_viewport(title=vp_title, width=vp_width, height=vp_height)
        dpg.setup_dearpygui()
        dpg.show_viewport()

        # Resize handler (optional)
        if resize_cb_fn is not None:
            try:
                dpg.set_viewport_resize_callback(resize_cb_fn)
            except Exception:
                pass

        # Recurring tick (optional) — caller schedules frame callbacks
        if tick_setup_fn is not None:
            try:
                tick_setup_fn()
            except Exception:
                pass

        # Event loop
        while dpg.is_dearpygui_running():
            dpg.render_dearpygui_frame()
    finally:
        dpg.destroy_context()
