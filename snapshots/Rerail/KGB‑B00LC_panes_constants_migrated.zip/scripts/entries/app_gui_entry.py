# LAYOUT/LOOK Rails – LL-R03 thin bootstrap
# - Theme lives in ui/theme.py
# - Tailer lives in ui/tailer.py
# - Panes (init_ui / refresh_ui / calibrate_to_viewport) live in ui/panes.py
# - This file wires them together + keeps minimal GUI-specific state

from __future__ import annotations

# --- DEV INPUT (IN01) imports: safe when flag is off
import os
import re
from collections import deque
from pathlib import Path
from datetime import datetime

import dearpygui.dearpygui as dpg
# Theme hook (supports both project-root and scripts-root launches)
try:
    from scripts.ui.theme import apply_theme_if_enabled   # running from C:\Piper
except Exception:
    from ui.theme import apply_theme_if_enabled           # running from C:\Piper\scripts

# Persona styling passthrough (Services)
try:
    from scripts.services.persona_adapter import style_line
except Exception:
    from services.persona_adapter import style_line

# Tailer + Panes adapters
try:
    from scripts.ui.tailer import Tailer
except Exception:
    from ui.tailer import Tailer

try:
    from scripts.ui.panes import init_ui, refresh_ui, calibrate_to_viewport, set_hb_text
except Exception:
    from ui.panes import init_ui, refresh_ui, calibrate_to_viewport, set_hb_text

# Try both package paths for ipc_child (depends on how you run modules)
try:
    from scripts.ui.ipc_child import spawn_cli  # our new helper (IN01)
except Exception:
    try:
        from ui.ipc_child import spawn_cli
    except Exception:
        spawn_cli = None  # type: ignore
        
# Dev tools module (flag-gated)
try:
    from scripts.ui.dev_tools import attach_dev_tools
except Exception:
    try:
        from ui.dev_tools import attach_dev_tools
    except Exception:
        attach_dev_tools = None  # type: ignore
# Heartbeat singleton for header timer
try:
    from scripts.ui.heartbeat import heartbeat
except Exception:
    from ui.heartbeat import heartbeat  # fallback when running from /scripts directly

# layout constants
try:
    from scripts.ui.layout_constants import L  # when launched as `python -m scripts...`
except Exception:
    from ui.layout_constants import L          # fallback if run from within scripts/


# Handle to the child CLI (dev-only). None when flag is off or unavailable.
_PIPER_CLI_CHILD = None
# -------------------------------
# Config (UI-only)
# -------------------------------
LOG_PATH = os.environ.get("PIPER_CORE_LOG", r"C:\Piper\run\core.log")
TAIL_FROM_START = os.environ.get("PIPER_UI_TAIL_FROM_START", "0") == "1"
POLL_INTERVAL_SEC = float(os.environ.get("PIPER_UI_POLL_SEC", "0.25"))
STATE_DWELL_SEC = float(os.environ.get("PIPER_UI_STATE_DWELL_SEC", "1.1"))
SPEAKING_IDLE_SEC = float(os.environ.get("PIPER_UI_SPEAKING_IDLE_SEC", "3.5"))

# -------------------------------
# Buffers & State (UI-only)
# -------------------------------
LOG_MAX_LINES = 1200
CHAT_MAX_LINES = 600

from collections import deque
log_buffer  = deque(maxlen=LOG_MAX_LINES)
chat_buffer = deque(maxlen=CHAT_MAX_LINES)

current_state = "SLEEPING"

# Persona read-outs (UI-only, read-only)
persona_tone = os.environ.get("PIPER_PERSONA_TONE", "neutral").strip().lower()
persona_sarcasm = (os.environ.get("PIPER_PERSONA_SARCASM", "off").strip().lower() in ("1","on","true","yes"))

# State & timing
state_queue = deque()
last_update_ts: datetime | None = None
last_display_switch: datetime | None = None
# Heartbeat start instant (for the header ticker only)
heartbeat_start_ts: datetime | None = None
# Dirty flags (set True when NEW line appended; cleared after refresh)
_chat_dirty = False
_log_dirty  = False

# Render tick nudge
_refresh_needed = False

# RR03: last `[STATE]` line printed to Logs (for de‑dupe)
_last_state_log: str | None = None

# UI readiness guard (avoid painting before widgets exist)
_UI_READY = False
# -------------------------------
# Classifiers (robust parsing)
# -------------------------------
AVAILABLE_STATES_BANNER_RE = re.compile(r"\[STATE\].*available_states=", re.IGNORECASE)
STATE_RE = re.compile(
    r"\[STATE\]\s*(?:([A-Za-z_]+)\s*(?:→|->)\s*([A-Za-z_]+)|([A-Za-z_]+))",
    re.IGNORECASE
)
# Valid Piper states (whitelist to avoid parsing junk like "[STATE]TE]")
VALID_STATES = {"SLEEPING", "WAKING", "LISTENING", "THINKING", "SPEAKING"}
STATE_WORD_RE = re.compile(r"\b(sleeping|waking|listening|thinking|speaking)\b", re.IGNORECASE)
SLEEP_HINT_RE = re.compile(
    r"(going to sleep|back to sleep|piper is (now )?sleeping|^sleep$|sleeping\.\.\.)",
    re.IGNORECASE,
)

# Persona toggle lines (from CLI/log)
PERSONA_RE  = re.compile(r"\[PERSONA\].*?\btone\s*=\s*([A-Za-z]+).*?\bsarcasm\s*=\s*(on|off|true|false|1|0)", re.IGNORECASE)
TONE_RE     = re.compile(r"\[TONE\]\s*([A-Za-z]+)", re.IGNORECASE)
SARCASM_RE  = re.compile(r"\[SARCASM\]\s*(on|off|true|false|1|0)", re.IGNORECASE)

# -------------------------------
# Small helpers
# -------------------------------
def _tone_for_line(line: str) -> str:
    low = (line or "").lower()
    if "[state]" in low:
        return "status"
    if "[event]" in low or "[tts]" in low:
        return "info"
    if "error" in low or "[err]" in low or "traceback" in low:
        return "error"
    return "info"

def _badge_for_logs(line: str) -> str:
    """
    Normalize common log tags and prevent artifacts like '[STATE]TE]'.
    - Case-insensitive normalization for [STATE]/[EVENT]/[TTS]/[ERR]
    - Pulls [STATE] to the front if it appears later in the line
    - Ensures errors/tracebacks are [ERR]-prefixed
    """
    s = (line or "").strip()

    # Normalize tags (case-insensitive)
    s = re.sub(r"\[state\]", "[STATE]", s, flags=re.IGNORECASE)
    s = re.sub(r"\[event\]", "[EVT]", s, flags=re.IGNORECASE)
    s = re.sub(r"\[tts\]", "[TTS]", s, flags=re.IGNORECASE)
    s = re.sub(r"\[err\]", "[ERR]", s, flags=re.IGNORECASE)

    # Clean historical artifact like '[STATE]TE]'
    s = s.replace("[STATE]TE]", "[STATE]")

    low = s.lower()

    # Error/exception lines: force [ERR] prefix once
    if ("traceback" in low) or ("error" in low) or ("exception" in low):
        if not s.startswith("[ERR]"):
            s = f"[ERR] {s}"
        return s

    # If there's a [STATE] tag not at the start, pull it forward once
    if "[STATE]" in s and not s.startswith("[STATE]"):
        s = re.sub(r"^.*?\[STATE\]", "[STATE]", s, count=1)

    return s

def _compose(buf: deque) -> str:
    return "\n".join(buf)

def _human_when(ts: datetime | None) -> str:
    if not ts:
        return "Last update: -"
    delta = (datetime.now() - ts).total_seconds()
    return f"Last update: {int(delta)}s ago"

def _advance_state_if_needed():
    """Advance state_queue head after dwell time so transient states are visible."""
    global last_display_switch, _refresh_needed

    now = datetime.now()

    # Initialize queue with the current state and force a refresh
    if not state_queue:
        state_queue.append(current_state)
        last_display_switch = now
        _refresh_needed = True
        return

    head = state_queue[0]

    # Pop head after it has been displayed for STATE_DWELL_SEC and differs from current_state
    if head != current_state:
        # Guard if last_display_switch somehow wasn't set
        last_sw = last_display_switch or now
        if (now - last_sw).total_seconds() >= STATE_DWELL_SEC:
            state_queue.popleft()
            last_display_switch = now
            _refresh_needed = True  # <-- ensure header redraw on next tick

def _is_chat_line(line: str) -> bool:
    """
    Chat pane shows ONLY Piper's spoken output.
    Accept either explicit [TTS] or lines that start with '>'.
    """
    s = (line or "")
    if not s.strip():
        return False
    if s.startswith("? ") or "Tailing:" in s or s.startswith("[GUI]"):
        return False
    if "[TTS]" in s:
        return True
    if s.lstrip().startswith(">"):
        return True
    return False

# -------------------------------
# Tailer → GUI ingestion
# -------------------------------
def _consume_line(line: str):
    """Ingest one log line; route to Chat or Logs; request UI refresh."""
    global last_update_ts, current_state, _chat_dirty, _log_dirty, _refresh_needed, _last_state_log, hb_seconds

    # Normalize
    if line.endswith("\n"):
        line = line[:-1]
    s = (line or "")
    low = s.lower()

    # Drop noisy CLI banner like: "[STATE]TE] available_states=..."
    if AVAILABLE_STATES_BANNER_RE.search(s):
        return

    # Count only meaningful lines for the header heartbeat
    is_noise_for_clock = ("[tail]" in low) or low.startswith("[dev][trace]") or s.startswith("[GUI]")
    if not is_noise_for_clock:
        last_update_ts = datetime.now()
        heartbeat.reset()  # ← reset timer on meaningful line

    # Persona toggles (read-only display)
    try:
        pm = PERSONA_RE.search(s)
        if pm:
            t = pm.group(1).strip().lower()
            sv = pm.group(2).strip().lower()
            if t:
                globals()["persona_tone"] = t
            if sv:
                globals()["persona_sarcasm"] = (sv in ("on", "true", "1", "yes"))
            _refresh_needed = True
        else:
            tm = TONE_RE.search(s)
            if tm:
                globals()["persona_tone"] = tm.group(1).strip().lower()
                _refresh_needed = True
            sm = SARCASM_RE.search(s)
            if sm:
                sv = sm.group(1).strip().lower()
                globals()["persona_sarcasm"] = (sv in ("on", "true", "1", "yes"))
                _refresh_needed = True
    except Exception:
        pass

    # --- State detection (robust + heuristics) ---
    has_state_tag = "[STATE]" in s  # used to avoid duplicate echo
    new_state = None

    m = STATE_RE.search(s)
    if m:
        if m.group(2):       # OLD -> NEW
            new_state = m.group(2)
        elif m.group(3):     # NEW
            new_state = m.group(3)
    else:
        mw = STATE_WORD_RE.search(s)
        if mw:
            new_state = mw.group(1)
        elif SLEEP_HINT_RE.search(s):
            new_state = "SLEEPING"
        elif s.lstrip().startswith(">"):
            new_state = "SPEAKING"

    # Apply state if valid and changed (whitelist to block junk like "TE")
    if new_state:
        candidate = (new_state or "").strip().upper()
        if candidate in VALID_STATES and candidate != current_state:
            old_state = current_state
            current_state = candidate
            if not state_queue or state_queue[-1] != candidate:
                state_queue.append(candidate)
            if not has_state_tag:
                syn = f"[STATE] {old_state} -> {candidate}"
                if _last_state_log != syn:
                    try:
                        log_buffer.append(style_line(syn, tone="status"))
                    except Exception:
                        log_buffer.append(syn)
                    _last_state_log = syn
                    _log_dirty = True
            _refresh_needed = True

    # --- Routing to Chat / Logs ---
    try:
        is_spoken = ("[TTS]" in s) or s.lstrip().startswith(">")
        is_status = any(tag in s for tag in (
            "[STATE]", "[EVENT]", "[Tail]", "[GUI]",
            "[PERSONA]", "[TONE]", "[SARCASM]", "[DEV]"
        ))
        is_error = ("error" in low) or ("[err]" in low) or ("traceback" in low)

        if is_spoken:
            chat_buffer.append(style_line(s.strip(), tone=_tone_for_line(s)))
            _chat_dirty = True

        if is_status or is_error:
            line_for_logs = _badge_for_logs(s)
            if "[STATE]" in line_for_logs:
                if (_last_state_log or "") != line_for_logs.strip():
                    try:
                        log_buffer.append(style_line(line_for_logs, tone=_tone_for_line(s)))
                    except Exception:
                        log_buffer.append(line_for_logs)
                    _last_state_log = line_for_logs.strip()
                    _log_dirty = True
            else:
                try:
                    log_buffer.append(style_line(line_for_logs, tone=_tone_for_line(s)))
                except Exception:
                    log_buffer.append(line_for_logs)
                _log_dirty = True

    except Exception:
        if ("[TTS]" in s) or s.lstrip().startswith(">"):
            chat_buffer.append(s.strip()); _chat_dirty = True
        if any(tag in s for tag in (
            "[STATE]", "[EVENT]", "[Tail]", "[GUI]",
            "[PERSONA]", "[TONE]", "[SARCASM]"
        )) or ("error" in low):
            log_buffer.append(_badge_for_logs(s)); _log_dirty = True

    while len(chat_buffer) > CHAT_MAX_LINES:
        chat_buffer.popleft()
    while len(log_buffer) > LOG_MAX_LINES:
        log_buffer.popleft()

    _refresh_needed = True

def _on_tailer_status(msg: str):
    # Send tail/status notices to LOGS (not Chat), but DO NOT bump last_update_ts.
    global _log_dirty, _refresh_needed
    try:
        log_buffer.append(style_line(msg, tone="status"))
    except Exception:
        log_buffer.append(msg)
    _log_dirty = True
    _refresh_needed = True


def _on_tailer_error(msg: str):
    global _log_dirty, _refresh_needed, last_update_ts, hb_seconds
    try:
        log_buffer.append(style_line(msg, tone="error"))
    except Exception:
        log_buffer.append(msg)
    last_update_ts = datetime.now()
    heartbeat.reset()  # ← errors also reset timer
    _log_dirty = True
    _refresh_needed = True
# -------------------------------
# UI refresh scheduling
# -------------------------------
def _update_panes():
    """Delegate to panes.refresh_ui with smart autoscroll (show current_state for reliability)."""
    global _chat_dirty, _log_dirty, _refresh_needed

    state_text = current_state  # RR02: render current_state (not queue head) for dev-preview reliability
    hb_text    = _human_when(last_update_ts)
    chat_text  = _compose(chat_buffer)
    log_text   = _compose(log_buffer)

    refresh_ui(state_text, hb_text, chat_text, log_text, _chat_dirty, _log_dirty)

    # Reflect persona read-outs in header (read-only)
    try:
        dpg.set_value("tone_label", f"Tone: {persona_tone}")
    except Exception:
        pass
    try:
        dpg.set_value("sarcasm_label", "Sarcasm: on" if persona_sarcasm else "Sarcasm: off")
    except Exception:
        pass

    _chat_dirty = False
    _log_dirty  = False
    _refresh_needed = False

def schedule_recurring_update():
    """Frame tick: handle dwell/snap + repaint panes when needed.
    NOTE: Do NOT touch hb_label here; the heartbeat singleton owns it.
    """
    frames_per_tick = max(1, int(POLL_INTERVAL_SEC * 60))  # ~every POLL_INTERVAL_SEC

    def _tick(sender=None, app_data=None):
        try:
            # Maintain queued-state dwell progression
            _advance_state_if_needed()

            # Auto-snap from SPEAKING to SLEEPING after idle
            try:
                if current_state == "SPEAKING" and last_update_ts:
                    idle = (datetime.now() - last_update_ts).total_seconds()
                    if idle >= SPEAKING_IDLE_SEC:
                        globals()["current_state"] = "SLEEPING"
                        globals()["_refresh_needed"] = True
            except Exception:
                pass

            # Redraw panes only if something changed (chat/log/state/persona)
            if _refresh_needed:
                _update_panes()

            # DO NOT call set_hb_text() or set_value("hb_label", ...) here.
            # The heartbeat singleton updates the label independently.

        except Exception:
            pass
        finally:
            # Re-arm next tick
            try:
                dpg.set_frame_callback(dpg.get_frame_count() + frames_per_tick, _tick)
            except Exception:
                pass

    # Kick off the loop once
    try:
        dpg.set_frame_callback(dpg.get_frame_count() + 1, _tick)
    except Exception:
        pass
# -------------------------------
# Bootstrap
# -------------------------------
def build_gui():
    init_ui(LOG_PATH)

def run():
    print("[GUI] Starting Piper GUI (LL-R03).")
    path = Path(LOG_PATH)

    # Tailer thread
    tailer = Tailer(path=path, from_start=TAIL_FROM_START, poll_interval=POLL_INTERVAL_SEC)
    tailer.start_in_thread(on_line=_consume_line, on_status=_on_tailer_status, on_error=_on_tailer_error)

    # DPG lifecycle (correct order)
    dpg.create_context()
    apply_theme_if_enabled()
    build_gui()  # creates window tagged "root" in panes.init_ui

    dpg.create_viewport(title="Piper GUI", width=L.WINDOW.WIDTH, height=L.WINDOW.HEIGHT)
    dpg.setup_dearpygui()
    dpg.show_viewport()

    # Now it's safe to calibrate + hook resize
    try:
        calibrate_to_viewport()
    except Exception:
        pass

    def _on_vp_resize(sender, app_data):
        try:
            calibrate_to_viewport()
        except Exception:
            pass
    try:
        dpg.set_viewport_resize_callback(_on_vp_resize)
    except Exception:
        pass
    try:
        heartbeat.start(POLL_INTERVAL_SEC, "hb_label")
    except Exception:
        pass
    # Startup message (appears in Chat)
    try:
        mode = "start" if TAIL_FROM_START else "end"
        chat_buffer.append(style_line(f"Tailing: {path} (from {mode})", tone="status"))
    except Exception:
        chat_buffer.append(f"Tailing: {path} (from {mode})")

    globals()["_chat_dirty"] = True
    globals()["_refresh_needed"] = True
    _update_panes()
    # Start independent header heartbeat (ticks hb_label every ~POLL_INTERVAL_SEC)
    try:
        heartbeat.start(poll_sec=POLL_INTERVAL_SEC)  # sets up its own frame-loop
        heartbeat.reset()  # seed to 0s now
    except Exception:
        pass



    # Seed heartbeat so the timer starts ticking immediately
    globals()["last_update_ts"] = datetime.now()
    globals()["heartbeat_start_ts"] = globals()["last_update_ts"]
    globals()["hb_seconds"] = 0
    # Heartbeat simple counter (ticks every frame; reset on real updates)
    hb_seconds: int = 0

    # Frame callbacks
    schedule_recurring_update()

    # Dev dwell speed-up (flag-gated)
    try:
        if os.getenv("PIPER_UI_DEV_INPUT", "0") == "1":
            globals()["STATE_DWELL_SEC"] = float(os.environ.get("PIPER_UI_STATE_DWELL_SEC", "0.35"))
            try:
                log_buffer.append(style_line(f"[DEV][TRACE] dwell={STATE_DWELL_SEC:.2f}s", tone="status"))
                globals()["_log_dirty"] = True
                globals()["_refresh_needed"] = True
                _update_panes()
            except Exception:
                pass
    except Exception:
        pass

    # ---------- Dev tools & helpers ----------
    dev_handle = None

    def _emit_to_logs(text: str, tone: str = "info"):
        """Emit into Logs; route special tags/errors through normal ingest so header/state/clock update.
        Paint only when the UI is fully ready to avoid startup crashes.
        """
        try:
            t = (text or "").strip()
            low = t.lower()

            # Treat error-like lines as meaningful even if they don't start with a tag
            errorish = ("error" in low) or ("traceback" in low) or ("[err]" in low) or t.lstrip().startswith("(!)")

            # Lines that should update GUI state/labels must be parsed, not just appended.
            should_ingest = (
                t.lstrip().startswith("[PERSONA]")
                or t.lstrip().startswith("[TONE]")
                or t.lstrip().startswith("[SARCASM]")
                or t.lstrip().startswith("[DEV]")    # dev injections
                or t.lstrip().startswith("[ERR]")    # explicit error tag
                or "[STATE]" in t
                or "[EVENT]" in t
                or "[TTS]" in t
                or t.startswith(">")
                or errorish                            # ← HB-P1k: catch '(!) ...', RuntimeError, traceback, etc.
            )

            if should_ingest:
                # Route through the normal pipeline → updates persona/state/chat/logs + heartbeat
                _consume_line(t)
                if globals().get("_UI_READY", False):
                    _update_panes()
                return

            # Otherwise, append directly to Logs (no parsing side-effects)
            try:
                log_buffer.append(style_line(t, tone=tone))
            except Exception:
                log_buffer.append(t)
            globals()["_log_dirty"] = True
            globals()["_refresh_needed"] = True
            if globals().get("_UI_READY", False):
                _update_panes()

        except Exception:
            # Never let logging break the GUI
            pass

    # visible trace
    _emit_to_logs(
        f"[DEV][TRACE] PIPER_UI_DEV_INPUT={os.getenv('PIPER_UI_DEV_INPUT','<unset>')}  dev_tools={'ok' if attach_dev_tools else 'None'}",
        "status",
    )

    # Build dev panes + attach child CLI only when flag is enabled
    try:
        if attach_dev_tools is not None and os.getenv("PIPER_UI_DEV_INPUT", "0") == "1":
            dev_handle = attach_dev_tools(
                get_state=lambda: globals().get("current_state", "?"),
                get_queue=lambda: list(globals().get("state_queue", [])),
                get_last_ts=lambda: globals().get("last_update_ts", None),
                log_emit=_emit_to_logs,
                tone_for_line=_tone_for_line,
                badge_for_logs=_badge_for_logs,
            )
    except Exception as e:
        _emit_to_logs(f"[DEV][WARN] attach_dev_tools failed: {e}", "error")

    # UI is now fully constructed; enable safe painting from helpers
    globals()["_UI_READY"] = True

    # Event loop + cleanup
    try:
        dpg.start_dearpygui()
    finally:
        try:
            if dev_handle is not None:
                dev_handle.stop()
        except Exception:
            pass
        dpg.destroy_context()
        print("[GUI] Piper GUI closed.")

def main():
    run()

if __name__ == "__main__":
    main()
