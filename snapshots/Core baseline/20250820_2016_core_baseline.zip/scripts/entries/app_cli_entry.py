# scripts/entries/app_cli_entry.py
import os
import sys

# Ensure project root on path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from core.startup import print_banner

def main():
    print_banner(file_label=__file__)

    # Normal prompt loop (no Core wiring here; CLI entry is just a shell)
    print("Piper is ready. Type 'exit' to quit.")
    if os.getenv("PIPER_TEST") == "1":
        return

    try:
        while True:
            s = input("\nYou: ")
            if s.strip().lower() in {"exit", "quit", "bye"}:
                print("[CORE] sandbox=exit")
                break
    except KeyboardInterrupt:
        print("\n[CORE] interrupted, shutting down")

if __name__ == "__main__":
    main()
