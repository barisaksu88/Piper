# scripts/make_snapshot.py
from __future__ import annotations
import zipfile
from pathlib import Path
from datetime import datetime

def include(p: Path) -> bool:
    # Keep .py / tests; skip __pycache__ and runtime artifacts
    if any(part == "__pycache__" for part in p.parts):
        return False
    if p.suffix not in {".py", ".txt"} and p.is_file() and "tests" not in p.parts:
        return False
    return True

def main():
    root = Path(__file__).resolve().parents[1]   # -> C:\Piper
    scripts_dir = root / "scripts"
    tests_dir = scripts_dir / "tests"
    snapshots = root / "snapshots"
    snapshots.mkdir(exist_ok=True)

    stamp = datetime.now().strftime("%Y%m%d_%H%M")
    out = snapshots / f"{stamp}_core_baseline.zip"

    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for base in (scripts_dir, tests_dir):
            if not base.exists():
                continue
            for p in base.rglob("*"):
                if p.is_file() and include(p):
                    z.write(p, p.relative_to(root))

    print(f"[SNAPSHOT] created {out}")

if __name__ == "__main__":
    main()
