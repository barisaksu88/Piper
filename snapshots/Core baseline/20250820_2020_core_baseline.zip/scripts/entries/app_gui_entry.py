# scripts/entries/app_gui_entry.py
import os
import sys

# Ensure project root on path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from core.startup import print_banner

def main():
    print_banner(file_label=__file__)

    # Try to start Dear PyGui adapter if present; otherwise exit gracefully.
    try:
        try:
            from scripts.ui.dpg_app import run_app as _run  # preferred name
        except ModuleNotFoundError:
            from ui.dpg_app import run_app as _run  # type: ignore
    except Exception:
        _run = None

    if _run is None:
        print("[UI] dpg_app not found; GUI entry placeholder exiting.")
        return

    try:
        _run()
    except KeyboardInterrupt:
        print("\n[UI] interrupted, closing")

if __name__ == "__main__":
    main()
