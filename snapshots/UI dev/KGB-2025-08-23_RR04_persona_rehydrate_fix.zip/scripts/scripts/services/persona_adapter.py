# C:\Piper\scripts\services\persona_adapter.py
# PV09 Persona/Voice – runtime profile save/load (export/import)
from __future__ import annotations
import copy
import importlib, sys, time

try:
    from scripts import personality
except Exception:
    try:
        import personality
    except Exception:
        personality = None

_last_loaded_at = 0.0
_last_load_error = None
_DEFAULT_GREETING = "Hello sir!"
_DEFAULT_MAX_LEN = 280
_DEFAULT_TONE_PRESETS = {
    "greet":       {"prefix": "",     "suffix": "", "end": "!"},
    "info":        {"prefix": "",     "suffix": "", "end": "."},
    "status":      {"prefix": "✓ ",   "suffix": "", "end": "."},
    "about":       {"prefix": "",     "suffix": "", "end": "."},
    "confirm":     {"prefix": "✔ ",   "suffix": "", "end": "."},
    "thinking":    {"prefix": "… ",   "suffix": "", "end": "…"},
    "error":       {"prefix": "(!) ", "suffix": "", "end": "."},
    "error_hard":  {"prefix": "✖ ",   "suffix": "", "end": "."},
    "neutral":     {"prefix": "",     "suffix": "", "end": "."},
}

# ---------- runtime overrides ----------
_runtime = {
    "sarcasm": None,   # None = follow personality.py; True/False = override
    "max_len": None,   # None = follow personality.py; int = override
    "tones":   {},     # e.g., {"error": {"prefix": "!! ", "end": "."}}
}

# ----- personality accessors -----
def reload_persona():
    """
    Hot-reload personality.py (read-only import). Returns (ok: bool, message: str).
    """
    global _last_loaded_at, _last_load_error
    try:
        # Determine module name used for import
        mod_name = "personality"
        if mod_name in sys.modules:
            importlib.reload(sys.modules[mod_name])
        else:
            importlib.import_module(mod_name)

        # After reload, (re)read attributes personality.GREETING, TONES, MAX_LEN, etc.
        # If your adapter caches values, rehydrate them here from sys.modules[mod_name].
        persona = sys.modules[mod_name]
        _rehydrate_from_persona(persona)  # <-- this calls your existing logic to load GREETING/TONES/MAX_LEN

        _last_loaded_at = time.time()
        _last_load_error = None
        return True, f"Reloaded personality.py at {time.strftime('%H:%M:%S')}."
    except Exception as e:
        _last_load_error = str(e)
        return False, f"Reload failed: {e!s}"

def _get_attr(name: str, default):
    if personality is None:
        return default
    return getattr(personality, name, default)

def get_greeting() -> str:
    return str(_get_attr("GREETING", _DEFAULT_GREETING))

def max_len() -> int:
    ov = _runtime["max_len"]
    if isinstance(ov, int) and ov > 0:
        return ov
    return int(_get_attr("MAX_RESPONSE_CHARS", _DEFAULT_MAX_LEN))

def _get_base_tone_presets() -> dict:
    presets = _get_attr("TONE_PRESETS", None)
    if not isinstance(presets, dict):
        return dict(_DEFAULT_TONE_PRESETS)
    merged = dict(_DEFAULT_TONE_PRESETS)
    for k, v in presets.items():
        if isinstance(v, dict):
            merged[k] = {**_DEFAULT_TONE_PRESETS.get(k, {}), **v}
    return merged

def _get_tone_presets() -> dict:
    base = _get_base_tone_presets()
    overrides = _runtime.get("tones", {})
    for tone, cfg in overrides.items():
        if isinstance(cfg, dict):
            base[tone] = {**base.get(tone, {}), **cfg}
    return base

def _persona_sarcasm_default() -> bool:
    return bool(_get_attr("SARCASM", False))

# ----- runtime setters/getters -----
def set_runtime_sarcasm(value: bool | None): _runtime["sarcasm"] = value
def get_runtime_sarcasm() -> bool | None: return _runtime["sarcasm"]

def set_runtime_max_len(value: int | None):
    if value is None:
        _runtime["max_len"] = None
        return
    try:
        v = int(value)
        if v < 10: v = 10
        _runtime["max_len"] = v
    except Exception:
        pass

def get_runtime_max_len() -> int | None: return _runtime["max_len"]

# ----- runtime tone editor API -----
def list_tones() -> list[str]:
    return sorted(_get_tone_presets().keys())

def show_tone(tone: str) -> dict:
    p = _get_tone_presets()
    return dict(p.get(tone, {}))

def set_tone_field(tone: str, field: str, value: str) -> None:
    if tone not in _get_tone_presets():
        base = _get_base_tone_presets().get("neutral", {"prefix": "", "suffix": "", "end": "."})
        _runtime["tones"][tone] = dict(base)
    if tone not in _runtime["tones"]:
        _runtime["tones"][tone] = {}
    if field not in ("prefix", "suffix", "end"):
        return
    _runtime["tones"][tone][field] = value

def clear_tone(tone: str) -> None:
    if tone in _runtime["tones"]:
        del _runtime["tones"][tone]

# ----- export/import profiles -----
def export_runtime_dict() -> dict:
    """Return a deep copy of the current runtime overrides (safe to JSON)."""
    return copy.deepcopy(_runtime)

def import_runtime_dict(state: dict) -> None:
    """Load runtime overrides from a dict."""
    if not isinstance(state, dict):
        return
    sarcasm = state.get("sarcasm", None)
    maxl = state.get("max_len", None)
    tones = state.get("tones", {})
    set_runtime_sarcasm(sarcasm if sarcasm in (True, False, None) else None)
    set_runtime_max_len(maxl if isinstance(maxl, int) or maxl is None else None)
    if isinstance(tones, dict):
        _runtime["tones"] = {}
        for tone, cfg in tones.items():
            if isinstance(cfg, dict):
                # only allow known keys
                filtered = {}
                for k in ("prefix", "suffix", "end"):
                    if k in cfg and isinstance(cfg[k], str):
                        filtered[k] = cfg[k]
                if filtered:
                    _runtime["tones"][tone] = filtered

# ----- styling core -----
def _apply_style(text: str, tone: str, sarcasm: bool) -> str:
    if not text: return text
    t = text.strip()

    presets = _get_tone_presets()
    p = presets.get((tone or "neutral").lower(), presets["neutral"])

    if p.get("end") and not t.endswith((".", "!", "…")):
        t += p["end"]
    if p.get("prefix"):
        t = f"{p['prefix']}{t}"
    if p.get("suffix"):
        t = f"{t}{p['suffix']}"

    if sarcasm:
        aside = " (obviously)."
        if len(t) + len(aside) <= max_len():
            t += aside
    return t

def style_line(text: str, tone: str = "neutral", sarcasm: bool | None = None) -> str:
    if sarcasm is None:
        sarcasm = _runtime["sarcasm"]
        if sarcasm is None:
            sarcasm = _persona_sarcasm_default()
    styled = _apply_style(str(text), tone, sarcasm)
    limit = max_len()
    if len(styled) <= limit:
        return styled
    ellipsis = "…"
    return styled[: max(0, limit - len(ellipsis))] + ellipsis
