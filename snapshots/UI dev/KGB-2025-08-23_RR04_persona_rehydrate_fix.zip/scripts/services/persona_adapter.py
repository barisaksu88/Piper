# C:\Piper\scripts\services\persona_adapter.py
# PV09 Persona/Voice – runtime profile save/load (export/import)
from __future__ import annotations
import copy
import importlib, sys, time

# personality.py is user-owned/read-only; we only read it.
try:
    from scripts import personality as _scripts_personality
    personality = _scripts_personality
except Exception:
    try:
        import personality as _root_personality
        personality = _root_personality
    except Exception:
        personality = None  # graceful fallback

_last_loaded_at = 0.0
_last_load_error = None

# ---------------- Defaults (safe fallbacks) ----------------
_DEFAULT_GREETING = "Hello sir!"
_DEFAULT_MAX_LEN = 280
_DEFAULT_TONE_PRESETS = {
    "greet":       {"prefix": "",     "suffix": "", "end": "!"},
    "info":        {"prefix": "",     "suffix": "", "end": "."},
    "status":      {"prefix": "✓ ",   "suffix": "", "end": "."},
    "about":       {"prefix": "",     "suffix": "", "end": "."},
    "confirm":     {"prefix": "✔ ",   "suffix": "", "end": "."},
    "thinking":    {"prefix": "… ",   "suffix": "", "end": "…"},
    "error":       {"prefix": "(!) ", "suffix": "", "end": "."},
    "error_hard":  {"prefix": "✖ ",   "suffix": "", "end": "."},
    "neutral":     {"prefix": "",     "suffix": "", "end": "."},
}

# ---------- runtime overrides ----------
_runtime = {
    "sarcasm": None,   # None = follow personality.py; True/False = override
    "max_len": None,   # None = follow personality.py; int = override
    "tones":   {},     # e.g., {"error": {"prefix": "!! ", "end": "."}}
}
# ---- compat shims + persona rehydrate (inserted by RR04) ----
def set_greeting(value: str) -> None:
    """Update fallback greeting from personality.py."""
    global _DEFAULT_GREETING
    try:
        _DEFAULT_GREETING = str(value) if value is not None else _DEFAULT_GREETING
    except Exception:
        pass

def set_max_len_default(value: int) -> None:
    """Update fallback max length from personality.py."""
    global _DEFAULT_MAX_LEN
    try:
        v = int(value)
        if v > 0:
            _DEFAULT_MAX_LEN = v
    except Exception:
        pass

def set_sarcasm_default(flag: bool) -> None:
    """No-op shim to keep API stable."""
    return None

def set_tones_default(presets: dict) -> None:
    """Merge personality tone presets onto our defaults."""
    global _DEFAULT_TONE_PRESETS
    try:
        if isinstance(presets, dict):
            merged = dict(_DEFAULT_TONE_PRESETS)
            for k, v in presets.items():
                if isinstance(v, dict):
                    merged[k] = {**_DEFAULT_TONE_PRESETS.get(k, {}), **v}
            _DEFAULT_TONE_PRESETS = merged
    except Exception:
        pass

def _rehydrate_from_persona(persona_mod):
    """
    Pull fresh values from the personality module into the adapter's fallback cache.
    Accepts either legacy or current field names.
    """
    try:
        if hasattr(persona_mod, "GREETING"):
            set_greeting(persona_mod.GREETING)
        # Accept either MAX_LEN or MAX_RESPONSE_CHARS
        if hasattr(persona_mod, "MAX_LEN"):
            set_max_len_default(int(persona_mod.MAX_LEN))
        elif hasattr(persona_mod, "MAX_RESPONSE_CHARS"):
            set_max_len_default(int(persona_mod.MAX_RESPONSE_CHARS))
        if hasattr(persona_mod, "SARCASM"):
            set_sarcasm_default(bool(persona_mod.SARCASM))
        # Accept either TONES or TONE_PRESETS
        if hasattr(persona_mod, "TONES"):
            set_tones_default(dict(persona_mod.TONES))
        elif hasattr(persona_mod, "TONE_PRESETS"):
            set_tones_default(dict(persona_mod.TONE_PRESETS))
    except Exception:
        # Keep runtime as-is on partial issues
        pass
# ---- end RR04 insert ----


# ---------------- Internal helpers ----------------
def _get_attr(name: str, default):
    if personality is None:
        return default
    return getattr(personality, name, default)

def _persona_sarcasm_default() -> bool:
    return bool(_get_attr("SARCASM", False))

# ---------------- Compat shims for defaults ----------------
# These are called by _rehydrate_from_persona(); keep them no-ops unless useful.
def set_greeting(value: str) -> None:
    # We read GREETING dynamically; keep a fallback sync for safety.
    global _DEFAULT_GREETING
    try:
        _DEFAULT_GREETING = str(value) if value is not None else _DEFAULT_GREETING
    except Exception:
        pass

def set_max_len_default(value: int) -> None:
    # Let MAX_LEN from personality influence our fallback when runtime override is absent.
    global _DEFAULT_MAX_LEN
    try:
        v = int(value)
        if v > 0:
            _DEFAULT_MAX_LEN = v
    except Exception:
        pass

def set_sarcasm_default(flag: bool) -> None:
    # Sarcasm default comes from personality at read time; no cache needed.
    # Kept for compatibility; intentionally a no-op.
    return None

def set_tones_default(presets: dict) -> None:
    # Merge provided defaults onto our built-ins for future fallbacks.
    global _DEFAULT_TONE_PRESETS
    try:
        if isinstance(presets, dict):
            merged = dict(_DEFAULT_TONE_PRESETS)
            for k, v in presets.items():
                if isinstance(v, dict):
                    merged[k] = {**_DEFAULT_TONE_PRESETS.get(k, {}), **v}
            _DEFAULT_TONE_PRESETS = merged
    except Exception:
        pass

# ---------------- personality.py rehydrate/reload ----------------
def _rehydrate_from_persona(persona_mod):
    """
    Pull fresh values from the personality module into the adapter's fallback cache.
    Accepts either legacy or current field names.
    """
    try:
        if hasattr(persona_mod, "GREETING"):
            set_greeting(persona_mod.GREETING)
        # Accept either MAX_LEN or MAX_RESPONSE_CHARS
        if hasattr(persona_mod, "MAX_LEN"):
            set_max_len_default(int(persona_mod.MAX_LEN))
        elif hasattr(persona_mod, "MAX_RESPONSE_CHARS"):
            set_max_len_default(int(persona_mod.MAX_RESPONSE_CHARS))
        if hasattr(persona_mod, "SARCASM"):
            set_sarcasm_default(bool(persona_mod.SARCASM))
        # Accept either TONES or TONE_PRESETS
        if hasattr(persona_mod, "TONES"):
            set_tones_default(dict(persona_mod.TONES))
        elif hasattr(persona_mod, "TONE_PRESETS"):
            set_tones_default(dict(persona_mod.TONE_PRESETS))
    except Exception:
        # Keep runtime as-is on partial issues
        pass

def reload_persona():
    """
    Hot-reload personality.py (read-only import). Returns (ok: bool, message: str).
    Works for either import path: 'personality' or 'scripts.personality'.
    """
    global personality, _last_loaded_at, _last_load_error
    try:
        importlib.invalidate_caches()
        # Try to reload whichever is present; otherwise import fresh.
        mod_obj = None
        if "personality" in sys.modules:
            mod_obj = importlib.reload(sys.modules["personality"])
        elif "scripts.personality" in sys.modules:
            mod_obj = importlib.reload(sys.modules["scripts.personality"])
        else:
            try:
                mod_obj = importlib.import_module("personality")
            except Exception:
                mod_obj = importlib.import_module("scripts.personality")
        personality = mod_obj
        _rehydrate_from_persona(mod_obj)
        _last_loaded_at = time.time()
        _last_load_error = None
        return True, f"Reloaded personality at {time.strftime('%H:%M:%S')}."
    except Exception as e:
        _last_load_error = str(e)
        return False, f"Reload failed: {e!s}"

# ---------------- Public getters / runtime overrides ----------------
def get_greeting() -> str:
    # Dynamic read from personality, fallback to (possibly updated) default
    return str(_get_attr("GREETING", _DEFAULT_GREETING))

def max_len() -> int:
    ov = _runtime["max_len"]
    if isinstance(ov, int) and ov > 0:
        return ov
    # Accept either MAX_LEN or legacy MAX_RESPONSE_CHARS
    return int(_get_attr("MAX_LEN", _get_attr("MAX_RESPONSE_CHARS", _DEFAULT_MAX_LEN)))

def set_runtime_sarcasm(value: bool | None): _runtime["sarcasm"] = value
def get_runtime_sarcasm() -> bool | None: return _runtime["sarcasm"]

def set_runtime_max_len(value: int | None):
    if value is None:
        _runtime["max_len"] = None
        return
    try:
        v = int(value); _runtime["max_len"] = max(10, v)
    except Exception:
        pass

def get_runtime_max_len() -> int | None: return _runtime["max_len"]

# ---------------- Tones (defaults + overrides) ----------------
def _get_base_tone_presets() -> dict:
    # Accept either TONE_PRESETS or TONES in personality.py
    presets = _get_attr("TONE_PRESETS", None) or _get_attr("TONES", None)
    if not isinstance(presets, dict):
        return dict(_DEFAULT_TONE_PRESETS)
    merged = dict(_DEFAULT_TONE_PRESETS)
    for k, v in presets.items():
        if isinstance(v, dict):
            merged[k] = {**_DEFAULT_TONE_PRESETS.get(k, {}), **v}
    return merged

def _get_tone_presets() -> dict:
    base = _get_base_tone_presets()
    overrides = _runtime.get("tones", {})
    for tone, cfg in overrides.items():
        if isinstance(cfg, dict):
            base[tone] = {**base.get(tone, {}), **cfg}
    return base

def list_tones() -> list[str]:
    return sorted(_get_tone_presets().keys())

def show_tone(tone: str) -> dict:
    p = _get_tone_presets()
    return dict(p.get(tone, {}))

def set_tone_field(tone: str, field: str, value: str) -> None:
    if tone not in _get_tone_presets():
        base = _get_base_tone_presets().get("neutral", {"prefix": "", "suffix": "", "end": "."})
        _runtime["tones"][tone] = dict(base)
    if tone not in _runtime["tones"]:
        _runtime["tones"][tone] = {}
    if field not in ("prefix", "suffix", "end"):
        return
    _runtime["tones"][tone][field] = value

def clear_tone(tone: str) -> None:
    if tone in _runtime["tones"]:
        del _runtime["tones"][tone]

# ---------------- Export / Import ----------------
def export_runtime_dict() -> dict:
    """Return a deep copy of the current runtime overrides (safe to JSON)."""
    return copy.deepcopy(_runtime)

def import_runtime_dict(state: dict) -> None:
    """Load runtime overrides from a dict."""
    if not isinstance(state, dict):
        return
    sarcasm = state.get("sarcasm", None)
    maxl = state.get("max_len", None)
    tones = state.get("tones", {})
    set_runtime_sarcasm(sarcasm if sarcasm in (True, False, None) else None)
    set_runtime_max_len(maxl if isinstance(maxl, int) or maxl is None else None)
    if isinstance(tones, dict):
        _runtime["tones"] = {}
        for tone, cfg in tones.items():
            if isinstance(cfg, dict):
                # only allow known keys
                filtered = {}
                for k in ("prefix", "suffix", "end"):
                    if k in cfg and isinstance(cfg[k], str):
                        filtered[k] = cfg[k]
                if filtered:
                    _runtime["tones"][tone] = filtered

# ---------------- Styling core ----------------
def _apply_style(text: str, tone: str, sarcasm: bool) -> str:
    if not text:
        return text
    t = text.strip()

    presets = _get_tone_presets()
    p = presets.get((tone or "neutral").lower(), presets["neutral"])

    if p.get("end") and not t.endswith((".", "!", "…")):
        t += p["end"]
    if p.get("prefix"):
        t = f"{p['prefix']}{t}"
    if p.get("suffix"):
        t = f"{t}{p['suffix']}"

    if sarcasm:
        aside = " (obviously)."
        if len(t) + len(aside) <= max_len():
            t += aside
    return t

def style_line(text: str, tone: str = "neutral", sarcasm: bool | None = None) -> str:
    if sarcasm is None:
        sarcasm = _runtime["sarcasm"]
        if sarcasm is None:
            sarcasm = _persona_sarcasm_default()
    styled = _apply_style(str(text), tone, sarcasm)
    limit = max_len()
    if len(styled) <= limit:
        return styled
    ellipsis = "…"
    return styled[: max(0, limit - len(ellipsis))] + ellipsis
