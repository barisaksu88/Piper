# LAYOUT/LOOK – LL04C independent, intent-based autoscroll (final, avatar-ready)
from __future__ import annotations
import os
import time
import dearpygui.dearpygui as dpg

# ---------- layout ----------
VIEWPORT_W = 1316
VIEWPORT_H = 720
LEFT_W     = int(VIEWPORT_W * 0.58)
RIGHT_W    = VIEWPORT_W - LEFT_W - 250
ROW_H      = VIEWPORT_H - 120
PAD        = 12

# ---------- state colors ----------
STATE_COLORS = {
    "SLEEPING":  (128, 128, 128, 255),
    "WAKING":    (255, 165,   0, 255),
    "LISTENING": ( 70, 130, 180, 255),
    "THINKING":  (255, 215,   0, 255),
    "SPEAKING":  (  0, 200, 100, 255),
}
_DEFAULT_DOT = (200, 200, 200, 255)
_DWELL_SEC   = 0.35

_last_state  = None
_last_change = 0.0

# ---------- autoscroll control ----------
_first_chat  = True
_first_logs  = True

# user-intent autofollow flags (True = follow to bottom)
_chat_autofollow = True
_logs_autofollow = True

# multi-frame snapping windows (only if autofollow True)
_chat_stick_frames = 0
_logs_stick_frames = 0

# detect continued growth of scrollable height; require stability before releasing
_chat_last_max = 0.0
_logs_last_max = 0.0
_chat_growth_stable = 0
_logs_growth_stable = 0

# detect user scroll (track last y-scroll)
_chat_last_scroll = 0.0
_logs_last_scroll = 0.0

# tolerance for "at bottom"
_EPS = 28.0  # px

# ---------- copy helpers ----------
def _copy_chat():
    try:
        dpg.set_clipboard_text(dpg.get_value("chat_text") or "")
    except Exception:
        pass

def _copy_logs():
    try:
        dpg.set_clipboard_text(dpg.get_value("log_text") or "")
    except Exception:
        pass

# ---------- avatar helpers (single, consistent version) ----------
_AVATAR_TEX = None          # texture id (if image loaded)
_AVATAR_IMG_W = 0           # source image width
_AVATAR_IMG_H = 0           # source image height
_AVATAR_W, _AVATAR_H = 48, 48  # header icon size

def _ensure_texture_registry():
    if not dpg.does_item_exist("texture_registry"):
        with dpg.texture_registry(tag="texture_registry"):
            pass

def _load_avatar_from_file(path: str):
    """Load file into a static texture and remember dimensions; return texture id or None."""
    global _AVATAR_TEX, _AVATAR_IMG_W, _AVATAR_IMG_H
    if not path or not os.path.exists(path):
        return None
    try:
        _ensure_texture_registry()
        w, h, c, data = dpg.load_image(path)
        tex_id = dpg.add_static_texture(w, h, data, parent="texture_registry")
        _AVATAR_TEX, _AVATAR_IMG_W, _AVATAR_IMG_H = tex_id, w, h
        return tex_id
    except Exception:
        return None

# ---------- helpers ----------
def _update_bottom_padding():
    """Let the user scroll ~1/3 pane beyond last line."""
    try:
        _, h = dpg.get_item_rect_size("chat_scroll")
        dpg.configure_item("chat_pad", height=max(12, int(h * 0.33)))
    except Exception:
        pass
    try:
        _, h = dpg.get_item_rect_size("logs_scroll")
        dpg.configure_item("logs_pad", height=max(12, int(h * 0.33)))
    except Exception:
        pass

def _is_at_bottom(tag: str) -> bool:
    try:
        cur = dpg.get_y_scroll(tag)
        mx  = dpg.get_y_scroll_max(tag)
        return (mx - cur) <= _EPS
    except Exception:
        return True  # default sticky until mounted

def _scroll_to_bottom(tag: str):
    def _snap():
        try:
            dpg.set_y_scroll(tag, dpg.get_y_scroll_max(tag))
        except Exception:
            pass
    _snap()
    try:
        fc = dpg.get_frame_count()
        for k in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10):
            dpg.set_frame_callback(fc + k, lambda s=None, a=None, u=None: _snap())
    except Exception:
        pass

def _apply_wraps():
    try:
        w,_ = dpg.get_item_rect_size("chat_scroll")
        dpg.configure_item("chat_text", wrap=max(0, int(w - PAD)))
    except Exception:
        pass
    try:
        w,_ = dpg.get_item_rect_size("logs_scroll")
        dpg.configure_item("log_text", wrap=max(0, int(w - PAD)))
    except Exception:
        pass

def _update_state_dot(state_text: str):
    global _last_state, _last_change
    now = time.time()
    if state_text != _last_state:
        _last_state, _last_change = state_text, now
    show_state = _last_state if (now - _last_change) < _DWELL_SEC and _last_state else state_text
    color = STATE_COLORS.get(show_state, _DEFAULT_DOT)
    try:
        dpg.configure_item("state_dot_circle", fill=color)
    except Exception:
        pass
    try:
        dpg.set_value("state_label", f"State: {state_text}")
    except Exception:
        pass

def _shorten_path(p: str, max_chars: int = 72) -> str:
    try:
        s = str(p)
        if len(s) <= max_chars:
            return s
        head = s[: max_chars // 2 - 2].rstrip("\\/")
        tail = s[-(max_chars // 2 - 3):]
        return f"{head}…{tail}"
    except Exception:
        return p

def _ensure_pane_theme():
    if dpg.does_item_exist("pane_pad_theme"):
        return "pane_pad_theme"
    with dpg.theme(tag="pane_pad_theme"):
        with dpg.theme_component(dpg.mvAll):
            dpg.add_theme_style(dpg.mvStyleVar_WindowPadding, 10, 8, category=dpg.mvThemeCat_Core)
            dpg.add_theme_style(dpg.mvStyleVar_ItemSpacing,    6, 4, category=dpg.mvThemeCat_Core)
            dpg.add_theme_style(dpg.mvStyleVar_FramePadding,   6, 4, category=dpg.mvThemeCat_Core)
    return "pane_pad_theme"

# ---------- Public API ----------
def init_ui(log_path: str) -> None:
    """Root fixed & primary. Non-scrolling headers. Dedicated scroll windows for content."""
    if dpg.does_item_exist("root"):
        dpg.delete_item("root")

    root = dpg.add_window(
        tag="root",
        pos=(0, 0),
        no_title_bar=True,
        no_move=True,
        no_resize=True,
        no_scrollbar=True,
    )
    dpg.set_item_width("root",  VIEWPORT_W)
    dpg.set_item_height("root", VIEWPORT_H)
    dpg.set_primary_window("root", True)

    pane_theme = _ensure_pane_theme()

    # ---- App header (NO avatar) ----
    with dpg.group(parent=root, tag="header_row", horizontal=True):
        dpg.add_text("Piper GUI", tag="title_label")
        dpg.add_spacer(width=16)
        with dpg.drawlist(width=14, height=14, tag="state_dot_draw"):
            dpg.draw_circle(center=(7, 7), radius=6, color=(0, 0, 0, 0),
                            fill=_DEFAULT_DOT, tag="state_dot_circle")
        dpg.add_spacer(width=6)
        dpg.add_text("State: SLEEPING", tag="state_label")
        dpg.add_spacer(width=12); dpg.add_text("·"); dpg.add_spacer(width=8)
        dpg.add_text("Last update: -", tag="hb_label")
        dpg.add_spacer(width=12); dpg.add_text("·"); dpg.add_spacer(width=8)
        dpg.add_text("Tone: neutral", tag="tone_label")
        dpg.add_spacer(width=12); dpg.add_text("·"); dpg.add_spacer(width=8)
        dpg.add_text("Sarcasm: off", tag="sarcasm_label")
        dpg.add_spacer(width=12); dpg.add_text("·"); dpg.add_spacer(width=8)
        dpg.add_text(_shorten_path(log_path), tag="tailing_label")
    # ---- Body row ----
    with dpg.group(parent=root, tag="body_row", horizontal=True):
        # Chat
        with dpg.group(tag="chat_container"):
            with dpg.group(horizontal=True):
                dpg.add_text("Chat", tag="chat_hdr")
                dpg.add_spacer(width=10)
                dpg.add_button(label="Copy Chat", callback=_copy_chat)
                dpg.add_spacer(width=10)
                dpg.add_text("[⏸ autoscroll]", tag="chat_autoscroll_badge", show=False)
            dpg.add_separator()
            dpg.add_spacer(height=6)
            with dpg.child_window(tag="chat_scroll", width=LEFT_W, height=ROW_H,
                                  autosize_x=False, autosize_y=False):
                dpg.add_text("", tag="chat_text", wrap=LEFT_W - PAD)
                dpg.add_spacer(tag="chat_pad", height=8)
        dpg.bind_item_theme("chat_scroll", pane_theme)

        dpg.add_spacer(width=12)

        # Logs + Avatar (stacked right column)
        with dpg.group(tag="logs_container"):
            with dpg.group(horizontal=True):
                dpg.add_text("Logs", tag="logs_hdr")
                dpg.add_spacer(width=10)
                dpg.add_button(label="Copy Logs", callback=_copy_logs)
                dpg.add_spacer(width=10)
                dpg.add_text("[⏸ autoscroll]", tag="logs_autoscroll_badge", show=False)
            dpg.add_separator()
            dpg.add_spacer(height=6)

            with dpg.child_window(tag="logs_scroll", width=(RIGHT_W - 12), height=ROW_H,
                                  autosize_x=False, autosize_y=False):
                dpg.add_text("", tag="log_text", wrap=RIGHT_W - PAD)
                dpg.add_spacer(tag="logs_pad", height=8)
            dpg.bind_item_theme("logs_scroll", pane_theme)

            dpg.add_spacer(height=8)

            # Avatar panel (bottom right; resized in calibrate_to_viewport)
            avatar_path = os.environ.get("PIPER_UI_AVATAR", "").strip()
            if not avatar_path:
                avatar_path = r"C:\Piper\Library\Urban Night Glow.png"
            _load_avatar_from_file(avatar_path)  # sets _AVATAR_TEX and dims if present

            with dpg.child_window(tag="avatar_panel", width=(RIGHT_W - 12), height=180,
                                  autosize_x=False, autosize_y=False, no_scrollbar=True):
                if _AVATAR_TEX:
                    dpg.add_image(_AVATAR_TEX, tag="avatar_image")
                else:
                    with dpg.drawlist(tag="avatar_draw"):
                        dpg.draw_rectangle((0,0),(10,10),color=(0,0,0,0))  # will be redrawn on calibrate

def calibrate_to_viewport() -> None:
    """Match root to viewport; split right column into logs + avatar; scale avatar."""
    try:
        # Safe guards for lifecycle
        try:
            running = dpg.is_dearpygui_running()
        except Exception:
            running = True
        if not running or not dpg.does_item_exist("root"):
            return

        w = dpg.get_viewport_client_width()
        h = dpg.get_viewport_client_height()
        dpg.set_item_width("root",  w)
        dpg.set_item_height("root", h)

        # header height
        try:
            _, hdr_h = dpg.get_item_rect_size("header_row")
        except Exception:
            hdr_h = 40

        body_h = max(120, int(h - hdr_h - 70))

        # Left pane sizing
        if dpg.does_item_exist("chat_scroll"):
            dpg.configure_item("chat_scroll", height=body_h)

        # Right pane split
        logs_h_ratio = 0.3
        logs_h = max(120, int(body_h * logs_h_ratio))
        avatar_h = max(120, body_h - logs_h - 8)

        if dpg.does_item_exist("logs_scroll"):
            dpg.configure_item("logs_scroll", height=logs_h)
        if dpg.does_item_exist("avatar_panel"):
            dpg.configure_item("avatar_panel", height=avatar_h)

        # Avatar sizing / fallback drawing
        try:
            ap_w, ap_h = dpg.get_item_rect_size("avatar_panel")
            avail_w = max(50, ap_w - 12)
            avail_h = max(50, ap_h - 12)

            if dpg.does_item_exist("avatar_image") and _AVATAR_TEX and _AVATAR_IMG_W and _AVATAR_IMG_H:
                scale = min(avail_w / _AVATAR_IMG_W, avail_h / _AVATAR_IMG_H)
                tw, th = max(1, int(_AVATAR_IMG_W * scale)), max(1, int(_AVATAR_IMG_H * scale))
                dpg.configure_item("avatar_image", width=tw, height=th)
            elif dpg.does_item_exist("avatar_draw"):
                dpg.delete_item("avatar_draw", children_only=True)
                dpg.draw_rectangle((0,0), (ap_w, ap_h),
                                   color=(0,0,0,0),
                                   fill=(24,48,96,255),
                                   rounding=12,
                                   parent="avatar_draw")
                dpg.draw_text((ap_w//2 - 12, ap_h//2 - 24), "P",
                              size=48, color=(230,240,255,255),
                              parent="avatar_draw")
        except Exception:
            pass

        _apply_wraps()
        _update_bottom_padding()
    except Exception:
        pass

def refresh_ui(
    state_text: str,
    heartbeat_text: str,
    chat_text: str,
    log_text: str,
    chat_dirty: bool,
    log_dirty: bool
) -> None:
    """Update labels and content with robust, intent-based autoscroll for both panes."""
    global _first_chat, _first_logs
    global _chat_autofollow, _logs_autofollow
    global _chat_stick_frames, _logs_stick_frames
    global _chat_last_max, _logs_last_max, _chat_growth_stable, _logs_growth_stable
    global _chat_last_scroll, _logs_last_scroll

    # Header updates
    try:
        dpg.set_value("hb_label", heartbeat_text)
    except Exception:
        pass
    _update_state_dot(state_text)

    # Wraps
    _apply_wraps()

    # Current scroll & bottom status
    try:
        chat_cur = dpg.get_y_scroll("chat_scroll")
        chat_max = dpg.get_y_scroll_max("chat_scroll")
        chat_at_bottom = (chat_max - chat_cur) <= _EPS
    except Exception:
        chat_cur = _chat_last_scroll
        chat_max = _chat_last_max
        chat_at_bottom = True

    try:
        logs_cur = dpg.get_y_scroll("logs_scroll")
        logs_max = dpg.get_y_scroll_max("logs_scroll")
        logs_at_bottom = (logs_max - logs_cur) <= _EPS
    except Exception:
        logs_cur = _logs_last_scroll
        logs_max = _logs_last_max
        logs_at_bottom = True

    # Detect explicit user scroll up (only hovered pane)
    try:
        chat_hover = dpg.is_item_hovered("chat_scroll")
    except Exception:
        chat_hover = False
    try:
        logs_hover = dpg.is_item_hovered("logs_scroll")
    except Exception:
        logs_hover = False

    if chat_hover and (chat_cur < _chat_last_scroll - 0.5) and not chat_at_bottom:
        _chat_autofollow = False
        _chat_stick_frames = 0
    if logs_hover and (logs_cur < _logs_last_scroll - 0.5) and not logs_at_bottom:
        _logs_autofollow = False
        _logs_stick_frames = 0

    # Re-enable autofollow when the user reaches bottom
    if chat_at_bottom:
        _chat_autofollow = True
    if logs_at_bottom:
        _logs_autofollow = True

    prev_chat_max = chat_max
    prev_logs_max = logs_max

    # 1) Apply content
    if chat_dirty:
        try:
            dpg.set_value("chat_text", chat_text)
            if _chat_autofollow:
                _scroll_to_bottom("chat_scroll")

            if _first_chat:
                _scroll_to_bottom("chat_scroll")
                _first_chat = False
                _chat_stick_frames = 6
                _chat_growth_stable = 0
            else:
                if _chat_autofollow:
                    _chat_stick_frames = max(_chat_stick_frames, 10)

            try:
                chat_max = dpg.get_y_scroll_max("chat_scroll")
            except Exception:
                chat_max = prev_chat_max

            if _chat_autofollow and (chat_max > prev_chat_max + 0.5):
                _chat_stick_frames = max(_chat_stick_frames, 18)
                _chat_growth_stable = 0
            else:
                _chat_growth_stable = min(_chat_growth_stable + 1, 3)
                if _chat_growth_stable >= 2:
                    _chat_stick_frames = min(_chat_stick_frames, 6)
        except Exception:
            pass

    if log_dirty:
        try:
            dpg.set_value("log_text", log_text)
            if _logs_autofollow:
                _scroll_to_bottom("logs_scroll")

            if _first_logs:
                _scroll_to_bottom("logs_scroll")
                _first_logs = False
                _logs_stick_frames = 6
                _logs_growth_stable = 0
            else:
                if _logs_autofollow:
                    _logs_stick_frames = max(_logs_stick_frames, 10)

            try:
                logs_max = dpg.get_y_scroll_max("logs_scroll")
            except Exception:
                logs_max = prev_logs_max

            if _logs_autofollow and (logs_max > prev_logs_max + 0.5):
                _logs_stick_frames = max(_logs_stick_frames, 18)
                _logs_growth_stable = 0
            else:
                _logs_growth_stable = min(_logs_growth_stable + 1, 3)
                if _logs_growth_stable >= 2:
                    _logs_stick_frames = min(_logs_stick_frames, 6)
        except Exception:
            pass

    # 2) During stick windows, keep snapping — only if autofollow True
    try:
        if _chat_stick_frames > 0 and _chat_autofollow:
            _scroll_to_bottom("chat_scroll")
            _chat_stick_frames -= 1
    except Exception:
        pass
    try:
        if _logs_stick_frames > 0 and _logs_autofollow:
            _scroll_to_bottom("logs_scroll")
            _logs_stick_frames -= 1
    except Exception:
        pass

    # 3) Badges reflect current bottom
    try:
        dpg.configure_item("chat_autoscroll_badge", show=(not _chat_autofollow) and (not chat_at_bottom))
    except Exception:
        pass
    try:
        dpg.configure_item("logs_autoscroll_badge", show=(not _logs_autofollow) and (not logs_at_bottom))
    except Exception:
        pass

    # 4) Remember last scrolls for next user‑scroll detection
    _chat_last_scroll = chat_cur
    _logs_last_scroll = logs_cur
    _chat_last_max    = chat_max
    _logs_last_max    = logs_max
