# LAYOUT/LOOK Rails – LL-R03 thin bootstrap
# - Theme lives in ui/theme.py
# - Tailer lives in ui/tailer.py
# - Panes (init_ui / refresh_ui / calibrate_to_viewport) live in ui/panes.py
# - This file wires them together + keeps minimal GUI-specific state

from __future__ import annotations

# --- DEV INPUT (IN01) imports: safe when flag is off
import os
import re
from collections import deque
from pathlib import Path
from datetime import datetime

import dearpygui.dearpygui as dpg
from ui.theme import apply_theme_if_enabled  # theme hook

# Persona styling passthrough (Services)
try:
    from scripts.services.persona_adapter import style_line
except Exception:
    from services.persona_adapter import style_line

# Tailer + Panes adapters
try:
    from scripts.ui.tailer import Tailer
except Exception:
    from ui.tailer import Tailer

try:
    from scripts.ui.panes import init_ui, refresh_ui, calibrate_to_viewport
except Exception:
    from ui.panes import init_ui, refresh_ui, calibrate_to_viewport

# Try both package paths for ipc_child (depends on how you run modules)
try:
    from scripts.ui.ipc_child import spawn_cli  # our new helper (IN01)
except Exception:
    try:
        from ui.ipc_child import spawn_cli
    except Exception:
        spawn_cli = None  # type: ignore

# Handle to the child CLI (dev-only). None when flag is off or unavailable.
_PIPER_CLI_CHILD = None
# -------------------------------
# Config (UI-only)
# -------------------------------
LOG_PATH = os.environ.get("PIPER_CORE_LOG", r"C:\Piper\run\core.log")
TAIL_FROM_START = os.environ.get("PIPER_UI_TAIL_FROM_START", "0") == "1"
POLL_INTERVAL_SEC = float(os.environ.get("PIPER_UI_POLL_SEC", "0.25"))
STATE_DWELL_SEC = float(os.environ.get("PIPER_UI_STATE_DWELL_SEC", "1.1"))
SPEAKING_IDLE_SEC = float(os.environ.get("PIPER_UI_SPEAKING_IDLE_SEC", "3.5"))

# -------------------------------
# Buffers & State (UI-only)
# -------------------------------
LOG_MAX_LINES = 1200
CHAT_MAX_LINES = 600
log_buffer  = deque(maxlen=LOG_MAX_LINES)
chat_buffer = deque(maxlen=CHAT_MAX_LINES)

current_state = "SLEEPING"

# Persona read-outs (UI-only, read-only)
persona_tone = os.environ.get("PIPER_PERSONA_TONE", "neutral").strip().lower()
persona_sarcasm = (os.environ.get("PIPER_PERSONA_SARCASM", "off").strip().lower() in ("1","on","true","yes"))

state_queue = deque()
last_update_ts: datetime | None = None
last_display_switch: datetime | None = None

# Dirty flags (set True when NEW line appended; cleared after refresh)
_chat_dirty = False
_log_dirty = False

# Render tick nudge
_refresh_needed = False

# -------------------------------
# Classifiers (robust parsing)
# -------------------------------
STATE_RE = re.compile(
    r"\[STATE\]\s*(?:([A-Za-z_]+)\s*(?:→|->)\s*([A-Za-z_]+)|([A-Za-z_]+))",
    re.IGNORECASE
)
STATE_WORD_RE = re.compile(r"\b(sleeping|waking|listening|thinking|speaking)\b", re.IGNORECASE)
SLEEP_HINT_RE = re.compile(r"(going to sleep|back to sleep)", re.IGNORECASE)

# Persona toggle lines (from CLI/log)
PERSONA_RE  = re.compile(r"\[PERSONA\].*?\btone\s*=\s*([A-Za-z]+).*?\bsarcasm\s*=\s*(on|off|true|false|1|0)", re.IGNORECASE)
TONE_RE     = re.compile(r"\[TONE\]\s*([A-Za-z]+)", re.IGNORECASE)
SARCASM_RE  = re.compile(r"\[SARCASM\]\s*(on|off|true|false|1|0)", re.IGNORECASE)

# -------------------------------
# Small helpers
# -------------------------------
def _tone_for_line(line: str) -> str:
    low = (line or "").lower()
    if "[state]" in low:
        return "status"
    if "[event]" in low or "[tts]" in low:
        return "info"
    if "error" in low or "[err]" in low or "traceback" in low:
        return "error"
    return "info"

def _badge_for_logs(line: str) -> str:
    """Return a copy of line with an ASCII badge prefix when appropriate (Logs only)."""
    s = (line or "").strip()
    low = s.lower()
    if "[state]" in low:
        return s if s.startswith("[STATE]") else s.replace(s[:s.find("[state]")+7], "[STATE]")
    if "traceback" in low or "[err]" in low or "error:" in low or "exception" in low:
        return s if s.startswith("[ERR]") else f"[ERR] {s}"
    if "[event]" in low and not s.startswith("[EVT]"):
        return s.replace("[EVENT]", "[EVT]")
    if "[tts]" in low and not s.startswith("[TTS]"):
        return s.replace("[TTS]", "[TTS]")
    return s

def _compose(buf: deque) -> str:
    return "\n".join(buf)

def _human_when(ts: datetime | None) -> str:
    if not ts:
        return "Last update: -"
    delta = (datetime.now() - ts).total_seconds()
    return f"Last update: {int(delta)}s ago"

def _advance_state_if_needed():
    """Advance state_queue head after dwell time so transient states are visible (legacy behavior)."""
    global last_display_switch
    if not state_queue:
        state_queue.append(current_state)
        last_display_switch = datetime.now()
        return
    head = state_queue[0]
    if head != current_state and (datetime.now() - last_display_switch).total_seconds() >= STATE_DWELL_SEC:
        state_queue.popleft()
        last_display_switch = datetime.now()

def _is_chat_line(line: str) -> bool:
    """
    Chat pane shows ONLY Piper's spoken output.
    Accept either explicit [TTS] or lines that start with '>'.
    """
    s = (line or "")
    if not s.strip():
        return False
    if s.startswith("? ") or "Tailing:" in s or s.startswith("[GUI]"):
        return False
    if "[TTS]" in s:
        return True
    if s.lstrip().startswith(">"):
        return True
    return False

# -------------------------------
# Tailer → GUI ingestion
# -------------------------------
def _consume_line(line: str):
    """Ingest one log line; route to Chat or Logs; request UI refresh."""
    global last_update_ts, current_state, _chat_dirty, _log_dirty, _refresh_needed

    # Normalize and timestamp
    if line.endswith("\n"):
        line = line[:-1]
    last_update_ts = datetime.now()

    # Persona toggles (read-only display)
    try:
        pm = PERSONA_RE.search(line)
        if pm:
            t = pm.group(1).strip().lower()
            s = pm.group(2).strip().lower()
            if t:
                globals()["persona_tone"] = t
            if s:
                globals()["persona_sarcasm"] = (s in ("on","true","1","yes"))
            globals()["_refresh_needed"] = True
        else:
            tm = TONE_RE.search(line)
            if tm:
                globals()["persona_tone"] = tm.group(1).strip().lower()
                globals()["_refresh_needed"] = True
            sm = SARCASM_RE.search(line)
            if sm:
                s = sm.group(1).strip().lower()
                globals()["persona_sarcasm"] = (s in ("on","true","1","yes"))
                globals()["_refresh_needed"] = True
    except Exception:
        pass

    # Track state transitions (robust + heuristics)
    m = STATE_RE.search(line)
    new_state = None
    if m:
        if m.group(2):   # HEAD → NEW  (or ->)
            new_state = m.group(2)
        elif m.group(3): # NEW
            new_state = m.group(3)
    else:
        mw = STATE_WORD_RE.search(line)
        if mw:
            new_state = mw.group(1)
        elif line.lstrip().startswith(">"):
            new_state = "SPEAKING"
        elif SLEEP_HINT_RE.search(line):
            new_state = "SLEEPING"

    if new_state:
        new_state = (new_state or "").strip().upper()
        if new_state and new_state != current_state:
            old_state = current_state
            current_state = new_state
            if not state_queue or state_queue[-1] != new_state:
                state_queue.append(new_state)
            # Emit a synthetic STATE transition into Logs so it updates
            try:
                log_buffer.append(style_line(f"[STATE] {old_state} -> {new_state}", tone="status"))
            except Exception:
                log_buffer.append(f"[STATE] {old_state} -> {new_state}")
            globals()["_log_dirty"] = True
            globals()["_refresh_needed"] = True

    # Route to Chat and Logs with proper split
    try:
        s = (line or "")
        low = s.lower()
        is_spoken = ("[TTS]" in s) or s.lstrip().startswith(">")
        is_status = any(tag in s for tag in ("[STATE]", "[EVENT]", "[Tail]", "[GUI]"))
        is_error  = ("error" in low or "[err]" in low or "traceback" in low)

        if is_spoken:
            chat_buffer.append(style_line(s.strip(), tone=_tone_for_line(s)))
            _chat_dirty = True

        if is_status or is_error:
            log_buffer.append(style_line(_badge_for_logs(s), tone=_tone_for_line(s)))
            _log_dirty = True

    except Exception:
        s = (line or "")
        if ("[TTS]" in s) or s.lstrip().startswith(">"):
            chat_buffer.append(s.strip()); _chat_dirty = True
        if any(tag in s for tag in ("[STATE]", "[EVENT]", "[Tail]", "[GUI]")) or "error" in s.lower():
            log_buffer.append(_badge_for_logs(s)); _log_dirty = True

    # Bound sizes
    while len(chat_buffer) > CHAT_MAX_LINES: chat_buffer.popleft()
    while len(log_buffer) > LOG_MAX_LINES:   log_buffer.popleft()

    # Hint the UI to refresh soon (frame loop will pick this up)
    _refresh_needed = True

def _on_tailer_status(msg: str):
    # Send tail/status notices to LOGS (not Chat), so Logs is never empty
    global _log_dirty, _refresh_needed, last_update_ts
    try:
        log_buffer.append(style_line(msg, tone="status"))
    except Exception:
        log_buffer.append(msg)
    last_update_ts = datetime.now()
    _log_dirty = True
    _refresh_needed = True

def _on_tailer_error(msg: str):
    global _log_dirty, _refresh_needed, last_update_ts
    try:
        log_buffer.append(style_line(msg, tone="error"))
    except Exception:
        log_buffer.append(msg)
    last_update_ts = datetime.now()
    _log_dirty = True
    _refresh_needed = True

# -------------------------------
# UI refresh scheduling
# -------------------------------
def _update_panes():
    """Delegate to panes.refresh_ui with smart autoscroll."""
    global _chat_dirty, _log_dirty, _refresh_needed
    state_text = current_state
    hb_text = _human_when(last_update_ts)
    chat_text = _compose(chat_buffer)
    log_text  = _compose(log_buffer)

    refresh_ui(state_text, hb_text, chat_text, log_text, _chat_dirty, _log_dirty)

    # Reflect persona read-outs in header (read-only)
    try:
        dpg.set_value("tone_label", f"Tone: {persona_tone}")
    except Exception:
        pass
    try:
        dpg.set_value("sarcasm_label", "Sarcasm: on" if persona_sarcasm else "Sarcasm: off")
    except Exception:
        pass

    _chat_dirty = False
    _log_dirty = False
    _refresh_needed = False

def schedule_recurring_update():
    """DPG 2.1-compatible recurring tick via set_frame_callback (never dies on error)."""
    frames_per_tick = max(1, int(POLL_INTERVAL_SEC * 60))

    def _tick(sender=None, app_data=None):
        try:
            _advance_state_if_needed()

            # Idle fallback: if stuck in SPEAKING with no new lines, snap back
            try:
                if current_state == "SPEAKING" and last_update_ts:
                    idle = (datetime.now() - last_update_ts).total_seconds()
                    if idle >= SPEAKING_IDLE_SEC:
                        globals()["current_state"] = "SLEEPING"
                        globals()["_refresh_needed"] = True
            except Exception:
                pass

            if _refresh_needed:
                _update_panes()
            else:
                try:
                    dpg.set_value("hb_label", _human_when(last_update_ts))
                except Exception:
                    pass

        except Exception:
            pass
        finally:
            dpg.set_frame_callback(dpg.get_frame_count() + frames_per_tick, _tick)

    dpg.set_frame_callback(dpg.get_frame_count() + 1, _tick)

# -------------------------------
# Bootstrap
# -------------------------------
def build_gui():
    init_ui(LOG_PATH)

def run():
    print("[GUI] Starting Piper GUI (LL-R03).")
    path = Path(LOG_PATH)

    # Tailer thread
    tailer = Tailer(path=path, from_start=TAIL_FROM_START, poll_interval=POLL_INTERVAL_SEC)
    tailer.start_in_thread(on_line=_consume_line, on_status=_on_tailer_status, on_error=_on_tailer_error)

    # DPG lifecycle
    dpg.create_context()
    apply_theme_if_enabled()
    build_gui()  # <- creates window tagged "root" in panes.init_ui

    dpg.create_viewport(title="Piper GUI", width=1116, height=780)

    dpg.setup_dearpygui()
    dpg.show_viewport()

    # Now it's safe to calibrate + hook resize
    try:
        calibrate_to_viewport()
    except Exception:
        pass

    def _on_vp_resize(sender, app_data):
        try:
            calibrate_to_viewport()
        except Exception:
            pass
    try:
        dpg.set_viewport_resize_callback(_on_vp_resize)
    except Exception:
        pass

    # Startup message (appears in Chat)
    try:
        mode = "start" if TAIL_FROM_START else "end"
        chat_buffer.append(style_line(f"Tailing: {path} (from {mode})", tone="status"))
    except Exception:
        chat_buffer.append(f"Tailing: {path} (from {mode})")
    globals()["_chat_dirty"] = True
    globals()["_refresh_needed"] = True
    _update_panes()

    schedule_recurring_update()

    # ---------- IN01 hook: attach CLI child AFTER UI/tailer are ready, BEFORE main loop ----------
    cli_child = None

    # Visible trace in Logs pane
    try:
        log_buffer.append(style_line(
            f"[DEV][TRACE] PIPER_UI_DEV_INPUT={os.getenv('PIPER_UI_DEV_INPUT','<unset>')}  spawn_cli={'ok' if spawn_cli else 'None'}",
            tone="status"
        ))
    except Exception:
        log_buffer.append(f"[DEV][TRACE] PIPER_UI_DEV_INPUT={os.getenv('PIPER_UI_DEV_INPUT','<unset>')}  spawn_cli={'ok' if spawn_cli else 'None'}")
    globals()["_log_dirty"] = True
    globals()["_refresh_needed"] = True
    _update_panes()

    if os.getenv("PIPER_UI_DEV_INPUT", "0") == "1" and spawn_cli is not None:
        def _on_cli_line(line: str) -> None:
            # Mirror child stdout into the LOG pane directly
            try:
                s = _badge_for_logs(line)
                try:
                    log_buffer.append(style_line(s, tone=_tone_for_line(s)))
                except Exception:
                    log_buffer.append(s)
                globals()["_log_dirty"] = True
                globals()["_refresh_needed"] = True
            except Exception:
                pass

        try:
            global _PIPER_CLI_CHILD
            _PIPER_CLI_CHILD = spawn_cli(on_line=_on_cli_line)
            cli_child = _PIPER_CLI_CHILD
            try:
                log_buffer.append(style_line("[DEV] Attached CLI child (IN01)", tone="status"))
            except Exception:
                log_buffer.append("[DEV] Attached CLI child (IN01)")
            globals()["_log_dirty"] = True
            globals()["_refresh_needed"] = True
            _update_panes()
        except Exception as e:
            try:
                log_buffer.append(style_line(f"[DEV][WARN] Failed to attach CLI child: {e}", tone="error"))
            except Exception:
                log_buffer.append(f"[DEV][WARN] Failed to attach CLI child: {e}")
            globals()["_log_dirty"] = True
            globals()["_refresh_needed"] = True
            _update_panes()

        # ---------- IN02 hook: minimal Dev Input pane ----------
        if _PIPER_CLI_CHILD is not None:
            # Callbacks live inside run() to access closures safely
            def _dev_send_text(sender=None, app_data=None, user_data=None):
                try:
                    text = dpg.get_value("dev_input_text") or ""
                except Exception:
                    text = ""
                if not text.strip():
                    return
                ok = False
                try:
                    ok = _PIPER_CLI_CHILD.write(text)
                except Exception:
                    ok = False
                # Echo outcome to Logs
                echo = f"[DEV][Send] {'OK' if ok else 'FAIL'}: {text.strip()}"
                try:
                    log_buffer.append(style_line(echo, tone="status" if ok else "error"))
                except Exception:
                    log_buffer.append(echo)
                globals()["_log_dirty"] = True
                globals()["_refresh_needed"] = True
                _update_panes()
                # Clear box if success
                if ok:
                    try:
                        dpg.set_value("dev_input_text", "")
                    except Exception:
                        pass

            # Floating mini window (dev-only)
            with dpg.window(label="Dev Input", tag="dev_input_win", width=360, height=120, pos=(740, 30), no_collapse=False):
                dpg.add_input_text(
                    tag="dev_input_text",
                    label="Send to CLI",
                    hint="Type a command, press Enter",
                    on_enter=True,
                    callback=_dev_send_text
                )
                dpg.add_button(label="Send", callback=_dev_send_text)
            # ---------- end IN02 window ----------

    # --------------------------------------------------------------------------------------------

    try:
        dpg.start_dearpygui()
    finally:
        # Graceful cleanup for IN01 child on window close
        try:
            if cli_child is not None:
                cli_child.stop()
        except Exception:
            pass
        dpg.destroy_context()
        print("[GUI] Piper GUI closed.")
def main():
    run()

if __name__ == "__main__":
    main()
