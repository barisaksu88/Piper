# C:\Piper\scripts\ui\ipc_child.py
from __future__ import annotations

import os
import sys
import threading
import subprocess
import queue
import time
from dataclasses import dataclass
from typing import Callable, Optional

# Windows-friendly Popen flags (safe no-ops on POSIX)
CREATE_NO_WINDOW = 0x08000000 if os.name == "nt" else 0

@dataclass
class CLIChild:
    proc: subprocess.Popen
    _reader: threading.Thread
    _q: "queue.Queue[str]"
    _on_line: Callable[[str], None]
    _alive: threading.Event

    def is_alive(self) -> bool:
        return self._alive.is_set() and (self.proc.poll() is None)

    def write(self, text: str) -> bool:
        """Send a line to the child's stdin. Returns True on success."""
        if not self.is_alive():
            return False
        try:
            # Guarantee a single trailing newline; child REPL expects '\n'
            line = (text or "").rstrip("\r\n") + "\n"
            self.proc.stdin.write(line)
            self.proc.stdin.flush()
            return True
        except Exception:
            return False

    def stop(self, wait_seconds: float = 1.0) -> None:
        """Gracefully stop the child; fall back to terminate."""
        self._alive.clear()
        try:
            if self.proc.stdin:
                try:
                    self.proc.stdin.flush()
                except Exception:
                    pass
                try:
                    self.proc.stdin.close()
                except Exception:
                    pass
        except Exception:
            pass

        # Give the reader thread a moment to finish
        if self._reader.is_alive():
            self._reader.join(timeout=wait_seconds)

        # Try graceful shutdown
        if self.proc.poll() is None:
            try:
                self.proc.terminate()
            except Exception:
                pass

        # Last resort after grace period
        t0 = time.time()
        while self.proc.poll() is None and (time.time() - t0) < wait_seconds:
            time.sleep(0.05)
        if self.proc.poll() is None:
            try:
                self.proc.kill()
            except Exception:
                pass


def _make_env() -> dict:
    """Derive a safe environment for the child CLI."""
    env = os.environ.copy()
    # Ensure UTF-8 I/O behavior and no window pop on Windows
    env.setdefault("PYTHONIOENCODING", "utf-8")
    # Forward input enabled; core may key off this
    env.setdefault("PIPER_CORE_FORWARD_INPUT", "1")
    return env


def _reader_loop(proc: subprocess.Popen,
                 q: "queue.Queue[str]",
                 alive: threading.Event) -> None:
    """Continuously read child's stdout into a queue."""
    try:
        while alive.is_set():
            line = proc.stdout.readline()
            if not line:
                break
            q.put_nowait(line.rstrip("\r\n"))
    except Exception:
        pass
    finally:
        alive.clear()


def spawn_cli(on_line: Callable[[str], None],
              module: str = "entries.app_cli_entry") -> CLIChild:
    """
    Start the CLI as a child process and stream its stdout lines to `on_line`.

    Parameters
    ----------
    on_line: callable
        Called once per line from child stdout (already stripped).
    module: str
        Python module to run with `-m`. Defaults to Piper's CLI entry.

    Returns
    -------
    CLIChild
        Handle with is_alive(), write(text), and stop().
    """
    exe = sys.executable or "python"
    cmd = [exe, "-u", "-m", module]  # -u: unbuffered I/O

    proc = subprocess.Popen(
        cmd,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,   # merge for simplicity
        bufsize=1,                  # line-buffered
        universal_newlines=True,    # text mode
        env=_make_env(),
        creationflags=CREATE_NO_WINDOW
    )

    q: "queue.Queue[str]" = queue.Queue()
    alive = threading.Event()
    alive.set()

    reader = threading.Thread(
        target=_reader_loop,
        args=(proc, q, alive),
        name="PiperCLI-stdout-reader",
        daemon=True,
    )
    reader.start()

    # Fan-out thread: deliver lines to on_line() from the queue.
    def _deliver():
        while alive.is_set():
            try:
                line = q.get(timeout=0.2)
            except queue.Empty:
                # Check liveness periodically
                if proc.poll() is not None:
                    break
                continue
            try:
                on_line(line)
            except Exception:
                # Keep delivering even if a handler throws
                pass
        alive.clear()

    threading.Thread(target=_deliver, name="PiperCLI-deliver", daemon=True).start()

    return CLIChild(proc=proc, _reader=reader, _q=q, _on_line=on_line, _alive=alive)


def stdin_write(child: Optional[CLIChild], text: str) -> bool:
    """Convenience wrapper used by GUI code; safe if child is None."""
    if child is None:
        return False
    return child.write(text)
