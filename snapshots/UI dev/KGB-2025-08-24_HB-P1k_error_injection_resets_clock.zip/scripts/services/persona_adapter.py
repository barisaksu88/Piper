# C:\Piper\scripts\services\persona_adapter.py
# PV09 Persona/Voice – runtime profile save/load (export/import)
from __future__ import annotations
import copy, importlib, sys, time

# Try both import paths; this module never writes to personality.py
def _import_persona():
    try:
        import scripts.personality as p; return p
    except Exception:
        try:
            import personality as p; return p
        except Exception:
            return None

personality = _import_persona()

# -------- Defaults (safe fallbacks) --------
_DEFAULT_GREETING = "Hello sir!"
_DEFAULT_MAX_LEN  = 280
_DEFAULT_TONE_PRESETS = {
    "greet":      {"prefix": "",    "suffix": "", "end": "!"},
    "info":       {"prefix": "",    "suffix": "", "end": "."},
    "status":     {"prefix": "✓ ",  "suffix": "", "end": "."},
    "about":      {"prefix": "",    "suffix": "", "end": "."},
    "confirm":    {"prefix": "✔ ",  "suffix": "", "end": "."},
    "thinking":   {"prefix": "… ",  "suffix": "", "end": "…"},
    "error":      {"prefix": "(!) ","suffix": "", "end": "."},
    "error_hard": {"prefix": "✖ ",  "suffix": "", "end": "."},
    "neutral":    {"prefix": "",    "suffix": "", "end": "."},
}

# -------- Runtime overrides (None = follow personality.py) --------
_runtime = {"sarcasm": None, "max_len": None, "tones": {}}

# -------- Small helpers --------
def _get_attr(name: str, default):
    return getattr(personality, name, default) if personality else default

def _persona_sarcasm_default() -> bool:
    return bool(_get_attr("SARCASM", False))

# -------- Compat shims (used by rehydrate) --------
def set_greeting(v: str) -> None:
    global _DEFAULT_GREETING
    try: _DEFAULT_GREETING = str(v) if v is not None else _DEFAULT_GREETING
    except Exception: pass

def set_max_len_default(v: int) -> None:
    global _DEFAULT_MAX_LEN
    try:
        v = int(v)
        if v > 0: _DEFAULT_MAX_LEN = v
    except Exception: pass

def set_sarcasm_default(flag: bool) -> None:  # no-op, API compat
    return None

def set_tones_default(presets: dict) -> None:
    global _DEFAULT_TONE_PRESETS
    try:
        if isinstance(presets, dict):
            merged = dict(_DEFAULT_TONE_PRESETS)
            for k, cfg in presets.items():
                if isinstance(cfg, dict):
                    merged[k] = {**merged.get(k, {}), **cfg}
            _DEFAULT_TONE_PRESETS = merged
    except Exception: pass

def _rehydrate_from_persona(mod) -> None:
    try:
        if hasattr(mod, "GREETING"): set_greeting(mod.GREETING)
        if hasattr(mod, "MAX_LEN"): set_max_len_default(int(mod.MAX_LEN))
        elif hasattr(mod, "MAX_RESPONSE_CHARS"): set_max_len_default(int(mod.MAX_RESPONSE_CHARS))
        if hasattr(mod, "SARCASM"): set_sarcasm_default(bool(mod.SARCASM))
        if hasattr(mod, "TONES"): set_tones_default(dict(mod.TONES))
        elif hasattr(mod, "TONE_PRESETS"): set_tones_default(dict(mod.TONE_PRESETS))
    except Exception:
        pass

# -------- Public API: reload --------
_last_loaded_at = 0.0
_last_load_error = None

def reload_persona():
    """Hot-reload personality module; supports both import paths."""
    global personality, _last_loaded_at, _last_load_error
    try:
        importlib.invalidate_caches()
        mod = None
        # Reload whichever is present, else import fresh
        if "personality" in sys.modules:
            mod = importlib.reload(sys.modules["personality"])
        elif "scripts.personality" in sys.modules:
            mod = importlib.reload(sys.modules["scripts.personality"])
        else:
            try:
                mod = importlib.import_module("personality")
            except Exception:
                mod = importlib.import_module("scripts.personality")
        personality = mod
        _rehydrate_from_persona(mod)
        _last_loaded_at, _last_load_error = time.time(), None
        return True, f"Reloaded personality at {time.strftime('%H:%M:%S')}."
    except Exception as e:
        _last_load_error = str(e)
        return False, f"Reload failed: {e!s}"

# -------- Runtime setters/getters --------
def set_runtime_sarcasm(value: bool | None): _runtime["sarcasm"] = value
def get_runtime_sarcasm() -> bool | None:    return _runtime["sarcasm"]

def set_runtime_max_len(value: int | None):
    if value is None: _runtime["max_len"] = None; return
    try: _runtime["max_len"] = max(10, int(value))
    except Exception: pass

def get_runtime_max_len() -> int | None: return _runtime["max_len"]

# -------- Tones (defaults + overrides) --------
def _get_base_tone_presets() -> dict:
    presets = _get_attr("TONE_PRESETS", None) or _get_attr("TONES", None)
    if not isinstance(presets, dict):
        return dict(_DEFAULT_TONE_PRESETS)
    merged = dict(_DEFAULT_TONE_PRESETS)
    for k, v in presets.items():
        if isinstance(v, dict):
            merged[k] = {**merged.get(k, {}), **v}
    return merged

def _get_tone_presets() -> dict:
    base = _get_base_tone_presets()
    for tone, cfg in _runtime.get("tones", {}).items():
        if isinstance(cfg, dict):
            base[tone] = {**base.get(tone, {}), **cfg}
    return base

def list_tones() -> list[str]:
    return sorted(_get_tone_presets().keys())

def show_tone(tone: str) -> dict:
    return dict(_get_tone_presets().get(tone, {}))

def set_tone_field(tone: str, field: str, value: str) -> None:
    if tone not in _get_tone_presets():
        _runtime["tones"][tone] = dict(_get_base_tone_presets().get("neutral", {"prefix": "", "suffix": "", "end": "."}))
    if tone not in _runtime["tones"]:
        _runtime["tones"][tone] = {}
    if field in ("prefix", "suffix", "end"):
        _runtime["tones"][tone][field] = value

def clear_tone(tone: str) -> None:
    if tone in _runtime["tones"]:
        del _runtime["tones"][tone]

# -------- Export/Import --------
def export_runtime_dict() -> dict:
    return copy.deepcopy(_runtime)

def import_runtime_dict(state: dict) -> None:
    if not isinstance(state, dict): return
    set_runtime_sarcasm(state.get("sarcasm") if state.get("sarcasm") in (True, False, None) else None)
    set_runtime_max_len(state.get("max_len") if isinstance(state.get("max_len"), int) or state.get("max_len") is None else None)
    tones = state.get("tones", {})
    if isinstance(tones, dict):
        _runtime["tones"] = {}
        for tone, cfg in tones.items():
            if isinstance(cfg, dict):
                filtered = {k: v for k, v in cfg.items() if k in ("prefix", "suffix", "end") and isinstance(v, str)}
                if filtered: _runtime["tones"][tone] = filtered

# -------- Styling core --------
def get_greeting() -> str:
    return str(_get_attr("GREETING", _DEFAULT_GREETING))

def max_len() -> int:
    ov = _runtime["max_len"]
    if isinstance(ov, int) and ov > 0: return ov
    return int(_get_attr("MAX_LEN", _get_attr("MAX_RESPONSE_CHARS", _DEFAULT_MAX_LEN)))

def _apply_style(text: str, tone: str, sarcasm: bool) -> str:
    if not text: return text
    t = str(text).strip()
    p = _get_tone_presets().get((tone or "neutral").lower(), _get_tone_presets()["neutral"])
    if p.get("end") and not t.endswith((".", "!", "…")): t += p["end"]
    if p.get("prefix"): t = f"{p['prefix']}{t}"
    if p.get("suffix"): t = f"{t}{p['suffix']}"
    if sarcasm:
        aside = " (obviously)."
        if len(t) + len(aside) <= max_len(): t += aside
    return t

def style_line(text: str, tone: str = "neutral", sarcasm: bool | None = None) -> str:
    if sarcasm is None:
        sarcasm = _runtime["sarcasm"] if _runtime["sarcasm"] is not None else _persona_sarcasm_default()
    styled, limit = _apply_style(text, tone, sarcasm), max_len()
    if len(styled) <= limit: return styled
    ellipsis = "…"
    return styled[: max(0, limit - len(ellipsis))] + ellipsis
