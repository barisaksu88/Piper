# C:\Piper\scripts\entries\app_gui_entry.py
# LAYOUT/LOOK – LL13.1
# - Persona styling passthrough (Services.style_line)
# - Robust chunk tailer w/ encoding auto-detect (UTF-8 / UTF-16)
# - Chat vs Logs classifier (no duplication)
# - Smart autoscroll: only on new lines and only if user was at bottom
# - Periodic refresh + per-line refresh signal

from __future__ import annotations

import os
import time
import threading
from threading import Event
from collections import deque
from pathlib import Path
from datetime import datetime
import re

import dearpygui.dearpygui as dpg

# Persona styling passthrough (Services)
try:
    from scripts.services.persona_adapter import style_line
except Exception:
    from services.persona_adapter import style_line

# add this, with a fallback to relative import (mirrors persona import style)
try:
    from scripts.ui.theme import apply_theme_if_enabled
except Exception:
    from ui.theme import apply_theme_if_enabled


# -------------------------------
# Config
# -------------------------------
LOG_PATH = os.environ.get("PIPER_CORE_LOG", r"C:\Piper\run\core.log")
TAIL_FROM_START = os.environ.get("PIPER_UI_TAIL_FROM_START", "0") == "1"
ENABLE_CLEAN_THEME = os.environ.get("PIPER_UI_THEME", "").lower() == "clean"
POLL_INTERVAL_SEC = float(os.environ.get("PIPER_UI_POLL_SEC", "0.25"))  # GUI refresh cadence
STATE_DWELL_SEC = float(os.environ.get("PIPER_UI_STATE_DWELL_SEC", "1.1"))  # min time to show a state

# -------------------------------
# Buffers & State
# -------------------------------
LOG_MAX_LINES = 1200
CHAT_MAX_LINES = 600
log_buffer  = deque(maxlen=LOG_MAX_LINES)
chat_buffer = deque(maxlen=CHAT_MAX_LINES)

current_state = "SLEEPING"
state_queue = deque()
last_update_ts: datetime | None = None
last_display_switch: datetime | None = None

# When tail thread ingests new data, signal UI to refresh
_refresh_event = Event()

STATE_RE = re.compile(r"\[STATE\]\s*(?:([A-Z]+)\s*→\s*([A-Z]+)|([A-Z]+))")
INTERESTING_TAGS = ("[STATE]", "[EVENT]", "[TTS]")

# Smart autoscroll toggles
autoscroll_chat = True
autoscroll_logs = True
# Dirty flags: set to True only when NEW line is appended
_chat_dirty = False
_log_dirty = False

# Tail thread stop flag
_stop_tail = False

# -------------------------------
# Helpers
# -------------------------------
def _tone_for_line(line: str) -> str:
    low = (line or "").lower()
    if "[state]" in low:
        return "status"
    if "[event]" in low or "[tts]" in low:
        return "info"
    if "error" in low or "[err]" in low or "traceback" in low:
        return "error"
    return "info"

def _compose(buf: deque) -> str:
    return "\n".join(buf)

def _human_when(ts: datetime | None) -> str:
    if not ts:
        return "Last update: -"
    delta = (datetime.now() - ts).total_seconds()
    return f"Last update: {int(delta)}s ago"

def _state_color(name: str):
    # accessible palette
    return {
        "SLEEPING":  (130,130,130,255),  # gray
        "WAKING":    (255,170,0,255),    # orange
        "LISTENING": (0,155,255,255),    # blue
        "THINKING":  (185,95,255,255),   # purple
        "SPEAKING":  (0,200,120,255),    # green
    }.get(name, (160,160,160,255))

def _is_at_bottom(child_tag: str) -> bool:
    try:
        y = dpg.get_y_scroll(child_tag)
        h = dpg.get_y_scroll_max(child_tag)
        return (h - y) < 8  # within ~8px
    except Exception:
        return True

def _snap_to_bottom(child_tag: str):
    try:
        dpg.set_y_scroll(child_tag, dpg.get_y_scroll_max(child_tag))
    except Exception:
        pass

def _apply_wrap(text_tag: str, child_tag: str):
    try:
        width = max(320, int(dpg.get_item_rect_size(child_tag)[0]) - 24)
        dpg.configure_item(text_tag, wrap=width)
    except Exception:
        pass

def _is_chat_line(line: str) -> bool:
    """Decide if a log line should appear ONLY in the Chat pane."""
    s = (line or "").strip()
    if not s:
        return False

    # Skip tail/tech lines and GUI notices
    if s.startswith("? ") or "Tailing:" in s or s.startswith("[GUI]"):
        return False

    # Tagged human-facing events
    if any(tag in s for tag in INTERESTING_TAGS):
        return True

    # CLI style prompt/output and persona-styled speech
    if s.startswith(">"):
        return True

    # Persona markers (some shells may render as '?' but we filter '?' tech lines above)
    if s[:1] in {"✓", "✔", "✖", "…", "!", "?"}:
        return True

    # Plain lines with no bracket tags and no obvious error keywords
    lower = s.lower()
    looks_like_error = any(k in lower for k in (
        "traceback", "exception", "error:", "systemerror", "unicodeencodeerror"
    ))
    if not looks_like_error and "[" not in s:
        return True

    return False

# -------------------------------
# UI update & scheduling
# -------------------------------
def _advance_state_if_needed():
    """Advance state_queue head after dwell time so transient states are visible."""
    global last_display_switch
    if not state_queue:
        state_queue.append(current_state)
        last_display_switch = datetime.now()
        return

    head = state_queue[0]
    if head != current_state and (datetime.now() - last_display_switch).total_seconds() >= STATE_DWELL_SEC:
        state_queue.popleft()
        last_display_switch = datetime.now()

def _update_panes():
    """Smart autoscroll: only on new lines and only if user was already at bottom."""
    global autoscroll_chat, autoscroll_logs, _chat_dirty, _log_dirty

    # Before: detect whether user is at bottom
    chat_was_bottom = _is_at_bottom("chat_child")
    logs_was_bottom = _is_at_bottom("logs_child")
    if not chat_was_bottom: autoscroll_chat = False
    if not logs_was_bottom: autoscroll_logs = False

    # Update labels & buffers
    dpg.set_value("state_label", state_queue[0] if state_queue else current_state)
    dpg.configure_item("state_label", color=_state_color(state_queue[0] if state_queue else current_state))
    dpg.set_value("hb_label", _human_when(last_update_ts))
    dpg.set_value("chat_text", _compose(chat_buffer))
    dpg.set_value("log_text", _compose(log_buffer))

    # Wrap to container width
    _apply_wrap("chat_text", "chat_child")
    _apply_wrap("log_text", "logs_child")

    # After: if there was NEW content for a pane AND user was at bottom → snap once
    if _chat_dirty and autoscroll_chat and chat_was_bottom:
        _snap_to_bottom("chat_child")
    if _log_dirty and autoscroll_logs and logs_was_bottom:
        _snap_to_bottom("logs_child")

    # If user is now back at bottom, re-enable autoscroll
    if _is_at_bottom("chat_child"):
        autoscroll_chat = True
    if _is_at_bottom("logs_child"):
        autoscroll_logs = True

    # Clear dirty flags after handling
    _chat_dirty = False
    _log_dirty = False

def schedule_recurring_update():
    """
    Repeating update loop using set_frame_callback (DPG 2.1 compatible).
    Also checks a thread signal so we update immediately after new tail data.
    """
    frames_per_tick = max(1, int(POLL_INTERVAL_SEC * 60))

    def _tick(sender=None, app_data=None):
        if _refresh_event.is_set():
            _refresh_event.clear()
            _advance_state_if_needed()
            _update_panes()
        else:
            _advance_state_if_needed()
            _update_panes()
        dpg.set_frame_callback(dpg.get_frame_count() + frames_per_tick, _tick)

    dpg.set_frame_callback(dpg.get_frame_count() + 1, _tick)

# -------------------------------
# Tail file & ingestion
# -------------------------------
def _open_for_tail(path: Path):
    """
    Open text file with encoding auto-detect (UTF-8 vs UTF-16 LE/BE).
    Re-check on rotation/truncation.
    """
    try:
        with open(path, "rb") as fb:
            head = fb.read(4)
        if head.startswith(b"\xff\xfe"):   # UTF-16 LE BOM
            enc = "utf-16-le"
        elif head.startswith(b"\xfe\xff"): # UTF-16 BE BOM
            enc = "utf-16-be"
        else:
            enc = "utf-16-le" if b"\x00" in head else "utf-8"
    except Exception:
        enc = "utf-8"
    return open(path, "r", encoding=enc, errors="replace")

def _consume_line(line: str):
    """Ingest one log line; route to Chat or Logs; request UI refresh."""
    global last_update_ts, current_state, _chat_dirty, _log_dirty

    # Normalize and timestamp
    if line.endswith("\n"):
        line = line[:-1]
    last_update_ts = datetime.now()

    # State tracking
    m = STATE_RE.search(line)
    if m:
        new_state = current_state
        if m.group(2):
            new_state = m.group(2)
        elif m.group(3):
            new_state = m.group(3)
        if new_state != current_state:
            current_state = new_state
            if not state_queue or state_queue[-1] != new_state:
                state_queue.append(new_state)

    # Route to Chat OR Logs (no duplication)
    try:
        if _is_chat_line(line):
            chat_buffer.append(style_line(line.strip(), tone=_tone_for_line(line)))
            _chat_dirty = True
        else:
            log_buffer.append(style_line(line, tone=_tone_for_line(line)))
            _log_dirty = True
    except Exception:
        # Fallback without persona styling
        if _is_chat_line(line):
            chat_buffer.append(line.strip()); _chat_dirty = True
        else:
            log_buffer.append(line); _log_dirty = True

    # Bound sizes (in case personas shorten wrap)
    while len(chat_buffer) > CHAT_MAX_LINES:
        chat_buffer.popleft()
    while len(log_buffer) > LOG_MAX_LINES:
        log_buffer.popleft()

    # Signal UI refresh soon; try immediate enqueue
    _refresh_event.set()
    try:
        dpg.add_thread_task(_update_panes)  # type: ignore[attr-defined]
    except Exception:
        pass

def _tail_file(path: Path):
    """
    Non-blocking tail: poll the file and read raw chunks so we don't stall on readline()
    when the writer flushes in buffered chunks (PowerShell Tee-Object behavior).
    Handles: late creation, truncation/rotation, and partial trailing lines.
    """
    told_missing = False
    buf = ""  # carry-over for a partial line
    f = None
    CHUNK = 4096  # bytes per read

    while not _stop_tail:
        try:
            # Wait for file
            if f is None:
                if not path.exists():
                    if not told_missing:
                        try:
                            chat_buffer.append(style_line(
                                f"Waiting for log file: {path}. Tip: run CLI with tee to this path.", tone="status"))
                            log_buffer.append(style_line(f"[GUI] Waiting for log file: {path}", tone="status"))
                        except Exception:
                            pass
                        told_missing = True
                    time.sleep(max(0.1, POLL_INTERVAL_SEC))
                    continue
                f = _open_for_tail(path)
                try:
                    if not TAIL_FROM_START:
                        f.seek(0, os.SEEK_END)
                except Exception:
                    pass
                told_missing = False
                try:
                    chat_buffer.append(style_line(f"Now tailing: {path}", tone="status"))
                    _chat_dirty = True
                except Exception:
                    pass
                _refresh_event.set()

            # Detect truncation/rotation
            try:
                cur_size = os.path.getsize(path)
                cur_pos = f.tell()
                if cur_pos > cur_size:
                    try: f.close()
                    except Exception: pass
                    f = _open_for_tail(path)
                    buf = ""
            except Exception:
                time.sleep(max(0.1, POLL_INTERVAL_SEC))
                continue

            # Read available chunk
            where = f.tell()
            data = f.read(CHUNK)
            if not data:
                time.sleep(POLL_INTERVAL_SEC)
                continue

            # Split & process complete lines (\r\n, \n, bare \r)
            buf += data
            lines = buf.splitlines(keepends=True)

            complete = 0
            for ln in lines:
                if ln.endswith("\r\n") or ln.endswith("\n") or ln.endswith("\r"):
                    _consume_line(ln.rstrip("\r\n") + "\n")
                    complete += 1
                else:
                    break

            buf = "".join(lines[complete:]) if complete < len(lines) else ""

        except Exception as e:
            try:
                if f: f.close()
            except Exception:
                pass
            f = None
            try:
                log_buffer.append(style_line(f"[GUI] tail error: {e}", tone="error")); _log_dirty = True
            except Exception:
                pass
            time.sleep(max(0.2, POLL_INTERVAL_SEC))

# -------------------------------
# Build GUI
# -------------------------------
def build_gui():
    with dpg.window(tag="main_window", label="Piper GUI", width=1060, height=760, pos=(20,20)):
        with dpg.group(horizontal=True):
            with dpg.child_window(tag="left_panel", width=640, height=660, border=True):
                # State header
                dpg.add_text("SLEEPING", tag="state_label")
                dpg.add_text("Last update: -", tag="hb_label")
                dpg.add_text(f"Tailing: {LOG_PATH}")

                # Chat
                with dpg.child_window(tag="chat_child", width=-1, height=500, border=True):
                    dpg.add_text("Chat (read-only)")
                    with dpg.group(horizontal=True):
                        dpg.add_button(label="Copy Chat", callback=lambda: dpg.set_clipboard_text(_compose(chat_buffer)))
                    dpg.add_text("", tag="chat_text", wrap=0)

            with dpg.child_window(tag="right_panel", width=380, height=660, border=True):
                # Logs
                with dpg.child_window(tag="logs_child", width=-1, height=600, border=True):
                    dpg.add_text("Logs (read-only)")
                    with dpg.group(horizontal=True):
                        dpg.add_button(label="Copy Logs", callback=lambda: dpg.set_clipboard_text(_compose(log_buffer)))
                    dpg.add_text("", tag="log_text", wrap=0)

    apply_theme_if_enabled()

# -------------------------------
# Theme (idempotent)
# -------------------------------


# -------------------------------
# Run
# -------------------------------
def run():
    print("[GUI] Starting Piper GUI (LL13.1).")
    path = Path(LOG_PATH)

    # Start tail thread
    t = threading.Thread(target=_tail_file, args=(path,), daemon=True)
    t.start()

    # GUI
    dpg.create_context()
    build_gui()
    apply_theme_if_enabled()

    dpg.create_viewport(title="Piper GUI — LL13.1", width=1060, height=760)
    dpg.setup_dearpygui()
    dpg.show_viewport()

    # Startup lines
    try:
        mode = "start" if TAIL_FROM_START else "end"
        chat_buffer.append(style_line(f"Tailing: {path} (from {mode})", tone="status"))
        _chat_dirty = True
        log_buffer.append(style_line(f"[GUI] Tail thread running for {path}", tone="status"))
        _log_dirty = True
    except Exception:
        chat_buffer.append(f"Tailing: {path} (from {mode})"); _chat_dirty = True
        log_buffer.append(f"[GUI] Tail thread running for {path}"); _log_dirty = True
    _update_panes()

    schedule_recurring_update()

    dpg.start_dearpygui()
    dpg.destroy_context()
    print("[GUI] Piper GUI closed.")

def main():
    run()

if __name__ == "__main__":
    main()
