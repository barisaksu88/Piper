# C:\Piper\scripts\entries\app_cli_entry.py
# T‑Core02: Thin CLI entrypoint that wires persona styling into CoreMachine.

from __future__ import annotations
import sys
from typing import Optional

# Persona styling passthrough (Services)
try:
    from scripts.services.persona_adapter import style_line  # type: ignore
except Exception:
    from services.persona_adapter import style_line  # type: ignore

# CoreMachine
try:
    from scripts.core.core_machine import CoreMachine  # type: ignore
except Exception:
    from core.core_machine import CoreMachine  # type: ignore

# Version tag (unchanged)
VERSION_STR = "PV11-2025-08-21"

def _say(text: str, tone: Optional[str] = None) -> None:
    """ Print one styled line with newline, flush for live tee. """
    try:
        out = style_line(text, tone=tone or "neutral")
    except Exception:
        out = text
    sys.stdout.write(out + "\n")
    sys.stdout.flush()

def main() -> None:
    CoreMachine(say=_say, version_str=VERSION_STR).run()

if __name__ == "__main__":
    main()
