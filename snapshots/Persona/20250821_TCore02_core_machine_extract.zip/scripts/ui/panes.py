# C:\Piper\scripts\ui\panes.py
from __future__ import annotations

import dearpygui.dearpygui as dpg
from typing import Tuple

from .theme import apply_theme_if_enabled  # same fallback as in entry file if you prefer

# Smart autoscroll flags (module-level so the entry can import behavior)
autoscroll_chat = True
autoscroll_logs = True

def _is_at_bottom(child_tag: str) -> bool:
    try:
        y = dpg.get_y_scroll(child_tag)
        h = dpg.get_y_scroll_max(child_tag)
        return (h - y) < 8
    except Exception:
        return True

def _snap_to_bottom(child_tag: str):
    try:
        dpg.set_y_scroll(child_tag, dpg.get_y_scroll_max(child_tag))
    except Exception:
        pass

def _apply_wrap(text_tag: str, child_tag: str):
    try:
        width = max(320, int(dpg.get_item_rect_size(child_tag)[0]) - 24)
        dpg.configure_item(text_tag, wrap=width)
    except Exception:
        pass

def init_ui(log_path: str) -> None:
    """Create the main window/panels and bind theme."""
    with dpg.window(tag="main_window", label="Piper GUI", width=1060, height=760, pos=(20,20)):
        with dpg.group(horizontal=True):
            with dpg.child_window(tag="left_panel", width=640, height=660, border=True):
                dpg.add_text("SLEEPING", tag="state_label")
                dpg.add_text("Last update: -", tag="hb_label")
                dpg.add_text(f"Tailing: {log_path}")

                with dpg.child_window(tag="chat_child", width=-1, height=500, border=True):
                    dpg.add_text("Chat (read-only)")
                    with dpg.group(horizontal=True):
                        dpg.add_button(label="Copy Chat",
                                       callback=lambda: dpg.set_clipboard_text(dpg.get_value("chat_text") or ""))
                    dpg.add_text("", tag="chat_text", wrap=0)

            with dpg.child_window(tag="right_panel", width=380, height=660, border=True):
                with dpg.child_window(tag="logs_child", width=-1, height=600, border=True):
                    dpg.add_text("Logs (read-only)")
                    with dpg.group(horizontal=True):
                        dpg.add_button(label="Copy Logs",
                                       callback=lambda: dpg.set_clipboard_text(dpg.get_value("log_text") or ""))
                    dpg.add_text("", tag="log_text", wrap=0)

    apply_theme_if_enabled()

def refresh_ui(state_label: str, hb_text: str, chat_text: str, log_text: str,
               chat_dirty: bool, log_dirty: bool) -> None:
    """
    Update labels/buffers and perform smart autoscroll.
    Autoscroll flags are managed internally; no return value.
    """
    global autoscroll_chat, autoscroll_logs

    # BEFORE: were we already at bottom?
    chat_was_bottom = _is_at_bottom("chat_child")
    logs_was_bottom = _is_at_bottom("logs_child")
    if not chat_was_bottom:
        autoscroll_chat = False
    if not logs_was_bottom:
        autoscroll_logs = False

    # Update labels and panes
    try:
        dpg.set_value("state_label", state_label)
        dpg.set_value("hb_label", hb_text)
        dpg.set_value("chat_text", chat_text)
        dpg.set_value("log_text",  log_text)
    except Exception:
        # If any tags aren’t created yet, just skip this tick
        return

    # Wrap to container width
    _apply_wrap("chat_text", "chat_child")
    _apply_wrap("log_text",  "logs_child")

    # AFTER: if new content AND user was at bottom, snap once
    if chat_dirty and autoscroll_chat and chat_was_bottom:
        _snap_to_bottom("chat_child")
    if log_dirty and autoscroll_logs and logs_was_bottom:
        _snap_to_bottom("logs_child")

    # If user is now back at bottom, re-enable autoscroll
    if _is_at_bottom("chat_child"):
        autoscroll_chat = True
    if _is_at_bottom("logs_child"):
        autoscroll_logs = True
