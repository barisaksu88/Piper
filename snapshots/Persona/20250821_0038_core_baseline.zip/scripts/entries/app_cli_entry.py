# C:\Piper\scripts\entries\app_cli_entry.py
# PV08: runtime tone editor commands
from __future__ import annotations
import datetime, shlex
from dataclasses import dataclass

CORE_VERSION = "PV08-2025-08-21"

try:
    from scripts.services.persona_adapter import (
        get_greeting, style_line, max_len,
        set_runtime_sarcasm, get_runtime_sarcasm,
        set_runtime_max_len, get_runtime_max_len,
        list_tones, show_tone, set_tone_field, clear_tone,
    )
except Exception:
    from services.persona_adapter import (
        get_greeting, style_line, max_len,
        set_runtime_sarcasm, get_runtime_sarcasm,
        set_runtime_max_len, get_runtime_max_len,
        list_tones, show_tone, set_tone_field, clear_tone,
    )

AVAILABLE_STATES = ("SLEEPING", "WAKING", "LISTENING", "THINKING", "SPEAKING")

@dataclass
class Event: name: str; data: dict

def _say(text: str, tone: str = "info", sarcasm: bool | None = None) -> None:
    out = style_line(str(text), tone=tone, sarcasm=sarcasm)
    if len(out) > max_len():
        out = out[: max_len() - 1] + "…"
    print(out)

class CoreMachine:
    def __init__(self):
        self.state = "SLEEPING"
        self.safe_mode = True
        self.running = True

    def _greet(self):
        _say(get_greeting(), tone="greet")

    def _about_text(self) -> str:
        return f"Piper CLI – Core {CORE_VERSION}. SAFE_MODE is {'ON' if self.safe_mode else 'OFF'}"

    def _help_text(self) -> str:
        return (
            "Commands: wake, sleep, about, time, date, version, help, exit.\n"
            "Persona: persona sarcasm on|off|status | persona max <n>|status|clear | persona preview\n"
            "         persona tone list | persona tone show <tone>\n"
            "         persona tone set <tone> prefix|suffix|end \"<text>\"\n"
            "         persona tone clear <tone>\n"
            "Flow: wake → (LISTENING) → type a command."
        )

    def _persona_preview(self) -> str:
        tones = [
            ("greet",      "Greeting sample"),
            ("about",      "About sample"),
            ("info",       "Info sample"),
            ("status",     "Status sample"),
            ("confirm",    "Confirm sample"),
            ("thinking",   "Thinking sample"),
            ("error",      "Soft error sample"),
            ("error_hard", "Hard error sample"),
        ]
        lines = [style_line(label, tone=tone) for tone, label in tones]
        # footer
        sval = get_runtime_sarcasm()
        sarc_mode = "FOLLOW_PERSONALITY" if sval is None else ("ON" if sval else "OFF")
        ov = get_runtime_max_len()
        ml_txt = f"FOLLOW_PERSONALITY ({max_len()} chars)" if ov is None else f"{ov} chars"
        lines.append(style_line(f"Sarcasm: {sarc_mode}; Max length: {ml_txt}", tone="status"))
        return "\n".join(lines)

    def _handle_text_command(self, text: str) -> tuple[str | None, str]:
        t = (text or "").strip()
        tl = t.lower()

        # Persona runtime: sarcasm
        if tl in ("persona sarcasm on", "persona sarcasm true"):
            set_runtime_sarcasm(True); return "Sarcasm override set to ON.", "status"
        if tl in ("persona sarcasm off", "persona sarcasm false"):
            set_runtime_sarcasm(False); return "Sarcasm override set to OFF.", "status"
        if tl in ("persona sarcasm", "persona sarcasm status"):
            sval = get_runtime_sarcasm()
            mode = "FOLLOW_PERSONALITY" if sval is None else ("ON" if sval else "OFF")
            return f"Sarcasm mode: {mode}.", "status"

        # Persona runtime: max length
        if tl.startswith("persona max"):
            parts = t.split()
            if len(parts) == 3 and parts[2].lower() == "status":
                ov = get_runtime_max_len()
                if ov is None:
                    return f"Max length: FOLLOW_PERSONALITY ({max_len()} chars).", "status"
                return f"Max length override: {ov} chars.", "status"
            if len(parts) == 3 and parts[2].lower() == "clear":
                set_runtime_max_len(None); return "Max length override cleared (following personality).", "status"
            if len(parts) == 3:
                try:
                    val = int(parts[2]); set_runtime_max_len(val)
                    return f"Max length override set to {max_len()} chars.", "status"
                except ValueError:
                    return "Provide a number, e.g., 'persona max 80'.", "error"
            return "Usage: persona max <n>|status|clear", "error"

        # Persona runtime: tone editor
        if tl == "persona tone list":
            tones = ", ".join(list_tones())
            return f"Tones: {tones}.", "status"

        if tl.startswith("persona tone show "):
            tone = t.split(" ", 3)[3].strip()
            cfg = show_tone(tone)
            return f"{tone}: prefix={cfg.get('prefix','')!r} suffix={cfg.get('suffix','')!r} end={cfg.get('end','')!r}", "status"

        if tl.startswith("persona tone clear "):
            tone = t.split(" ", 3)[3].strip()
            clear_tone(tone)
            return f"Cleared runtime overrides for tone '{tone}'.", "status"

        if tl.startswith("persona tone set "):
            # Accept quoted text via shlex: persona tone set error prefix "!! "
            try:
                parts = shlex.split(t)
            except ValueError:
                return "Bad quoting. Use: persona tone set <tone> prefix|suffix|end \"<text>\"", "error"
            # parts: ["persona", "tone", "set", "<tone>", "<field>", "<value>"]
            if len(parts) < 6:
                return "Usage: persona tone set <tone> prefix|suffix|end \"<text>\"", "error"
            _tone, _field, _value = parts[3], parts[4].lower(), " ".join(parts[5:])
            if _field not in ("prefix", "suffix", "end"):
                return "Field must be prefix, suffix, or end.", "error"
            set_tone_field(_tone, _field, _value)
            return f"Set {_tone}.{_field} = {_value!r}", "status"


        # Persona preview
        if tl == "persona preview":
            return self._persona_preview(), "info"

        # Core commands
        if tl == "wake":
            if self.state == "SLEEPING":
                self.state = "WAKING"; self._greet(); self.state = "LISTENING"
            else:
                return "Already awake.", "status"
            return None, "status"

        if tl == "sleep":
            self.state = "SLEEPING"; return "Going to sleep.", "status"

        if tl == "about":
            return self._about_text(), "about"

        if tl == "time":
            now = datetime.datetime.now().strftime("%H:%M"); return f"The time is {now}.", "confirm"

        if tl == "date":
            today = datetime.datetime.now().strftime("%Y-%m-%d"); return f"Today is {today}.", "confirm"

        if tl == "version":
            return f"Core version {CORE_VERSION}.", "confirm"

        if tl.startswith("help"):
            return self._help_text(), "info"

        if tl == "exit":
            self.running = False; return None, "status"

        # Unknown
        return "I don't know that command. Try 'help'.", "error_hard"

    def run(self):
        _say(f"[STATE] available_states={'|'.join(AVAILABLE_STATES)}", tone="status")
        _say("Piper is ready. Type 'wake' to greet or 'help' for commands.", tone="info")

        while self.running:
            try:
                user = input("> ").strip()
            except (EOFError, KeyboardInterrupt):
                user = "exit"

            reply, tone = self._handle_text_command(user)
            if reply:
                if user.lower().strip() == "persona preview":
                    for line in reply.splitlines():
                        _say(line, tone="info")
                else:
                    _say(reply, tone=tone)

def main(): CoreMachine().run()
if __name__ == "__main__": main()
