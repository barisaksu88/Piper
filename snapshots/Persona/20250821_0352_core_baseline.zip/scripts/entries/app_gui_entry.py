# C:\Piper\scripts\entries\app_gui_entry.py
# LAYOUT/LOOK Rails – LL-R03 thin bootstrap
# - Theme lives in ui/theme.py
# - Tailer lives in ui/tailer.py
# - Panes (init_ui / refresh_ui) live in ui/panes.py
# - This file only wires them together + keeps minimal GUI-specific state

from __future__ import annotations

import os
import time
from collections import deque
from pathlib import Path
from datetime import datetime
import re

import dearpygui.dearpygui as dpg

# Persona styling passthrough (Services)
try:
    from scripts.services.persona_adapter import style_line
except Exception:
    from services.persona_adapter import style_line

# Tailer + Panes adapters
try:
    from scripts.ui.tailer import Tailer
except Exception:
    from ui.tailer import Tailer

try:
    from scripts.ui.panes import init_ui, refresh_ui
except Exception:
    from ui.panes import init_ui, refresh_ui

# -------------------------------
# Config (UI-only)
# -------------------------------
LOG_PATH = os.environ.get("PIPER_CORE_LOG", r"C:\Piper\run\core.log")
TAIL_FROM_START = os.environ.get("PIPER_UI_TAIL_FROM_START", "0") == "1"
POLL_INTERVAL_SEC = float(os.environ.get("PIPER_UI_POLL_SEC", "0.25"))
STATE_DWELL_SEC = float(os.environ.get("PIPER_UI_STATE_DWELL_SEC", "1.1"))

# -------------------------------
# Buffers & State (UI-only)
# -------------------------------
LOG_MAX_LINES = 1200
CHAT_MAX_LINES = 600
log_buffer  = deque(maxlen=LOG_MAX_LINES)
chat_buffer = deque(maxlen=CHAT_MAX_LINES)

current_state = "SLEEPING"
state_queue = deque()
last_update_ts: datetime | None = None
last_display_switch: datetime | None = None

# Dirty flags: set True when NEW line appended; cleared after refresh
_chat_dirty = False
_log_dirty = False

# Render tick nudge
_refresh_needed = False

# Classifiers
STATE_RE = re.compile(r"\[STATE\]\s*(?:([A-Z]+)\s*→\s*([A-Z]+)|([A-Z]+))")
INTERESTING_TAGS = ("[STATE]", "[EVENT]", "[TTS]")

# -------------------------------
# Small helpers
# -------------------------------
def _tone_for_line(line: str) -> str:
    low = (line or "").lower()
    if "[state]" in low:
        return "status"
    if "[event]" in low or "[tts]" in low:
        return "info"
    if "error" in low or "[err]" in low or "traceback" in low:
        return "error"
    return "info"

def _compose(buf: deque) -> str:
    return "\n".join(buf)

def _human_when(ts: datetime | None) -> str:
    if not ts:
        return "Last update: -"
    delta = (datetime.now() - ts).total_seconds()
    return f"Last update: {int(delta)}s ago"

def _advance_state_if_needed():
    """Advance state_queue head after dwell time so transient states are visible."""
    global last_display_switch
    if not state_queue:
        state_queue.append(current_state)
        last_display_switch = datetime.now()
        return
    head = state_queue[0]
    if head != current_state and (datetime.now() - last_display_switch).total_seconds() >= STATE_DWELL_SEC:
        state_queue.popleft()
        last_display_switch = datetime.now()

def _is_chat_line(line: str) -> bool:
    """Decide if a log line should appear ONLY in the Chat pane."""
    s = (line or "").strip()
    if not s:
        return False

    # Skip tail/tech and GUI notices
    if s.startswith("? ") or "Tailing:" in s or s.startswith("[GUI]"):
        return False

    # Tagged human-facing events
    if any(tag in s for tag in INTERESTING_TAGS):
        return True

    # CLI prompt/output and persona-styled speech
    if s.startswith(">"):
        return True

    # Persona markers
    if s[:1] in {"✓", "✔", "✖", "…", "!", "?"}:
        return True

    # Plain lines with no bracket tags and no obvious error keywords
    lower = s.lower()
    looks_like_error = any(k in lower for k in (
        "traceback", "exception", "error:", "systemerror", "unicodeencodeerror"
    ))
    if not looks_like_error and "[" not in s:
        return True

    return False

# -------------------------------
# Tailer → GUI ingestion
# -------------------------------
def _consume_line(line: str):
    """Ingest one log line; route to Chat or Logs; request UI refresh."""
    global last_update_ts, current_state, _chat_dirty, _log_dirty, _refresh_needed

    # Normalize and timestamp
    if line.endswith("\n"):
        line = line[:-1]
    last_update_ts = datetime.now()

    # Track state transitions with dwell
    m = STATE_RE.search(line)
    if m:
        new_state = current_state
        if m.group(2):   # HEAD → NEW
            new_state = m.group(2)
        elif m.group(3): # NEW
            new_state = m.group(3)
        if new_state != current_state:
            current_state = new_state
            if not state_queue or state_queue[-1] != new_state:
                state_queue.append(new_state)

    # Route to Chat OR Logs (no duplication)
    try:
        if _is_chat_line(line):
            chat_buffer.append(style_line(line.strip(), tone=_tone_for_line(line)))
            _chat_dirty = True
        else:
            log_buffer.append(style_line(line, tone=_tone_for_line(line)))
            _log_dirty = True
    except Exception:
        if _is_chat_line(line):
            chat_buffer.append(line.strip()); _chat_dirty = True
        else:
            log_buffer.append(line); _log_dirty = True

    # Bound sizes
    while len(chat_buffer) > CHAT_MAX_LINES: chat_buffer.popleft()
    while len(log_buffer) > LOG_MAX_LINES:   log_buffer.popleft()

    # Hint the UI to refresh soon
    _refresh_needed = True
    try:
        dpg.add_thread_task(_update_panes)  # if available in this DPG build
    except Exception:
        pass

def _on_tailer_status(msg: str):
    global _chat_dirty, _refresh_needed
    try:
        chat_buffer.append(style_line(msg, tone="status"))
    except Exception:
        chat_buffer.append(msg)
    last_update_ts = datetime.now()
    _chat_dirty = True
    _refresh_needed = True

def _on_tailer_error(msg: str):
    global _log_dirty, _refresh_needed
    try:
        log_buffer.append(style_line(msg, tone="error"))
    except Exception:
        log_buffer.append(msg)
    last_update_ts = datetime.now() 
    _log_dirty = True
    _refresh_needed = True

# -------------------------------
# UI refresh scheduling
# -------------------------------
def _update_panes():
    """Delegate to panes.refresh_ui with smart autoscroll."""
    global _chat_dirty, _log_dirty, _refresh_needed
    state_text = state_queue[0] if state_queue else current_state
    hb_text = _human_when(last_update_ts)
    chat_text = _compose(chat_buffer)
    log_text  = _compose(log_buffer)

    # refresh_ui also manages autoscroll & wrapping
    refresh_ui(state_text, hb_text, chat_text, log_text, _chat_dirty, _log_dirty)

    # Clear dirty flags after refresh
    _chat_dirty = False
    _log_dirty = False
    _refresh_needed = False

def schedule_recurring_update():
    """DPG 2.1-compatible recurring tick via set_frame_callback."""
    frames_per_tick = max(1, int(POLL_INTERVAL_SEC * 60))

    def _tick(sender=None, app_data=None):
        _advance_state_if_needed()
        # Only do heavy refresh if something changed (or periodically anyway)
        if _refresh_needed:
            _update_panes()
        else:
            # heartbeat text still needs updating
            dpg.set_value("hb_label", _human_when(last_update_ts))
        dpg.set_frame_callback(dpg.get_frame_count() + frames_per_tick, _tick)

    dpg.set_frame_callback(dpg.get_frame_count() + 1, _tick)

# -------------------------------
# Bootstrap
# -------------------------------
def build_gui():
    init_ui(LOG_PATH)

def run():
    print("[GUI] Starting Piper GUI (LL-R03).")
    path = Path(LOG_PATH)

    # Tailer thread
    tailer = Tailer(path=path, from_start=TAIL_FROM_START, poll_interval=POLL_INTERVAL_SEC)
    tailer.start_in_thread(on_line=_consume_line, on_status=_on_tailer_status, on_error=_on_tailer_error)

    # DPG lifecycle
    dpg.create_context()
    build_gui()
    dpg.create_viewport(title="Piper GUI — LL-R03", width=1060, height=760)
    dpg.setup_dearpygui()
    dpg.show_viewport()

    # Startup lines (chat: status; logs: thread notice handled by _on_tailer_status/_on_tailer_error)
    try:
        mode = "start" if TAIL_FROM_START else "end"
        chat_buffer.append(style_line(f"Tailing: {path} (from {mode})", tone="status"))
    except Exception:
        chat_buffer.append(f"Tailing: {path} (from {mode})")
    global _chat_dirty, _refresh_needed
    _chat_dirty = True
    _refresh_needed = True
    _update_panes()

    schedule_recurring_update()
    dpg.start_dearpygui()
    dpg.destroy_context()
    print("[GUI] Piper GUI closed.")

def main():
    run()

if __name__ == "__main__":
    main()
