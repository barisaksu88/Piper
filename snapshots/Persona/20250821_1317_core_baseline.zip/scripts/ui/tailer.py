# C:\Piper\scripts\ui\tailer.py
# UI Tailer: robust, non-blocking tail with UTF-8/UTF-16 auto-detect and rotation handling.

from __future__ import annotations

import os
import time
import threading
from pathlib import Path
from typing import Callable, Optional

OnLine   = Callable[[str], None]     # receives a single line (with trailing '\n' normalized)
OnMsg    = Callable[[str], None]     # status/error text (human readable)

def _open_for_tail(path: Path):
    """
    Open text file with encoding auto-detect (UTF-8 vs UTF-16 LE/BE).
    Re-check on rotation/truncation.
    """
    try:
        with open(path, "rb") as fb:
            head = fb.read(4)
        if head.startswith(b"\xff\xfe"):   # UTF-16 LE BOM
            enc = "utf-16-le"
        elif head.startswith(b"\xfe\xff"): # UTF-16 BE BOM
            enc = "utf-16-be"
        else:
            enc = "utf-16-le" if b"\x00" in head else "utf-8"
    except Exception:
        enc = "utf-8"
    return open(path, "r", encoding=enc, errors="replace")

class Tailer:
    def __init__(
        self,
        path: Path,
        from_start: bool = False,
        poll_interval: float = 0.25,
        chunk_bytes: int = 4096,
    ) -> None:
        self.path = Path(path)
        self.from_start = bool(from_start)
        self.poll_interval = float(poll_interval)
        self.chunk = int(chunk_bytes)
        self._stop = False
        self._thread: Optional[threading.Thread] = None

    def start_in_thread(
        self,
        on_line: OnLine,
        on_status: Optional[OnMsg] = None,
        on_error: Optional[OnMsg] = None,
    ) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop = False
        self._thread = threading.Thread(
            target=self._run, args=(on_line, on_status, on_error), daemon=True
        )
        self._thread.start()

    def stop(self) -> None:
        self._stop = True

    # ---------------- internal ----------------
    def _run(self, on_line: OnLine, on_status: Optional[OnMsg], on_error: Optional[OnMsg]) -> None:
        told_missing = False
        buf = ""
        f = None

        while not self._stop:
            try:
                # Wait for file
                if f is None:
                    if not self.path.exists():
                        if on_status and not told_missing:
                            on_status(f"Waiting for log file: {self.path}. Tip: run CLI with tee to this path.")
                        told_missing = True
                        time.sleep(max(0.1, self.poll_interval))
                        continue
                    f = _open_for_tail(self.path)
                    try:
                        if not self.from_start:
                            f.seek(0, os.SEEK_END)
                    except Exception:
                        pass
                    told_missing = False
                    if on_status:
                        on_status(f"Now tailing: {self.path}")

                # Detect truncation/rotation
                try:
                    cur_size = os.path.getsize(self.path)
                    cur_pos = f.tell()
                    if cur_pos > cur_size:
                        try:
                            f.close()
                        except Exception:
                            pass
                        f = _open_for_tail(self.path)
                        buf = ""
                except Exception:
                    time.sleep(max(0.1, self.poll_interval))
                    continue

                # Read available chunk
                where = f.tell()
                data = f.read(self.chunk)
                if not data:
                    time.sleep(self.poll_interval)
                    continue

                # Split complete lines; accept \r\n, \n, or bare \r; normalize to '\n'
                buf += data
                lines = buf.splitlines(keepends=True)

                complete = 0
                for ln in lines:
                    if ln.endswith("\r\n") or ln.endswith("\n") or ln.endswith("\r"):
                        on_line(ln.rstrip("\r\n") + "\n")
                        complete += 1
                    else:
                        break

                buf = "".join(lines[complete:]) if complete < len(lines) else ""

            except Exception as e:
                try:
                    if f:
                        f.close()
                except Exception:
                    pass
                f = None
                if on_error:
                    on_error(f"[GUI] tail error: {e}")
                time.sleep(max(0.2, self.poll_interval))
