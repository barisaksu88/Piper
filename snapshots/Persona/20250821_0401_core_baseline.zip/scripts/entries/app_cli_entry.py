# C:\Piper\scripts\entries\app_cli_entry.py
# PV11: persona README generator (Services + Core glue only)
from __future__ import annotations
import datetime, json
from pathlib import Path
from dataclasses import dataclass

CORE_VERSION = "PV11-2025-08-21"

try:
    from scripts.services.persona_adapter import (
        get_greeting, style_line, max_len,
        set_runtime_sarcasm, get_runtime_sarcasm,
        set_runtime_max_len, get_runtime_max_len,
        list_tones, show_tone, set_tone_field, clear_tone,
        export_runtime_dict, import_runtime_dict,
    )
except Exception:
    from services.persona_adapter import (
        get_greeting, style_line, max_len,
        set_runtime_sarcasm, get_runtime_sarcasm,
        set_runtime_max_len, get_runtime_max_len,
        list_tones, show_tone, set_tone_field, clear_tone,
        export_runtime_dict, import_runtime_dict,
    )

AVAILABLE_STATES = ("SLEEPING", "WAKING", "LISTENING", "THINKING", "SPEAKING")

@dataclass
class Event:
    name: str
    data: dict

def _say(text: str, tone: str = "info", sarcasm: bool | None = None) -> None:
    out = style_line(str(text), tone=tone, sarcasm=sarcasm)
    if len(out) > max_len():
        out = out[: max_len() - 1] + "…"
    print(out)

def _project_root() -> Path:
    here = Path(__file__).resolve()
    return here.parent.parent.parent  # -> C:\Piper

def _run_dir() -> Path:
    rd = _project_root() / "run"
    rd.mkdir(parents=True, exist_ok=True)
    return rd

def _safe_name(name: str) -> str:
    safe = "".join(c for c in name if c.isalnum() or c in ("-", "_")).strip()
    return safe or "default"

def _profile_path(name: str) -> Path:
    return _run_dir() / f"persona_{_safe_name(name)}.json"

def _list_profiles() -> list[str]:
    paths = sorted(_run_dir().glob("persona_*.json"))
    names = []
    for p in paths:
        stem = p.stem  # persona_<name>
        if stem.startswith("persona_"):
            names.append(stem[len("persona_"):])
    return names

def _readme_path() -> Path:
    return _run_dir() / "persona_README.txt"

def _generate_readme_text() -> str:
    # Gather knobs
    sval = get_runtime_sarcasm()
    sarc_mode = "FOLLOW_PERSONALITY" if sval is None else ("ON" if sval else "OFF")
    ov = get_runtime_max_len()
    ml_txt = f"FOLLOW_PERSONALITY ({max_len()} chars)" if ov is None else f"{ov} chars"

    # Tone table
    tones = list_tones()
    lines = []
    lines.append("Piper – Persona/Voice README (PV11)")
    lines.append(f"Generated: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append("")
    lines.append("Current knobs:")
    lines.append(f"  - Sarcasm: {sarc_mode}")
    lines.append(f"  - Max length: {ml_txt}")
    lines.append("")
    lines.append("Tone presets (prefix | suffix | end):")
    for t in tones:
        cfg = show_tone(t)
        lines.append(f"  - {t:11s} | {cfg.get('prefix','')!r} | {cfg.get('suffix','')!r} | {cfg.get('end','')!r}")
    lines.append("")
    lines.append("Samples:")
    samples = [
        ("greet",      "Greeting sample"),
        ("about",      "About sample"),
        ("info",       "Info sample"),
        ("status",     "Status sample"),
        ("confirm",    "Confirm sample"),
        ("thinking",   "Thinking sample"),
        ("error",      "Soft error sample"),
        ("error_hard", "Hard error sample"),
    ]
    for tone, label in samples:
        lines.append(style_line(label, tone=tone))
    lines.append("")
    lines.append("CLI commands (Services + Core glue):")
    lines.append("  wake | sleep | about | time | date | version | help | exit")
    lines.append("  persona preview")
    lines.append("  persona sarcasm on|off|status")
    lines.append("  persona max <n>|status|clear")
    lines.append("  persona tone list | persona tone show <tone>")
    lines.append('  persona tone set <tone> prefix|suffix|end "<text>"')
    lines.append("  persona tone clear <tone>")
    lines.append("  persona save <name> | persona load <name> | persona profiles | persona delete <name>")
    lines.append("")
    lines.append("Notes:")
    lines.append("  - personality.py remains user-owned/read-only; runtime overrides do not modify it.")
    lines.append("  - Saved profiles live under C:\\Piper\\run\\persona_<name>.json")
    return "\n".join(lines)

class CoreMachine:
    def __init__(self):
        self.state = "SLEEPING"
        self.safe_mode = True
        self.running = True

    def _greet(self):
        _say(get_greeting(), tone="greet")

    def _about_text(self) -> str:
        return f"Piper CLI – Core {CORE_VERSION}. SAFE_MODE is {'ON' if self.safe_mode else 'OFF'}"

    def _help_text(self) -> str:
        return (
            "Commands: wake, sleep, about, time, date, version, help, exit.\n"
            "Persona: persona sarcasm on|off|status | persona max <n>|status|clear | persona preview\n"
            "         persona tone list | persona tone show <tone>\n"
            "         persona tone set <tone> prefix|suffix|end \"<text>\" | persona tone clear <tone>\n"
            "         persona save <name> | persona load <name> | persona profiles | persona delete <name>\n"
            "         persona readme\n"
            "Flow: wake → (LISTENING) → type a command."
        )

    def _persona_preview(self) -> str:
        tones = [
            ("greet",      "Greeting sample"),
            ("about",      "About sample"),
            ("info",       "Info sample"),
            ("status",     "Status sample"),
            ("confirm",    "Confirm sample"),
            ("thinking",   "Thinking sample"),
            ("error",      "Soft error sample"),
            ("error_hard", "Hard error sample"),
        ]
        lines = [style_line(label, tone=tone) for tone, label in tones]
        sval = get_runtime_sarcasm()
        sarc_mode = "FOLLOW_PERSONALITY" if sval is None else ("ON" if sval else "OFF")
        ov = get_runtime_max_len()
        ml_txt = f"FOLLOW_PERSONALITY ({max_len()} chars)" if ov is None else f"{ov} chars"
        lines.append(style_line(f"Sarcasm: {sarc_mode}; Max length: {ml_txt}", tone="status"))
        return "\n".join(lines)

    def _handle_text_command(self, text: str) -> tuple[str | None, str]:
        t = (text or "").strip()
        tl = t.lower()

        # Persona runtime: sarcasm
        if tl in ("persona sarcasm on", "persona sarcasm true"):
            set_runtime_sarcasm(True); return "Sarcasm override set to ON.", "status"
        if tl in ("persona sarcasm off", "persona sarcasm false"):
            set_runtime_sarcasm(False); return "Sarcasm override set to OFF.", "status"
        if tl in ("persona sarcasm", "persona sarcasm status"):
            sval = get_runtime_sarcasm()
            mode = "FOLLOW_PERSONALITY" if sval is None else ("ON" if sval else "OFF")
            return f"Sarcasm mode: {mode}.", "status"

        # Persona runtime: max length
        if tl.startswith("persona max"):
            parts = t.split()
            if len(parts) == 3 and parts[2].lower() == "status":
                ov = get_runtime_max_len()
                if ov is None:
                    return f"Max length: FOLLOW_PERSONALITY ({max_len()} chars).", "status"
                return f"Max length override: {ov} chars.", "status"
            if len(parts) == 3 and parts[2].lower() == "clear":
                set_runtime_max_len(None); return "Max length override cleared (following personality).", "status"
            if len(parts) == 3:
                try:
                    val = int(parts[2]); set_runtime_max_len(val)
                    return f"Max length override set to {max_len()} chars.", "status"
                except ValueError:
                    return "Provide a number, e.g., 'persona max 80'.", "error"
            return "Usage: persona max <n>|status|clear", "error"

        # Persona runtime: tone editor
        if tl == "persona tone list":
            tones = ", ".join(list_tones())
            return f"Tones: {tones}.", "status"

        if tl.startswith("persona tone show "):
            tone = t.split(" ", 3)[3].strip()
            cfg = show_tone(tone)
            return f"{tone}: prefix={cfg.get('prefix','')!r} suffix={cfg.get('suffix','')!r} end={cfg.get('end','')!r}", "status"

        if tl.startswith("persona tone clear "):
            tone = t.split(" ", 3)[3].strip()
            clear_tone(tone)
            return f"Cleared runtime overrides for tone '{tone}'.", "status"

        if tl.startswith("persona tone set "):
            parts = t.split(" ", 5)
            if len(parts) < 6:
                return "Usage: persona tone set <tone> prefix|suffix|end \"<text>\"", "error"
            _tone, _field, _value = parts[3], parts[4].lower(), parts[5].strip().strip('"')
            if _field not in ("prefix", "suffix", "end"):
                return "Field must be prefix, suffix, or end.", "error"
            set_tone_field(_tone, _field, _value)
            return f"Set {_tone}.{_field} = {_value!r}", "status"

        # Persona profiles: save/load/list/delete
        if tl.startswith("persona save "):
            name = t.split(" ", 2)[2].strip()
            path = _profile_path(name)
            try:
                with open(path, "w", encoding="utf-8") as f:
                    json.dump(export_runtime_dict(), f, ensure_ascii=False, indent=2)
                return f"Saved persona profile to {path}.", "status"
            except Exception as e:
                return f"Failed to save profile: {e}", "error_hard"

        if tl.startswith("persona load "):
            name = t.split(" ", 2)[2].strip()
            path = _profile_path(name)
            if not path.exists():
                return f"Profile not found: {path}", "error_hard"
            try:
                with open(path, "r", encoding="utf-8") as f:
                    state = json.load(f)
                import_runtime_dict(state)
                return f"Loaded persona profile from {path}.", "status"
            except Exception as e:
                return f"Failed to load profile: {e}", "error_hard"

        if tl == "persona profiles":
            names = _list_profiles()
            return ("No saved profiles." if not names else "Profiles: " + ", ".join(names) + "."), "status"

        if tl.startswith("persona delete "):
            name = t.split(" ", 2)[2].strip()
            path = _profile_path(name)
            if not path.exists():
                return f"Profile not found: {path}", "error_hard"
            try:
                path.unlink()
                return f"Deleted profile {path}.", "status"
            except Exception as e:
                return f"Failed to delete profile: {e}", "error_hard"

        if tl == "persona preview":
            return self._persona_preview(), "info"

        if tl == "persona readme":
            try:
                path = _readme_path()
                text = _generate_readme_text()
                path.write_text(text, encoding="utf-8")
                return f"Wrote persona README to {path}.", "status"
            except Exception as e:
                return f"Failed to write README: {e}", "error_hard"

        # Core commands
        if tl == "wake":
            if self.state == "SLEEPING":
                self.state = "WAKING"; self._greet(); self.state = "LISTENING"
            else:
                return "Already awake.", "status"
            return None, "status"

        if tl == "sleep":
            self.state = "SLEEPING"; return "Going to sleep.", "status"

        if tl == "about":
            return self._about_text(), "about"

        if tl == "time":
            now = datetime.datetime.now().strftime("%H:%M"); return f"The time is {now}.", "confirm"

        if tl == "date":
            today = datetime.datetime.now().strftime("%Y-%m-%d"); return f"Today is {today}.", "confirm"

        if tl == "version":
            return f"Core version {CORE_VERSION}.", "confirm"

        if tl.startswith("help"):
            return self._help_text(), "info"

        if tl == "exit":
            self.running = False; return None, "status"

        # Unknown
        return "I don't know that command. Try 'help'.", "error_hard"

    def run(self):
        _say(f"[STATE] available_states={'|'.join(AVAILABLE_STATES)}", tone="status")
        _say("Piper is ready. Type 'wake' to greet or 'help' for commands.", tone="info")

        while self.running:
            try:
                user = input("> ").strip()
            except (EOFError, KeyboardInterrupt):
                user = "exit"

            reply, tone = self._handle_text_command(user)
            if reply:
                if user.lower().strip() == "persona preview":
                    for line in reply.splitlines():
                        _say(line, tone="info")
                else:
                    _say(reply, tone=tone)

def main(): CoreMachine().run()
if __name__ == "__main__": main()
