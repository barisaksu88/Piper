# Ring-2 UI: placeholder app shell (not used unless explicitly imported).
def run():
    pass
__all__ = ["run"]
