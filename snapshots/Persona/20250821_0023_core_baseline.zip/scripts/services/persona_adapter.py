# C:\Piper\scripts\services\persona_adapter.py
# PV05 Persona/Voice – add runtime override for max_len (plus PV04 sarcasm override)
from __future__ import annotations

# Read-only import of user persona
try:
    from scripts import personality
except Exception:
    try:
        import personality
    except Exception:
        personality = None

# Defaults
_DEFAULT_GREETING = "Hello sir!"
_DEFAULT_MAX_LEN = 280
_DEFAULT_TONE_PRESETS = {
    "greet":  {"prefix": "",    "suffix": "", "end": "!"},
    "info":   {"prefix": "",    "suffix": "", "end": "."},
    "status": {"prefix": "✓ ",  "suffix": "", "end": "."},
    "about":  {"prefix": "",    "suffix": "", "end": "."},
    "error":  {"prefix": "(!) ", "suffix": "", "end": "."},
    "neutral":{"prefix": "",    "suffix": "", "end": "."},
}

# ---------- runtime overrides ----------
_runtime = {
    "sarcasm": None,       # None = follow personality.py; True/False = override
    "max_len": None,       # None = follow personality.py/default; int = override
}

def _get_attr(name: str, default):
    if personality is None:
        return default
    return getattr(personality, name, default)

def get_greeting() -> str:
    return str(_get_attr("GREETING", _DEFAULT_GREETING))

def set_runtime_sarcasm(value: bool | None):
    """Set sarcasm override: True/False or None to follow personality.py."""
    _runtime["sarcasm"] = value

def get_runtime_sarcasm() -> bool | None:
    return _runtime["sarcasm"]

def set_runtime_max_len(value: int | None):
    """Set max length override: positive int or None to follow personality.py."""
    if value is None:
        _runtime["max_len"] = None
        return
    try:
        v = int(value)
        if v < 10:  # sanity floor to avoid silly values
            v = 10
        _runtime["max_len"] = v
    except Exception:
        # ignore bad values; keep previous
        pass

def get_runtime_max_len() -> int | None:
    return _runtime["max_len"]

def max_len() -> int:
    ov = _runtime["max_len"]
    if isinstance(ov, int) and ov > 0:
        return ov
    return int(_get_attr("MAX_RESPONSE_CHARS", _DEFAULT_MAX_LEN))

def _get_tone_presets() -> dict:
    presets = _get_attr("TONE_PRESETS", None)
    if not isinstance(presets, dict):
        return _DEFAULT_TONE_PRESETS
    merged = dict(_DEFAULT_TONE_PRESETS)
    for k, v in presets.items():
        if isinstance(v, dict):
            merged[k] = {**_DEFAULT_TONE_PRESETS.get(k, {}), **v}
    return merged

def _persona_sarcasm_default() -> bool:
    return bool(_get_attr("SARCASM", False))

def _apply_style(text: str, tone: str, sarcasm: bool) -> str:
    if not text:
        return text
    t = text.strip()

    presets = _get_tone_presets()
    p = presets.get((tone or "neutral").lower(), presets["neutral"])

    # End punctuation per tone
    if p.get("end") and not t.endswith((".", "!", "…")):
        t += p["end"]

    # Prefix/suffix
    if p.get("prefix"):
        t = f"{p['prefix']}{t}"
    if p.get("suffix"):
        t = f"{t}{p['suffix']}"

    # Very mild sarcasm
    if sarcasm:
        aside = " (couldn’t be simpler)."
        if len(t) + len(aside) <= max_len():
            t += aside

    return t

def style_line(text: str, tone: str = "neutral", sarcasm: bool | None = None) -> str:
    """
    Style + truncate to persona max length.
    sarcasm: True/False to force; None → runtime override if set, else personality.py.
    """
    if sarcasm is None:
        sarcasm = _runtime["sarcasm"]
        if sarcasm is None:
            sarcasm = _persona_sarcasm_default()

    styled = _apply_style(str(text), tone, sarcasm)
    limit = max_len()
    if len(styled) <= limit:
        return styled
    ellipsis = "…"
    return styled[: max(0, limit - len(ellipsis))] + ellipsis
