﻿"""
Central catalog for Piper UI layout constants.
Prep-only: importing this file must not change behavior anywhere.

Usage plan (later):
    from ui.layout_constants import L

    # Example (later, when we migrate):
    # dpg.add_window(width=L.WINDOW.WIDTH, height=L.WINDOW.HEIGHT)
"""

from __future__ import annotations
from dataclasses import dataclass

# ---- Basic scalar types -------------------------------------------------
@dataclass(frozen=True)
class Window:
    WIDTH: int = 1095     # was 1116
    HEIGHT: int = 780     # was 780
    MIN_WIDTH: int = 980
    MIN_HEIGHT: int = 640
    OFFSET_X = 0   # NEW: used by _panes_impl.add_window(...)
    OFFSET_Y = 0

@dataclass(frozen=True)
class Pane:
    LEFT_WIDTH: int = 780   # int(1345 * 0.58)
    RIGHT_WIDTH: int = 315  # 1345 - 780 - 250
    HEADER_HEIGHT: int = 48
    FOOTER_HEIGHT: int = 36
    SPLIT_RATIO: float = 0.58      # LEFT_W = int(WINDOW.WIDTH * SPLIT_RATIO)
    RIGHT_GUTTER: int = 250        # RIGHT_W = WIDTH - LEFT_W - RIGHT_GUTTER
    BODY_VPAD: int = 80           # ROW_H = WINDOW.HEIGHT - BODY_VPAD

@dataclass(frozen=True)
class Spacing:
    PAD: int = 12
    GAP: int = 4
    SECTION_GAP: int = 4
    BORDER: int = 1
    ROUNDING: int = 12
    SMALL: int = 8

@dataclass(frozen=True)
class Fonts:
    UI: float = 16.0
    MONO: float = 14.0
    HEADER: float = 18.0
    TINY: float = 12.0

@dataclass(frozen=True)
class Colors:
    # Placeholder RGBA tuples (Dear PyGui style later if needed)
    BG: tuple[int, int, int, int] = (18, 18, 18, 255)
    FG: tuple[int, int, int, int] = (230, 230, 230, 255)
    ACCENT: tuple[int, int, int, int] = (0, 170, 180, 255)
    MUTED: tuple[int, int, int, int] = (120, 120, 120, 255)
    OK: tuple[int, int, int, int] = (60, 200, 120, 255)
    WARN: tuple[int, int, int, int] = (240, 180, 40, 255)
    ERR: tuple[int, int, int, int] = (220, 60, 60, 255)

@dataclass(frozen=True)
class Heartbeat:
    # Poll/refresh cadence; aligns with existing POLL_INTERVAL_SEC
    POLL_SEC: float = 0.35

# ---- Aggregate namespace ------------------------------------------------
@dataclass(frozen=True)
class AVATAR:
    # Height of the avatar panel (right/bottom) in pixels.
    PANEL_H = 450
    # Minimal initial avatar panel height for cold build (pre-calibration).
    MIN_PANEL_H = 180
    # Contain-fit margin to avoid scrollbar jitter in Dear PyGui.
    FIT_MARGIN = 0.96

class L:
    WINDOW: Window = Window()
    PANE: Pane = Pane()
    SPACE: Spacing = Spacing()
    FONT: Fonts = Fonts()
    COLOR: Colors = Colors()
    HB: Heartbeat = Heartbeat()

# Single export object
L = L()
class Window:
    WIDTH: int = 1345     # was 1116
    HEIGHT: int = 720     # was 780

class RIGHTCOL:
    # Space reserved below logs for avatar panel + vertical gap
    # NOTE: At use sites we compute ROW_H - (AVATAR.HEIGHT + L.SPACE.SECTION_GAP)
    # Kept as semantic anchor for future layout changes.
    RESERVED_BELOW = None  # computed at call sites to avoid circular imports

# ----- Header / content separation -----
class HEADER:
    SEP_VISIBLE   = False   # draw a line under the header?
    SEP_THICKNESS = 1       # px (used only when SEP_VISIBLE is True)
    BOTTOM_GAP    = 6       # px vertical gap below header row
    DOT_SIZE      = 14      # px size of the state dot in header

# ----- Chat pane insets -----
class CHAT:
    INSET_LEFT    = -8      # px from the left edge of the content area
    INSET_TOP     = 4       # px extra offset below the header row

# --- B04.22h: attach AVATAR/RIGHTCOL onto L if missing ---
try:
    L  # type: ignore[name-defined]
except NameError:
    class L:  # minimal aggregator if not present
        pass

try:
    _ = L.AVATAR  # type: ignore[attr-defined]
except Exception:
    try:
        L.AVATAR = AVATAR  # type: ignore
    except Exception:
        pass

try:
    _ = L.RIGHTCOL  # type: ignore[attr-defined]
except Exception:
    try:
        L.RIGHTCOL = RIGHTCOL  # type: ignore
    except Exception:
        pass
    
try:
    _ = L.HEADER  # type: ignore[attr-defined]
except Exception:
    try:
        L.HEADER = HEADER  # type: ignore
    except Exception:
        pass

try:
    _ = L.CHAT  # type: ignore[attr-defined]
except Exception:
    try:
        L.CHAT = CHAT  # type: ignore
    except Exception:
        pass
