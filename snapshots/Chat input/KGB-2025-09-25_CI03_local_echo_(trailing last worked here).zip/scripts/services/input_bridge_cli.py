﻿"""services/input_bridge_cli.py — IB01 (stdin pipeline stub)

Runbook alignment:
- Attach mode is the source of truth.
- Embedded CLI is opt-in via env PIPER_UI_EMBED_CLI=1.

IB01 scope (no routing yet):
- Provide a tiny, safe bridge that can read stdin lines in a background thread
  and expose a .send() that writes to stdout when in attach mode.
- No GUI imports; stdlib only. Designed to be wired from UI in IB02.

Usage sketch (IB02 will do this):

    from services.input_bridge_cli import InputBridgeCLI

    bridge = InputBridgeCLI(on_line=lambda s: print(f"CLI> {s}"))
    bridge.start()
    bridge.send("hello from GUI")
    ...
    bridge.stop()

"""
from __future__ import annotations
import os
import sys
import threading
from dataclasses import dataclass, field
from typing import Callable, Optional


@dataclass
class BridgeConfig:
    mode: str = field(default_factory=lambda: ("embedded" if os.environ.get("PIPER_UI_EMBED_CLI", "").strip() == "1" else "attach"))
    encoding: str = "utf-8"
    line_sep: str = "\n"


class InputBridgeCLI:
    """Minimal stdin/stdout bridge.

    - In attach mode, .start() spawns a thread that reads from sys.stdin and
      invokes the provided callback on each complete line.
    - .send(text) writes the text + newline to sys.stdout (attach mode only).
    - Embedded mode is a placeholder; it keeps the API surface identical but
      avoids touching process stdio. IB02/IB03 can extend this.
    """

    def __init__(self, on_line: Optional[Callable[[str], None]] = None, config: Optional[BridgeConfig] = None):
        self.config = config or BridgeConfig()
        self._on_line = on_line or (lambda _s: None)
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._last_error: Optional[BaseException] = None

    # ---------------- lifecycle ----------------
    def start(self) -> None:
        if self.config.mode != "attach":
            # Embedded mode: nothing to spin up yet.
            return
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._reader_loop, name="InputBridgeCLI", daemon=True)
        self._thread.start()

    def stop(self, *, join_timeout: float = 0.5) -> None:
        try:
            self._stop.set()
            if self._thread and self._thread.is_alive():
                self._thread.join(timeout=join_timeout)
        except Exception as exc:
            self._last_error = exc

    # ---------------- I/O ----------------
    def send(self, text: str) -> bool:
        """Send a line to the CLI peer. Returns True if written/queued."""
        try:
            if self.config.mode == "attach":
                data = (text or "") + self.config.line_sep
                sys.stdout.write(data)
                sys.stdout.flush()
                return True
            # Embedded mode: no-op for now; IB02/IB03 may route internally
            return False
        except Exception as exc:
            self._last_error = exc
            return False

    # ---------------- state ----------------
    @property
    def is_running(self) -> bool:
        return bool(self._thread and self._thread.is_alive())

    @property
    def last_error(self) -> Optional[BaseException]:
        return self._last_error

    # ---------------- internals ----------------
    def _reader_loop(self) -> None:
        enc = self.config.encoding
        try:
            while not self._stop.is_set():
                line = sys.stdin.readline()
                if line == "":
                    # EOF or detached pipe; back off then continue until stopped
                    self._stop.wait(0.05)
                    continue
                try:
                    if isinstance(line, bytes):
                        line = line.decode(enc, errors="ignore")
                except Exception:
                    pass
                self._on_line(line.rstrip("\r\n"))
        except Exception as exc:
            self._last_error = exc