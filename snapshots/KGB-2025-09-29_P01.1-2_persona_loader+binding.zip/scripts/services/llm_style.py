﻿# CONTRACT — Persona-Aware Style
# - apply_style(text: str, persona: dict|None) -> str
# - Must be fast and non-blocking; if it fails, caller must continue with raw text.
# - No subprocess, no I/O, no UI imports.
# Notes:
# - Legacy env style PIPER_LLM_STYLE remains supported (plain|pilot|snark).
# - Persona keys recognized: tone, sarcasm (0|1/true), honorific (str), brevity (short|normal|long), first_chunk (bool, hint).


from __future__ import annotations
from typing import Any, Dict, Optional, Union
import os

PersonaT = Union[str, Dict[str, Any], None]

# -------------------------------
# Legacy style (LLM04) — kept for compatibility
# -------------------------------
_STYLE_ENV = "PIPER_LLM_STYLE"
_ALLOWED_STYLES = ("plain", "pilot", "snark")
_DEFAULT_STYLE = "plain"

def _style_plain(reply: str, persona: Any) -> str:
    return reply

def _style_pilot(reply: str, persona: Any) -> str:
    r = (reply or "").strip()
    if not r:
        return r
    if r.lower().startswith("roger"):
        return r
    return f"Roger — {r}"

def _style_snark(reply: str, persona: Any) -> str:
    r = reply or ""
    if r.endswith((".", "!", "?")):
        return r + " Sure."
    return r + " — sure."

_STYLES = {
    "plain": _style_plain,
    "pilot": _style_pilot,
    "snark": _style_snark,
}

def _current_legacy_style() -> str:
    v = (os.environ.get(_STYLE_ENV, _DEFAULT_STYLE) or "").strip().lower()
    return v if v in _ALLOWED_STYLES else _DEFAULT_STYLE

# -------------------------------
# LLM08 persona knobs (env + persona dict)
# -------------------------------

def _resolve_env_persona() -> Dict[str, Any]:
    tone = (os.getenv("PIPER_PERSONA_TONE", "") or "").strip().lower()
    sarcasm_raw = (os.getenv("PIPER_PERSONA_SARCASM", "") or "").strip().lower()
    honorific = (os.getenv("PIPER_PERSONA_HONORIFIC", "") or "").strip()
    brevity = (os.getenv("PIPER_PERSONA_BREVITY", "") or "").strip().lower()

    sarcasm: Optional[bool] = None
    if sarcasm_raw:
        sarcasm = sarcasm_raw in {"1", "true", "yes", "y", "on", "enable", "enabled"}

    out: Dict[str, Any] = {}
    if tone:
        out["tone"] = tone
    if sarcasm is not None:
        out["sarcasm"] = sarcasm
    if honorific:
        out["honorific"] = honorific
    if brevity in {"short", "normal", "long"}:
        out["brevity"] = brevity
    return out

def _coalesce_persona(persona: PersonaT) -> Dict[str, Any]:
    out = _resolve_env_persona()
    if isinstance(persona, dict):
        # persona from caller takes effect only where env not set
        for k, v in persona.items():
            out.setdefault(k, v)
    elif isinstance(persona, str):
        p = persona.strip().lower()
        if p in ("formal", "casual"):
            out.setdefault("tone", p)
        if "sarcasm=1" in p:
            out.setdefault("sarcasm", True)
    return out

# -------------------------------
# Public API
# -------------------------------

def apply_style(text: str, *, persona: PersonaT = None) -> str:
    """Return a styled version of *text*.

    Order of operations:
      1) Legacy style pass (PIPER_LLM_STYLE).
      2) Persona tweaks (non-blocking):
         - sarcasm emoji (😏)
         - optional honorific prefix on first chunk (if persona["first_chunk"])
         - light brevity clamp when brevity == "short"
    Never raises; on any error, return the original text.
    """
    try:
        if text is None:
            return text
        # 1) Legacy style pass
        legacy_fn = _STYLES.get(_current_legacy_style(), _style_plain)
        out = legacy_fn(text, persona)

        # 2) Persona tweaks
        p = _coalesce_persona(persona)
        # Sarcasm — only on FIRST chunk to avoid per-word emoji during streaming
        if bool(p.get("sarcasm", False)) and p.get("first_chunk", False) and any(c.isalnum() for c in out):
            out = f"{out} 😏"
        # Honorific on first chunk only (hint provided by client)
        honorific = (p.get("honorific") or "").strip()
        if honorific and p.get("first_chunk", False):
            lower = out.lower()
            if not lower.startswith(honorific.lower()):
                out = f"{honorific}, {out}" if out else honorific
        # Brevity clamp (very light)
        brevity = str(p.get("brevity", "normal")).lower()
        if brevity == "short" and isinstance(out, str) and len(out) > 240:
            out = out[:240].rstrip() + "…"
        return out
    except Exception:
        return text
