"""llamacpp provider — REAL shell adapter for LLM06.2 (llama-run positional args)
Adapts to your binary's usage:
  Usage: llama-run [options] model [prompt]
We pass: <exe> <model> <prompt> and only supported flags (--context-size, --threads).
Timeouts handled in services.llm_client.
"""
from __future__ import annotations
import os
import subprocess
from typing import List

class LlamaConfigError(RuntimeError):
    pass


def _env(name: str, *, required: bool = False, default: str | None = None) -> str:
    v = os.getenv(name, default)
    if required and (v is None or not str(v).strip()):
        raise LlamaConfigError(f"missing env: {name}")
    return "" if v is None else str(v)


def _build_argv(prompt: str) -> List[str]:
    exe = _env("PIPER_LLAMA_EXE", required=True)  # e.g., C:\Piper\llama.cpp\llama-run.exe
    model = _env("PIPER_LLAMA_MODEL", required=True)  # e.g., C:\Piper\llama.cpp\Meta-Llama-3-8B-Instruct.Q5_K_M.gguf
    ctx = int(_env("PIPER_LLAMA_CTX", default="2048"))
    threads = _env("PIPER_LLAMA_THREADS", default="auto").strip()

    argv: List[str] = [exe, model]
    if prompt:
        argv.append(prompt)
    # Supported flags for your binary
    if ctx:
        argv += ["--context-size", str(ctx)]
    if threads and threads.lower() != "auto":
        argv += ["--threads", threads]
    return argv


def generate(user_text: str, persona: str | None = None) -> str:
    prompt = user_text or ""
    argv = _build_argv(prompt)
    try:
        proc = subprocess.run(
            argv,  # no shell=True
            capture_output=True,
            text=True,
            check=False,
        )
    except FileNotFoundError as e:
        raise RuntimeError(f"llama.cpp exec not found: {argv[0]}") from e
    except LlamaConfigError:
        raise
    except Exception as e:
        raise RuntimeError(f"llama.cpp failed to start: {e}") from e

    if proc.returncode != 0:
        err = (proc.stderr or "").strip()
        raise RuntimeError(f"llama.cpp exited {proc.returncode}: {err[:400]}")

    out = (proc.stdout or "").strip()
    if not out:
        raise RuntimeError("llama.cpp produced no output")
    return out
