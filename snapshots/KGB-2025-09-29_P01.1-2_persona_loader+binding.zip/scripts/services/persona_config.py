﻿# CONTRACT — Persona Config (Read-Only)
# - load_persona() -> dict {tone, sarcasm, honorific, brevity, ...}
# - Sources (in order of precedence):
#   1) Env: PIPER_PERSONA_* (e.g., TONE, SARCASM, HONORIFIC, BREVITY)
#   2) Optional persona.yml (read-only)
#   3) Safe defaults
# Forbidden:
# - UI imports
# - Writes or background threads
# - Network or provider calls

from __future__ import annotations
import os
from typing import Dict, Any, Optional

# YAML is optional. If unavailable or file unreadable, we silently fall back.
try:
    import yaml  # type: ignore
except Exception:  # pragma: no cover
    yaml = None  # type: ignore

# -----------------------------
# Public API
# -----------------------------

def load_persona() -> Dict[str, Any]:
    """
    Resolve persona configuration from (highest → lowest priority):
      1) Environment variables (PIPER_PERSONA_*)
      2) Optional YAML file (path via PIPER_PERSONA_FILE, default 'config/persona.yml')
      3) Safe defaults

    Returns a dict with keys: tone, sarcasm, honorific, brevity.
    - tone: str in {"formal", "casual"} (others allowed but not enforced)
    - sarcasm: int 0|1
    - honorific: str or None
    - brevity: str in {"short", "normal", "long"}

    Never raises; on any error, returns best-effort merge.
    """
    defaults = _default_persona()

    # Lowest priority: YAML (if any)
    yml = _read_yaml_persona()
    merged = {**defaults, **(yml or {})}

    # Highest priority: ENV overrides
    env_overrides = _read_env_persona()
    merged.update(env_overrides)

    # Final sanitation
    return _sanitize_persona(merged)


# -----------------------------
# Internals (no I/O writes, no UI)
# -----------------------------

def _default_persona() -> Dict[str, Any]:
    return {
        "tone": "casual",         # "casual" | "formal" (free-form tolerated)
        "sarcasm": 0,              # 0|1
        "honorific": None,         # e.g., "sir", "captain"
        "brevity": "normal",      # "short" | "normal" | "long"
    }


def _read_env_persona() -> Dict[str, Any]:
    e = {}
    # Strings: keep as-is if non-empty
    tone = os.getenv("PIPER_PERSONA_TONE")
    if tone:
        e["tone"] = tone.strip()

    honorific = os.getenv("PIPER_PERSONA_HONORIFIC")
    if honorific is not None:  # allow empty to explicitly clear
        honorific = honorific.strip()
        e["honorific"] = honorific if honorific else None

    brevity = os.getenv("PIPER_PERSONA_BREVITY")
    if brevity:
        e["brevity"] = brevity.strip()

    # Booleans/ints: accept a variety of truthy/falsey forms
    sarcasm_raw = os.getenv("PIPER_PERSONA_SARCASM")
    if sarcasm_raw is not None:
        e["sarcasm"] = 1 if _as_boolish(sarcasm_raw) else 0

    return e


def _read_yaml_persona() -> Optional[Dict[str, Any]]:
    """Read YAML if available; return dict or None. Silent on errors."""
    # If PyYAML not installed or disabled, bail quietly
    if yaml is None:
        return None

    path = os.getenv("PIPER_PERSONA_FILE", "config/persona.yml").strip()
    if not path:
        return None

    try:
        if not os.path.exists(path):
            return None
        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)  # type: ignore
        if isinstance(data, dict):
            # Normalize common keys if present in YAML
            out: Dict[str, Any] = {}
            if "tone" in data:
                out["tone"] = str(data.get("tone", "")).strip()
            if "sarcasm" in data:
                out["sarcasm"] = 1 if _as_boolish(data.get("sarcasm")) else 0
            if "honorific" in data:
                hv = str(data.get("honorific", "")).strip()
                out["honorific"] = hv if hv else None
            if "brevity" in data:
                out["brevity"] = str(data.get("brevity", "")).strip()
            return out
    except Exception:
        # Silent fail; caller will fall back to defaults
        return None
    return None


def _sanitize_persona(p: Dict[str, Any]) -> Dict[str, Any]:
    # tone: keep as string
    p["tone"] = str(p.get("tone", "casual")).strip() or "casual"

    # sarcasm: ensure 0|1 int
    try:
        p["sarcasm"] = 1 if _as_boolish(p.get("sarcasm", 0)) else 0
    except Exception:
        p["sarcasm"] = 0

    # honorific: None or non-empty string
    hv = p.get("honorific")
    p["honorific"] = (str(hv).strip() or None) if hv is not None else None

    # brevity: normalize to one of short|normal|long (fallback normal)
    bv = str(p.get("brevity", "normal")).strip().lower()
    if bv not in {"short", "normal", "long"}:
        bv = "normal"
    p["brevity"] = bv

    return p


def _as_boolish(v: Any) -> bool:
    if isinstance(v, bool):
        return v
    s = str(v).strip().lower()
    return s in {"1", "true", "yes", "y", "on", "enable", "enabled"}
